#!/usr/bin/env python3
"""调试脚本：检查本地存储的元数据"""
import os
import sys
import json

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from utils.local_storage import LocalStorageSimulator

def check_metadata():
    """检查本地存储的元数据"""
    print("=" * 60)
    print("检查本地存储元数据")
    print("=" * 60)

    storage = LocalStorageSimulator()

    # 读取元数据
    metadata = storage._metadata
    print(f"\n元数据总数: {len(metadata)}")

    for key, value in metadata.items():
        print(f"\n文件key: {key}")
        print(f"  original_name: {value.get('original_name', '')}")
        print(f"  content_type: {value.get('content_type', '')}")
        print(f"  size: {value.get('size', 0)}")

    # 列出所有文件
    print("\n" + "=" * 60)
    print("列出所有文件")
    print("=" * 60)
    result = storage.list_files(prefix="templates/")
    print(f"找到 {len(result.get('keys', []))} 个文件")
    for key in result.get('keys', []):
        metadata = storage.get_file_metadata(key)
        print(f"\n文件key: {key}")
        print(f"  original_name: {metadata.get('original_name', '')}")
        print(f"  content_type: {metadata.get('content_type', '')}")

    # 检查具体的文件
    print("\n" + "=" * 60)
    print("检查特定文件的元数据")
    print("=" * 60)
    test_keys = [
        "templates/template_1769827379_877ada4fc3a7.md",
        "template_1769827379_877ada4fc3a7.md",
        "coze_storage_7601072529431855158/templates/template_1769827379_877ada4fc3a7.md"
    ]

    for key in test_keys:
        metadata = storage.get_file_metadata(key)
        print(f"\n文件key: {key}")
        print(f"  元数据: {metadata}")


if __name__ == "__main__":
    check_metadata()
