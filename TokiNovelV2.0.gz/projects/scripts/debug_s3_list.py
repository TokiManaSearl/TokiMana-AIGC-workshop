#!/usr/bin/env python3
"""调试脚本：检查S3存储的列表和元数据"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from utils.storage_adapter import StorageAdapter

def check_s3_list():
    """检查S3存储的列表"""
    print("=" * 60)
    print("检查S3存储列表")
    print("=" * 60)

    storage = StorageAdapter(use_s3=True)

    # 列出所有模板文件
    result = storage.list_files(prefix="templates/")
    print(f"\n找到 {len(result.get('keys', []))} 个文件")

    for key in result.get('keys', []):
        print(f"\nS3返回的key: {key}")

        # 尝试获取元数据
        metadata = storage.get_file_metadata(key)
        print(f"  元数据: {metadata}")
        print(f"  original_name: {metadata.get('original_name', 'N/A')}")

        # 测试_strip_bucket_prefix
        local_key = storage._strip_bucket_prefix(key)
        print(f"  移除bucket前缀后: {local_key}")

        # 再次尝试获取元数据
        metadata2 = storage.get_file_metadata(key)
        print(f"  再次获取元数据: {metadata2}")


if __name__ == "__main__":
    check_s3_list()
