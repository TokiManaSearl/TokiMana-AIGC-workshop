## 项目概述
- **名称**: 小说改编动画短剧工作流系统
- **功能**: 基于LangGraph的小说改编动画短剧工作流系统，包含四个独立工作流：提示词模板管理、小说改编大纲生成、生成改编文件包、原著小说直接改编

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| upload_template | `nodes/upload_template_node.py` | task | 上传提示词模板文件 | - | - |
| list_templates | `nodes/list_templates_node.py` | task | 列出所有提示词模板 | - | - |
| select_template | `nodes/select_template_node.py` | task | 选择提示词模板 | - | - |
| edit_template | `nodes/edit_template_node.py` | task | 编辑提示词模板 | - | - |
| save_template | `nodes/save_template_node.py` | task | 保存提示词模板 | - | - |
| delete_template | `nodes/delete_template_node.py` | task | 删除提示词模板 | - | - |
| upload_novel | `nodes/upload_novel_node.py` | task | 上传小说文件 | - | - |
| list_novels | `nodes/list_novels_node.py` | task | 列出所有小说 | - | - |
| load_novel | `nodes/load_novel_node.py` | task | 加载小说内容 | - | - |
| delete_novel | `nodes/delete_novel_node.py` | task | 删除小说 | - | - |
| load_template | `nodes/load_template_node.py` | task | 加载提示词模板 | - | - |
| generate_outline | `nodes/generate_outline_node.py` | agent | 生成改编大纲 | - | `config/generate_outline_cfg.json` |
| upload_files | `nodes/upload_files_node.py` | task | 上传文件 | - | - |
| list_files | `nodes/list_files_node.py` | task | 列出文件 | - | - |
| delete_file | `nodes/delete_file_node.py` | task | 删除文件 | - | - |
| clear_all_files | `nodes/clear_all_files_node.py` | task | 清理所有文件 | - | - |
| load_outline | `nodes/load_outline_node.py` | task | 加载大纲内容 | - | - |
| analyze_outline | `nodes/analyze_outline_node.py` | agent | 分析大纲 | - | `config/analyze_outline_cfg.json` |
| list_outlines | `nodes/list_outlines_node.py` | task | 列出大纲 | - | - |
| generate_scripts | `nodes/generate_scripts_node.py` | agent | 生成剧集脚本 | - | `config/generate_scripts_cfg.json` |
| generate_art_documentation | `nodes/generate_art_documentation_node.py` | agent | 生成美术设定文档 | - | `config/generate_art_documentation_cfg.json` |
| generate_60_episodes | `nodes/generate_60_episodes_node.py` | agent | 生成60集完整短剧 | - | `config/generate_60_episodes_cfg.json` |
| generate_episodes | `nodes/generate_episodes_node.py` | agent | 生成指定集数短剧 | - | `config/generate_episodes_cfg.json` |
| generate_art_settings | `nodes/generate_art_settings_node.py` | agent | 生成美术设定（已废弃） | - | - |
| analyze_chapters | `nodes/analyze_chapters_node.py` | agent | 分析小说章节结构（工作流4） | - | `config/analyze_chapters_cfg.json` |
| generate_script_by_chapter | `nodes/generate_script_by_chapter_node.py` | agent | 根据章节生成脚本（工作流4） | - | `config/generate_script_by_chapter_cfg.json` |
| generate_art_settings_from_novel | `nodes/generate_art_settings_from_novel_node.py` | agent | 根据原著生成美术设定（工作流4） | - | `config/generate_art_settings_from_novel_cfg.json` |
| fill_episode_excel | `nodes/fill_episode_excel_node.py` | task | 填写剧集Excel | - | - |
| fill_art_excel | `nodes/fill_art_excel_node.py` | task | 填写美术Excel | - | - |
| create_package | `nodes/create_package_node.py` | task | 创建文件包 | - | - |
| save_outline | `nodes/save_outline_node.py` | task | 保存大纲 | - | - |
| route_by_workflow | `graph.py` | condition | 工作流路由 | "workflow1"->call_workflow1, "workflow2"->call_workflow2, "workflow3"->call_workflow3, "workflow4"->call_workflow4 | - |
| call_workflow1 | `graph.py` | task | 调用工作流1 | - | - |
| call_workflow2 | `graph.py` | task | 调用工作流2 | - | - |
| call_workflow3 | `graph.py` | task | 调用工作流3 | - | - |
| call_workflow4 | `graph.py` | task | 调用工作流4 | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支)

## 子图清单
| 子图名 | 文件位置 | 功能描述 | 被调用节点 |
|-------|---------|------|---------|-----------|
| 无 | - | - | - |

## 集成使用
- **大语言模型**：所有agent节点（generate_outline、generate_scripts、generate_art_documentation等）都通过LLMProvider统一管理API Key，用户需在前端配置页面填写API Key和选择供应商
- **LLM Provider**：支持多个LLM提供商：火山方舟、DeepSeek、Gemini、OpenAI、通义千问、智谱AI、自定义API
- **文件存储**：所有文件使用本地存储（LocalStorageSimulator），保存在`assets/storage`目录
- **Excel处理**：使用openpyxl库处理Excel文件
- **HTTP服务器**：使用Flask提供本地HTTP服务

## 工作流说明

### 工作流1：提示词模板管理
- 上传、列出、选择、编辑、保存、删除提示词模板

### 工作流2：小说改编大纲生成
- 上传、列出、删除、加载小说
- 加载提示词模板
- 生成改编大纲

### 工作流3：生成改编文件包
- **完整流程**（node_name=None或"full_flow"）：load_template -> load_outline -> generate_scripts -> generate_art_documentation
- 单独操作：load_template、load_outline、generate_scripts、generate_art_documentation、generate_60_episodes、generate_episodes等
- 填写Excel：fill_episode_excel、fill_art_excel
- 创建文件包：create_package
- 文件管理：upload_files、list_files、delete_file、clear_all_files

### 工作流4：原著小说直接改编
- **核心特点**：将输入的小说原著在不改变原本的人设、剧情、台词的情况下输出成脚本、台本和美术设定
- **与工作流3的区别**：工作流3是根据大纲推算剧情和美术，工作流4是根据原著小说直接推算剧情和美术
- **每集对应小说章节**：每一集对应小说一章，支持长章节内容
- **功能对齐**：工作流4的功能与工作流3保持一致，包含"生成剧集脚本"和"生成美术设定文档"两个独立功能按钮
- **节点操作**：
  - upload_novel：上传小说（和工作流2共享小说文件夹）
  - list_novels：列出小说
  - delete_novel：删除小说
  - analyze_chapters：分析小说章节结构
  - generate_scripts：生成剧集脚本（与工作流3保持一致的节点名称）
  - generate_art_documentation：生成美术设定文档（与工作流3保持一致的节点名称，内部调用generate_art_settings_from_novel_node）

## 配置文件说明
- `config/generate_outline_cfg.json`：生成大纲的LLM配置
- `config/generate_scripts_cfg.json`：生成脚本的LLM配置
- `config/generate_art_documentation_cfg.json`：生成美术设定的LLM配置
- `config/analyze_outline_cfg.json`：分析大纲的LLM配置
- `config/generate_60_episodes_cfg.json`：生成60集完整短剧的LLM配置
- `config/generate_episodes_cfg.json`：生成指定集数短剧的LLM配置
- `config/analyze_chapters_cfg.json`：分析小说章节的LLM配置（工作流4）
- `config/generate_script_by_chapter_cfg.json`：根据章节生成脚本的LLM配置（工作流4）
- `config/generate_art_settings_from_novel_cfg.json`：根据原著生成美术设定的LLM配置（工作流4）

## LLM Provider配置说明

### 支持的提供商
1. **火山方舟（volcano_ark）**：字节跳动旗下豆包、DeepSeek、Kimi等模型
2. **DeepSeek官方（deepseek）**：DeepSeek V3大模型
3. **Google Gemini（gemini）**：Google Gemini Pro大模型
4. **OpenAI GPT（openai）**：OpenAI GPT-4/GPT-3.5大模型
5. **通义千问（qianwen）**：阿里云通义千问大模型
6. **智谱AI GLM（zhipu）**：智谱AI GLM-4大模型
7. **自定义API（custom）**：使用自定义的OpenAI兼容API

### 配置方式
用户需在前端配置页面：
1. 选择LLM提供商（从上述列表中选择）
2. 填写API Key
3. 配置API端点（Endpoint）
4. 选择模型名称
5. 配置其他参数（温度、最大token数等）

### 重要说明
- **所有LLM调用必须通过用户在前端配置的API Key**
- **不允许使用Coze内置的沙盒环境LLM**
- 如果未配置API Key，系统会提示用户："未配置API Key，请在前端配置页面或环境变量中设置"
- **类型自动转换**：LLMProvider会自动将配置参数转换为正确的类型（temperature转为float，max_tokens转为int），前端可以传递字符串或数字类型

### 参数类型说明
LLMProvider支持以下参数类型：
- **temperature**：推荐范围0.0-2.0，类型可以是字符串（如"0.7"）或数字（如0.7）
- **max_tokens**：推荐范围1-32768，类型可以是字符串（如"4096"）或数字（如4096）
- **top_p**：推荐范围0.0-1.0，类型可以是字符串（如"0.9"）或数字（如0.9）
- **max_completion_tokens**：推荐范围1-32768，类型可以是字符串（如"16384"）或数字（如16384）

系统会在调用LLM API之前自动将字符串转换为正确的数字类型，无需前端手动转换。

## 关键优化
- **编码检测优化**：FileOps.extract_text方法修复了编码检测逻辑，当chardet.detect返回encoding为None时，依次尝试多种编码
- **文件名提取优化**：upload_novel_node修复了文件名提取逻辑，优先使用original_filename字段
- **独立美术设定节点**：将美术设定生成从剧集生成节点中拆分出来，创建独立的generate_art_documentation_node
- **LLM Provider统一管理**：所有LLM调用统一通过LLMProvider管理，用户需在前端配置API Key和选择供应商
- **删除coze依赖**：删除了所有coze_coding_dev_sdk的LLM相关代码，确保用户必须在前端配置API Key
- **类型自动转换**：LLMProvider会自动将temperature、max_tokens等参数转换为正确的类型（float和int），支持字符串和数字两种输入形式
- **完整流程支持**：工作流3支持完整流程，自动执行load_template -> load_outline -> generate_scripts -> generate_art_documentation
