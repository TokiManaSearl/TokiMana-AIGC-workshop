"""
手动查看S3存储的文件列表
运行: python check_storage.py
"""

import os
import sys

# 添加项目路径到Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "src"))

from storage.s3.s3_storage import S3SyncStorage

def main():
    """查看S3存储中的所有文件"""
    print("=" * 60)
    print("📦 S3存储文件列表")
    print("=" * 60)

    # 创建S3存储实例（使用工作流中的配置）
    storage = S3SyncStorage(
        access_key="",           # 空key，通过x-storage-token认证
        secret_key="",          # 空secret，通过x-storage-token认证
        bucket_name=os.getenv("COZE_BUCKET_NAME", "coze_storage_7601072529431855158"),
        region="cn-beijing"
    )

    # 列出所有文件
    print("\n🔍 正在查询S3存储...")
    result = storage.list_files()
    files = result["keys"]

    if not files:
        print("❌ 没有找到文件")
        return

    # 按类型分类
    from collections import defaultdict
    files_by_type = defaultdict(list)

    for file_key in files:
        # 跳过空key和bucket前缀
        if not file_key or file_key.strip() == "":
            continue
        if file_key.endswith("/"):
            continue

        # 提取类型（第一个部分）
        parts = file_key.split("/")
        file_type = parts[0] if parts else "unknown"
        files_by_type[file_type].append(file_key)

    # 显示统计信息
    print(f"\n📊 文件统计：")
    print(f"   总文件数：{len(files)}")
    print(f"   类型数量：{len(files_by_type)}")

    # 按类型显示文件列表
    for file_type, file_list in sorted(files_by_type.items()):
        print(f"\n📁 {file_type}/ ({len(file_list)}个文件)")
        print("-" * 60)
        for file_key in sorted(file_list):
            # 提取文件名（最后一部分）
            filename = file_key.split("/")[-1] if "/" in file_key else file_key
            print(f"   • {filename}")

    # 生成签名URL示例
    print("\n🔗 生成签名URL示例：")
    if files:
        sample_file = files[0]
        url = storage.generate_presigned_url(key=sample_file, expire_time=3600)
        print(f"   文件：{sample_file}")
        print(f"   URL：{url[:80]}...")
        print(f"   有效期：1小时")

    print("\n" + "=" * 60)
    print("✅ 查看完成！")
    print("=" * 60)

if __name__ == "__main__":
    main()
