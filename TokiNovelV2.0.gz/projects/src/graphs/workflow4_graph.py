"""
图形化工作流4：原著小说直接改编（鼠标操作版）
从原著小说直接生成脚本和美术设定，不改变人设、剧情、台词
"""
from typing import Optional
from pydantic import BaseModel, Field
from langgraph.graph import StateGraph, END

# 导入节点
from graphs.nodes.upload_novel_node import upload_novel_node
from graphs.nodes.list_novels_node import list_novels_node
from graphs.nodes.delete_novel_node import delete_novel_node
from graphs.nodes.analyze_chapters_node import analyze_chapters_node
from graphs.nodes.generate_script_by_chapter_node import generate_script_by_chapter_node
from graphs.nodes.generate_art_settings_from_novel_node import generate_art_settings_from_novel_node


class Workflow4Input(BaseModel):
    """
    工作流4输入 - 图形化界面版本
    """
    # 上传节点参数
    upload_novel_file: Optional[dict] = Field(default=None, description="点击上传按钮时提供文件")
    
    # 删除节点参数
    delete_novel_name: str = Field(default="", description="点击删除按钮时提供小说名称")
    
    # 选择模型节点参数
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="从下拉框选择LLM模型")
    
    # 生成脚本节点参数
    start_chapter: int = Field(default=1, ge=1, description="起始章节（从1开始）")
    end_chapter: int = Field(default=3, ge=1, description="结束章节")
    series_name: str = Field(default="原著改编", description="剧集名称")


class Workflow4Output(BaseModel):
    """工作流4输出"""
    novels: list = Field(default=[], description="小说列表")
    chapters: list = Field(default=[], description="章节列表")
    script_files: list = Field(default=[], description="生成的脚本文件列表")
    character_art_url: str = Field(default="", description="角色美术设定文档URL")
    scene_art_url: str = Field(default="", description="场景美术设定文档URL")
    message: str = Field(default="", description="操作结果消息")


class Workflow4GlobalState(BaseModel):
    """工作流4全局状态"""
    # 小说文件存储（和工作流2共享）
    novels: list = Field(default=[], description="已上传的小说文件列表")
    
    # LLM模型选择
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="选择的LLM模型")
    
    # 章节分析结果
    chapters: list = Field(default=[], description="章节列表（章节标题、起始位置、字数、预计时长等）")
    novel_content: str = Field(default="", description="小说内容")
    
    # 生成的脚本
    scripts: dict = Field(default={}, description="生成的脚本字典（key为chapter_1/chapter_2等，value为脚本文本）")
    script_files: list = Field(default=[], description="生成的脚本文件列表")
    
    # 生成的美术设定
    character_settings: list = Field(default=[], description="角色美术设定")
    scene_settings: list = Field(default=[], description="场景美术设定")
    character_art_url: str = Field(default="", description="角色美术设定文档URL")
    scene_art_url: str = Field(default="", description="场景美术设定文档URL")
    
    # 消息
    message: str = Field(default="", description="操作结果消息")
    
    # 输入字段
    upload_novel_file: Optional[dict] = Field(default=None, description="上传的小说文件")
    delete_novel_name: str = Field(default="", description="要删除的小说名称")
    start_chapter: int = Field(default=1, ge=1, description="起始章节")
    end_chapter: int = Field(default=3, ge=1, description="结束章节")
    series_name: str = Field(default="原著改编", description="剧集名称")


# 创建状态图
builder = StateGraph(Workflow4GlobalState, input_schema=Workflow4Input, output_schema=Workflow4Output)

# 添加所有节点
builder.add_node("upload_novel", upload_novel_node, metadata={
    "type": "task",
    "ui": {
        "label": "上传小说",
        "widget": "file_upload",
        "description": "点击上传小说.txt或.md文件"
    }
})

builder.add_node("list_novels", list_novels_node, metadata={
    "type": "task",
    "ui": {
        "label": "刷新列表",
        "widget": "button",
        "description": "查看所有已上传的小说"
    }
})

builder.add_node("delete_novel", delete_novel_node, metadata={
    "type": "task",
    "ui": {
        "label": "删除小说",
        "widget": "button",
        "description": "删除选中的小说",
        "input_field": "delete_novel_name"
    }
})

builder.add_node("analyze_chapters", analyze_chapters_node, metadata={
    "type": "agent",
    "ui": {
        "label": "分析章节",
        "widget": "button",
        "description": "分析小说章节结构，提取章节标题、字数、预计时长等信息"
    },
    "llm_cfg": "config/analyze_chapters_cfg.json"
})

builder.add_node("generate_scripts", generate_script_by_chapter_node, metadata={
    "type": "agent",
    "ui": {
        "label": "生成脚本",
        "widget": "button",
        "description": "根据小说章节内容生成每集脚本（包含建议时长、脚本正文、台本）"
    },
    "llm_cfg": "config/generate_script_by_chapter_cfg.json"
})

builder.add_node("generate_art_settings", generate_art_settings_from_novel_node, metadata={
    "type": "agent",
    "ui": {
        "label": "生成美术设定",
        "widget": "button",
        "description": "根据原著小说和生成的脚本，生成角色和场景的美术设定文档"
    },
    "llm_cfg": "config/generate_art_settings_from_novel_cfg.json"
})

# 设置默认入口点
builder.set_entry_point("list_novels")

# 所有节点执行完后结束
builder.add_edge("upload_novel", END)
builder.add_edge("list_novels", END)
builder.add_edge("delete_novel", END)
builder.add_edge("analyze_chapters", END)
builder.add_edge("generate_scripts", END)
builder.add_edge("generate_art_settings", END)

# 编译图
workflow4_main_graph = builder.compile()
