"""Generate episodes node for workflow 3 - flexible episode range"""
import os
import json
import time
import zipfile
import tempfile
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.llm.llm_provider import get_llm_provider
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from graphs.state import GenerateEpisodesInput, GenerateEpisodesOutput


def generate_episodes_node(
    state: GenerateEpisodesInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateEpisodesOutput:
    """
    title: 生成指定范围集数脚本
    desc: 灵活生成指定范围的剧集脚本（如1-10集、11-20集等），每集包含简介、剧本正文、配音台本，并打包成压缩包。支持分批生成避免超时。
    integrations: 大语言模型, 对象存储
    """
    ctx = runtime.context

    # 从 state 中获取参数
    start_episode = state.start_episode
    end_episode = state.end_episode
    series_name = state.series_name

    # 参数校验
    if start_episode < 1:
        return GenerateEpisodesOutput(
            package_url="",
            message="❌ 起始集数必须 >= 1"
        )
    if end_episode < start_episode:
        return GenerateEpisodesOutput(
            package_url="",
            message="❌ 结束集数必须 >= 起始集数"
        )
    if (end_episode - start_episode + 1) > 10:
        return GenerateEpisodesOutput(
            package_url="",
            message="❌ 单次最多生成10集，请分批生成（如1-10集、11-20集）"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return GenerateEpisodesOutput(
            package_url="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # Get outline from storage
    outline_content = ""
    try:
        result = storage.list_files(prefix="outlines/")
        if result.get("keys"):
            outline_key = result["keys"][-1]
            if outline_key:
                content = storage.read_file(file_key=outline_key)
                outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
    except Exception as e:
        return GenerateEpisodesOutput(
            package_url="",
            message=f"❌ 读取大纲失败: {str(e)}"
        )

    if not outline_content:
        return GenerateEpisodesOutput(
            package_url="",
            message="❌ 未找到大纲，请先生成大纲"
        )

    # Get template content from storage
    template_content = ""
    try:
        result = storage.list_files(prefix="templates/")
        if result.get("keys"):
            template_key = result["keys"][-1]
            if template_key:
                content = storage.read_file(file_key=template_key)
                template_content = content.decode('utf-8') if isinstance(content, bytes) else content
    except Exception as e:
        template_content = ""  # Template is optional

    # 动态生成批次（每批5集，减少单次LLM输出长度）
    total_episodes = end_episode - start_episode + 1
    batch_size = 5
    episode_batches = []
    for i in range(start_episode, end_episode + 1, batch_size):
        batch_end = min(i + batch_size - 1, end_episode)
        episode_batches.append(f"第{i}-{batch_end}集")

    # 读取LLM配置
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_60_episodes_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        llm_config = _cfg.get("config", {})
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return GenerateEpisodesOutput(
            package_url="",
            message=f"❌ 读取配置失败: {str(e)}"
        )

    # 创建临时目录保存文件
    temp_dir = tempfile.mkdtemp()
    all_files = []

    try:
        # 获取LLM Provider
        llm_provider = get_llm_provider()

        # 分批生成（每批5集）
        for batch_idx, episode_range in enumerate(episode_batches, 1):
            batch_start_time = time.time()
            print(f"[{batch_idx}/{len(episode_batches)}] 正在生成{episode_range}脚本...")
            print(f"  开始时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")

            # 渲染用户提示词
            up_tpl = Template(up)
            user_prompt = up_tpl.render(
                outline_content=outline_content,
                template_content=template_content,
                episode_range=episode_range
            )

            messages = [
                {"role": "system", "content": sp},
                {"role": "user", "content": user_prompt}
            ]

            # 调用LLM生成脚本
            print(f"  调用LLM生成{episode_range}脚本...")
            llm_start_time = time.time()
            
            scripts_content = llm_provider.call_llm_with_config(
                llm_cfg=llm_config,
                messages=messages
            )
            
            llm_end_time = time.time()
            llm_duration = llm_end_time - llm_start_time
            print(f"  ✓ LLM调用完成，耗时: {llm_duration:.1f}秒")

            # 解析响应
            if isinstance(scripts_content, list):
                scripts_content = " ".join(str(item) for item in scripts_content)

            # 按分隔符拆分每集
            episodes = scripts_content.split("---")
            episode_num_start = int(episode_range.split("-")[0].replace("第", "").replace("集", ""))

            for i, episode in enumerate(episodes):
                episode_num = episode_num_start + i
                if not episode.strip():
                    continue

                # 保存每集脚本
                episode_file = os.path.join(temp_dir, f"第{episode_num}集.md")
                with open(episode_file, 'w', encoding='utf-8') as f:
                    f.write(episode.strip())
                all_files.append(episode_file)

                print(f"  ✓ 第{episode_num}集已生成")

            batch_end_time = time.time()
            batch_duration = batch_end_time - batch_start_time
            print(f"  ✓ {episode_range}脚本生成完成，批次总耗时: {batch_duration:.1f}秒")

        # 读取美术设定配置
        try:
            art_cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_art_settings_60_cfg.json")
            with open(art_cfg_file, 'r', encoding='utf-8') as fd:
                _art_cfg = json.load(fd)
            art_llm_config = _art_cfg.get("config", {})
            art_sp = _art_cfg.get("sp", "")
            art_up = _art_cfg.get("up", "")
        except Exception as e:
            print(f"⚠️ 读取美术设定配置失败，跳过美术设定生成: {e}")
            art_llm_config = None

        # 分批生成美术设定（每批5集）
        if art_llm_config:
            for episode_range in episode_batches:
                art_batch_start_time = time.time()
                print(f"正在生成{episode_range}美术设定...")

                # 读取该批次的脚本内容
                episode_num_start = int(episode_range.split("-")[0].replace("第", "").replace("集", ""))
                episode_num_end = int(episode_range.split("-")[1].replace("集", ""))
                batch_episodes = []
                for num in range(episode_num_start, episode_num_end + 1):
                    episode_file = os.path.join(temp_dir, f"第{num}集.md")
                    if os.path.exists(episode_file):
                        with open(episode_file, 'r', encoding='utf-8') as f:
                            batch_episodes.append(f.read())

                if not batch_episodes:
                    continue

                batch_content = "\n\n---\n\n".join(batch_episodes)

                # 渲染美术设定提示词
                art_up_tpl = Template(art_up)
                art_user_prompt = art_up_tpl.render(
                    episodes_content=batch_content,
                    episode_range=episode_range
                )

                art_messages = [
                    {"role": "system", "content": art_sp},
                    {"role": "user", "content": art_user_prompt}
                ]

                # 调用LLM生成美术设定
                art_llm_start_time = time.time()
                
                art_content = llm_provider.call_llm_with_config(
                    llm_cfg=art_llm_config,
                    messages=art_messages
                )
                
                art_llm_end_time = time.time()
                art_llm_duration = art_llm_end_time - art_llm_start_time
                print(f"  ✓ 美术设定LLM调用完成，耗时: {art_llm_duration:.1f}秒")

                # 解析并保存美术设定
                if isinstance(art_content, list):
                    art_content = " ".join(str(item) for item in art_content)

                # 保存美术设定（新格式：[美术元素名称]：[香蕉pro文生图提示词]）
                art_file = os.path.join(temp_dir, f"美术设定清单_{episode_range}.md")
                with open(art_file, 'w', encoding='utf-8') as f:
                    f.write(art_content)
                all_files.append(art_file)

                art_batch_end_time = time.time()
                art_batch_duration = art_batch_end_time - art_batch_start_time
                print(f"  ✓ {episode_range}美术设定生成完成，批次总耗时: {art_batch_duration:.1f}秒")

        # 生成完整台本（将指定范围集数合并）
        complete_script_file = os.path.join(temp_dir, f"完整台本（第{start_episode}-{end_episode}集）.md")
        with open(complete_script_file, 'w', encoding='utf-8') as f:
            f.write(f"# 完整台本（第{start_episode}-{end_episode}集）\n\n")
            for episode_num in range(start_episode, end_episode + 1):
                episode_file = os.path.join(temp_dir, f"第{episode_num}集.md")
                if os.path.exists(episode_file):
                    with open(episode_file, 'r', encoding='utf-8') as ef:
                        f.write(ef.read())
                        f.write("\n\n---\n\n")
        all_files.append(complete_script_file)

        # 打包成压缩包
        package_filename = f"{series_name}_第{start_episode}-{end_episode}集.zip"
        package_file = os.path.join(temp_dir, package_filename)
        with zipfile.ZipFile(package_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_path in all_files:
                arcname = os.path.basename(file_path)
                zipf.write(file_path, arcname)

        # 上传压缩包到对象存储
        with open(package_file, 'rb') as f:
            package_content = f.read()

        original_name = package_filename
        safe_filename, _ = get_safe_filename(original_name, category="packages", use_timestamp=True)
        storage_key = f"packages/{safe_filename}"

        file_key = storage.upload_file(
            file_content=package_content,
            file_name=storage_key,
            content_type="application/zip",
            original_name=original_name
        )

        # 获取本地文件路径
        if hasattr(storage, 'use_s3') and not storage.use_s3:
            # 本地存储模式
            file_path = storage.generate_presigned_url(key=file_key, expire_time=3600)
            package_url = file_path

            # 构建详细的完成消息
            success_message = f"""✅ 成功生成第{start_episode}-{end_episode}集脚本并打包！

📦 压缩包信息：
   - 文件数：{len(all_files)} 个文件
   - 文件名：{package_filename}
   - 文件大小：{len(package_content) / 1024:.1f} KB

💾 文件位置：
   {file_path}

💡 使用方法：
   1. 在资源管理器中打开上述路径
   2. 找到压缩包文件：{package_filename}
   3. 右键 -> 解压文件
   4. 查看生成的脚本和美术设定

⚠️  注意：
   - 文件已保存到本地，无需下载
   - 建议备份到其他位置
"""
        else:
            # S3存储模式
            package_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

            # 构建详细的完成消息，包含下载链接
            success_message = f"""✅ 成功生成第{start_episode}-{end_episode}集脚本并打包！

📦 压缩包信息：
   - 文件数：{len(all_files)} 个文件
   - 文件名：{package_filename}
   - 文件大小：{len(package_content) / 1024:.1f} KB

📥 下载链接（有效期1小时）：
   {package_url}

💡 使用方法：
   1. 复制上面的下载链接
   2. 在浏览器中打开
   3. 浏览器会自动下载文件到你的电脑
   4. 文件会保存在：浏览器的默认下载目录（通常是下载文件夹）

⚠️  注意：
   - 下载链接有效期1小时，超时需要重新生成
   - 建议尽快下载并备份到你的电脑
"""

        return GenerateEpisodesOutput(
            package_url=package_url,
            message=success_message
        )

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        print(f"生成第{start_episode}-{end_episode}集失败: {error_detail}")
        return GenerateEpisodesOutput(
            package_url="",
            message=f"❌ 生成第{start_episode}-{end_episode}集失败: {str(e)}"
        )
