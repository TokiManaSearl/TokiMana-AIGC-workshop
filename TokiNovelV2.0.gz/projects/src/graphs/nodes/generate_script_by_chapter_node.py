"""Generate script by chapter node for workflow 4 - Generate script from novel chapters"""
import os
import json
import re
from typing import Dict, List, Any, Optional
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from utils.llm.llm_provider import get_llm_provider
from graphs.state import GenerateScriptByChapterInput, GenerateScriptByChapterOutput
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading


def generate_single_chapter_script(
    chapter_num: int,
    chapter_title: str,
    chapter_content: str,
    estimated_duration: int,
    sp_template: str,
    up_template: str,
    llm_provider,
    llm_config: dict,
    lock: threading.Lock,
    progress_dict: dict
) -> tuple:
    """
    生成单章节脚本（用于并行调用）

    Args:
        chapter_num: 章节编号
        chapter_title: 章节标题
        chapter_content: 章节内容
        estimated_duration: 预计时长（分钟）
        sp_template: 系统提示词模板
        up_template: 用户提示词模板
        llm_provider: LLM Provider实例
        llm_config: LLM配置
        lock: 线程锁（用于保护共享资源）
        progress_dict: 进度字典（用于报告进度）

    Returns:
        tuple: (chapter_num, script_content, error_message)
    """
    try:
        # 渲染提示词
        up_tpl = Template(up_template)
        user_prompt = up_tpl.render(
            chapter_content=chapter_content,
            chapter_number=chapter_num,
            chapter_title=chapter_title,
            estimated_duration=estimated_duration
        )

        messages = [
            {"role": "system", "content": sp_template},
            {"role": "user", "content": user_prompt}
        ]

        # 调用LLM（带超时保护）
        response = None
        try:
            # 使用Thread实现超时保护（最长300秒，因为章节可能很长）
            import threading
            result = [None]
            error = [None]

            def call_llm():
                try:
                    # 使用用户配置的LLM
                    result[0] = llm_provider.call_llm_with_config(
                        llm_cfg=llm_config,
                        messages=messages
                    )
                except Exception as e:
                    error[0] = e

            # 创建线程
            thread = threading.Thread(target=call_llm)
            thread.daemon = True
            thread.start()

            # 等待线程完成，最多300秒（5分钟）
            thread.join(timeout=300)

            if thread.is_alive():
                # 超时，线程仍在运行
                raise TimeoutError(f"生成第{chapter_num}章脚本超时（300秒）")

            if error[0]:
                raise error[0]

            response = result[0]
            if response is None:
                raise Exception(f"LLM调用返回空结果（第{chapter_num}章）")
        except TimeoutError as te:
            raise te
        except Exception as llm_error:
            raise Exception(f"LLM调用失败: {llm_error}")

        # 提取响应内容
        script_content = response
        if script_content is None:
            script_content = ""
        if isinstance(script_content, list):
            script_content = " ".join(str(item) for item in script_content)

        # 使用线程锁保护进度报告
        with lock:
            progress_dict['completed'] += 1
            total = progress_dict['total']
            completed = progress_dict['completed']
            print(f"📊 进度：{completed}/{total}章完成 ({completed*100//total}%)")

        return chapter_num, script_content, None

    except Exception as e:
        # 使用线程锁保护错误报告
        with lock:
            progress_dict['failed'] += 1
            error_msg = str(e)
            # 截断过长的错误信息
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
            print(f"❌ 生成第{chapter_num}章脚本失败: {error_msg}")

        return chapter_num, None, str(e)


def generate_script_by_chapter_node(
    state: GenerateScriptByChapterInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateScriptByChapterOutput:
    """
    title: 根据章节生成脚本
    desc: 根据小说章节内容生成每集脚本（包含简介、脚本正文、台本），简介中包含建议时长
    integrations: 大语言模型, 对象存储
    """
    from jinja2 import Template

    ctx = runtime.context

    # 获取章节信息
    chapters = state.chapters
    novel_content = state.novel_content
    series_name = state.series_name
    start_chapter = state.start_chapter
    end_chapter = state.end_chapter

    # 验证章节范围
    if not chapters:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message="❌ 章节列表为空，请先执行'分析章节'操作"
        )

    total_chapters = len(chapters)
    if start_chapter > end_chapter:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ 起始章节({start_chapter})不能大于结束章节({end_chapter})"
        )

    if end_chapter > total_chapters:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ 结束章节({end_chapter})超过总章节数({total_chapters})"
        )

    print(f"🎬 开始根据章节生成脚本（第{start_chapter}-{end_chapter}章）...")

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=False)
    except Exception as e:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 获取LLM Provider
    llm_provider = get_llm_provider()

    # 读取提示词模板（SP和UP）
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_script_by_chapter_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ 读取LLM配置失败: {str(e)}"
        )

    # 从LLM Provider获取当前提供商的配置
    provider_config = llm_provider.get_provider_config(llm_provider.enabled_provider)
    if not provider_config:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ LLM提供商 {llm_provider.enabled_provider} 不存在，请先配置LLM提供商"
        )

    llm_config = provider_config.get("config", {})
    model = llm_config.get("model", "")
    if not model:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message="❌ 未配置模型，请先在LLM提供商中配置模型"
        )

    print(f"✅ 使用LLM提供商: {llm_provider.enabled_provider}, 模型: {model}")

    # 计算需要生成的章节
    chapters_to_generate = []
    for chapter in chapters[start_chapter - 1:end_chapter]:
        # 提取章节内容
        start_pos = chapter.get("start_position", 0)
        end_pos = chapter.get("end_position", len(novel_content))
        chapter_content = novel_content[start_pos:end_pos]

        chapters_to_generate.append({
            "chapter_number": chapter.get("chapter_number", start_chapter + len(chapters_to_generate)),
            "chapter_title": chapter.get("chapter_title", f"第{chapter.get('chapter_number', start_chapter + len(chapters_to_generate))}章"),
            "content": chapter_content,
            "estimated_duration": chapter.get("estimated_duration", 5)
        })

    if not chapters_to_generate:
        return GenerateScriptByChapterOutput(
            script_files=[],
            scripts={},
            message=f"❌ 没有需要生成的章节"
        )

    total_to_generate = len(chapters_to_generate)
    print(f"📖 共{total_to_generate}章需要生成脚本")

    # 使用并行生成策略
    # 根据章节数量调整并发数（3-5个）
    max_workers = min(5, max(3, total_to_generate))
    print(f"🚀 使用{max_workers}个线程并行生成...")

    progress_dict = {
        'total': total_to_generate,
        'completed': 0,
        'failed': 0
    }

    lock = threading.Lock()
    scripts = {}
    failed_chapters = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # 提交所有任务
        future_to_chapter = {}
        for chapter_info in chapters_to_generate:
            future = executor.submit(
                generate_single_chapter_script,
                chapter_info["chapter_number"],
                chapter_info["chapter_title"],
                chapter_info["content"],
                chapter_info["estimated_duration"],
                sp,
                up,
                llm_provider,
                llm_config,
                lock,
                progress_dict
            )
            future_to_chapter[future] = chapter_info

        # 等待所有任务完成
        for future in as_completed(future_to_chapter):
            chapter_info = future_to_chapter[future]
            chapter_num = chapter_info["chapter_number"]
            chapter_title = chapter_info["chapter_title"]

            try:
                chapter_num, script_content, error = future.result()

                if error:
                    failed_chapters.append({
                        "chapter_number": chapter_num,
                        "chapter_title": chapter_title,
                        "error": error
                    })
                else:
                    # 保存脚本内容
                    script_key = f"chapter_{chapter_num}"
                    scripts[script_key] = script_content
            except Exception as e:
                failed_chapters.append({
                    "chapter_number": chapter_num,
                    "chapter_title": chapter_title,
                    "error": str(e)
                })

    print(f"✅ 脚本生成完成：成功{progress_dict['completed']}章，失败{progress_dict['failed']}章")

    # 保存脚本文件
    script_files = []
    for chapter_info in chapters_to_generate:
        chapter_num = chapter_info["chapter_number"]
        script_key = f"chapter_{chapter_num}"
        
        if script_key not in scripts:
            print(f"⚠️ 第{chapter_num}章脚本生成失败，跳过保存")
            continue

        script_content = scripts[script_key]

        # 生成文件名
        safe_name = get_safe_filename(series_name)
        filename = f"{safe_name}_Chapter{chapter_num:02d}.md"
        file_key = f"scripts/{filename}"

        # 保存到存储
        try:
            script_url = storage.upload_file(
                file_content=script_content.encode('utf-8'),
                file_name=file_key,
                content_type="text/markdown",
                original_name=filename
            )
            
            script_files.append({
                "chapter_number": chapter_num,
                "chapter_title": chapter_info["chapter_title"],
                "filename": filename,
                "file_key": file_key,
                "word_count": len(script_content),
                "url": script_url
            })
        except Exception as e:
            print(f"⚠️ 保存第{chapter_num}章脚本失败: {str(e)}")

    print(f"✅ 成功保存{len(script_files)}个脚本文件")

    # 构建返回消息
    message = f"✅ 成功生成{len(script_files)}个脚本文件（第{start_chapter}-{end_chapter}章）"
    if failed_chapters:
        message += f"，{len(failed_chapters)}章失败"

    return GenerateScriptByChapterOutput(
        script_files=script_files,
        scripts=scripts,
        message=message
    )
