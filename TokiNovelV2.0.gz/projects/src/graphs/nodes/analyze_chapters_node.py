"""Analyze chapters node for workflow 4 - Analyze novel chapter structure"""
import os
import json
import re
from typing import Dict, List, Any, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file.file import File, FileOps
from utils.llm.llm_provider import get_llm_provider
from graphs.state import AnalyzeChaptersInput, AnalyzeChaptersOutput


def analyze_chapters_node(
    state: AnalyzeChaptersInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> AnalyzeChaptersOutput:
    """
    title: 分析小说章节结构
    desc: 使用LLM分析小说内容，提取章节标题、起始位置、字数、预计时长等信息
    integrations: 大语言模型
    """
    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=False)
    except Exception as e:
        return AnalyzeChaptersOutput(
            chapters=[],
            novel_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    print("🔍 开始分析小说章节结构...")

    # 读取小说内容
    novel_content = ""
    if state.novel_content:
        # 直接使用提供的内容
        novel_content = state.novel_content
    elif state.novel_file:
        # 从文件读取
        try:
            content = FileOps.extract_text(state.novel_file)
            if isinstance(content, bytes):
                novel_content = content.decode('utf-8')
            else:
                novel_content = content
        except Exception as e:
            return AnalyzeChaptersOutput(
                chapters=[],
                novel_content="",
                message=f"❌ 读取小说文件失败: {str(e)}"
            )
    else:
        # 从存储中读取最新的小说文件
        try:
            result = storage.list_files(prefix="novels/")
            novel_files = [key for key in result.get("keys", []) if key.endswith(".txt") or key.endswith(".md")]
            
            if not novel_files:
                return AnalyzeChaptersOutput(
                    chapters=[],
                    novel_content="",
                    message="❌ 未找到小说文件，请先上传小说"
                )
            
            # 读取最新的小说文件
            latest_file = novel_files[0]
            content = storage.read_file(file_key=latest_file)
            novel_content = content.decode('utf-8') if isinstance(content, bytes) else content
        except Exception as e:
            return AnalyzeChaptersOutput(
                chapters=[],
                novel_content="",
                message=f"❌ 从存储读取小说失败: {str(e)}"
            )

    if not novel_content or len(novel_content.strip()) < 100:
        return AnalyzeChaptersOutput(
            chapters=[],
            novel_content=novel_content,
            message="❌ 小说内容为空或太短，无法分析章节结构"
        )

    print(f"📖 成功读取小说内容，共{len(novel_content)}字")

    # 获取LLM Provider
    llm_provider = get_llm_provider()

    # 读取提示词模板（SP和UP）
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/analyze_chapters_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return AnalyzeChaptersOutput(
            chapters=[],
            novel_content=novel_content,
            message=f"❌ 读取LLM配置失败: {str(e)}"
        )

    # 从LLM Provider获取当前提供商的配置
    provider_config = llm_provider.get_provider_config(llm_provider.enabled_provider)
    if not provider_config:
        return AnalyzeChaptersOutput(
            chapters=[],
            novel_content=novel_content,
            message=f"❌ LLM提供商 {llm_provider.enabled_provider} 不存在，请先配置LLM提供商"
        )

    llm_config = provider_config.get("config", {})
    model = llm_config.get("model", "")
    if not model:
        return AnalyzeChaptersOutput(
            chapters=[],
            novel_content=novel_content,
            message="❌ 未配置模型，请先在LLM提供商中配置模型"
        )

    print(f"✅ 使用LLM提供商: {llm_provider.enabled_provider}, 模型: {model}")

    # 调用LLM分析章节结构
    print("🤖 正在调用LLM分析章节结构...")

    try:
        # 准备消息
        messages = [
            {"role": "system", "content": sp},
            {"role": "user", "content": up}
        ]

        # 替换用户提示词中的占位符
        messages[1]["content"] = messages[1]["content"].replace("{{novel_content}}", novel_content[:100000])  # 限制长度避免超限

        # 调用LLM
        response = llm_provider.call_llm_with_config(
            llm_cfg=llm_config,
            messages=messages
        )

        # 解析LLM响应
        if response is None:
            raise Exception("LLM调用返回空结果")

        # 提取章节信息
        chapters = parse_chapters_from_response(response, novel_content)

        if not chapters:
            # 如果LLM无法解析，使用正则表达式回退方案
            chapters = extract_chapters_by_regex(novel_content)

        print(f"✅ 成功分析出{len(chapters)}个章节")

        return AnalyzeChaptersOutput(
            chapters=chapters,
            novel_content=novel_content,
            message=f"✅ 成功分析出{len(chapters)}个章节"
        )

    except Exception as e:
        # LLM调用失败，使用正则表达式回退方案
        print(f"⚠️ LLM分析失败: {str(e)}，使用正则表达式回退方案")
        
        try:
            chapters = extract_chapters_by_regex(novel_content)
            
            if chapters:
                print(f"✅ 正则表达式提取出{len(chapters)}个章节")
                return AnalyzeChaptersOutput(
                    chapters=chapters,
                    novel_content=novel_content,
                    message=f"✅ 使用正则表达式提取出{len(chapters)}个章节（LLM分析失败）"
                )
            else:
                # 如果连正则表达式都无法提取，将整本小说作为一个章节
                chapters = [{
                    "chapter_number": 1,
                    "chapter_title": "全文",
                    "start_position": 0,
                    "end_position": len(novel_content),
                    "word_count": len(novel_content),
                    "estimated_duration": max(5, len(novel_content) // 2000)  # 估算：2000字约5分钟
                }]
                print(f"✅ 将整本小说作为一个章节处理")
                return AnalyzeChaptersOutput(
                    chapters=chapters,
                    novel_content=novel_content,
                    message=f"✅ 将整本小说作为一个章节处理"
                )
        except Exception as fallback_error:
            return AnalyzeChaptersOutput(
                chapters=[],
                novel_content=novel_content,
                message=f"❌ 分析章节失败: {str(e)}（回退方案也失败: {str(fallback_error)}）"
            )


def parse_chapters_from_response(response: str, novel_content: str) -> List[Dict[str, Any]]:
    """
    从LLM响应中解析章节信息

    Args:
        response: LLM的响应文本
        novel_content: 小说完整内容

    Returns:
        章节信息列表
    """
    chapters = []

    try:
        # 尝试解析JSON格式
        if response.strip().startswith("[") or response.strip().startswith("{"):
            # 提取JSON部分
            json_match = re.search(r'\[.*?\]', response, re.DOTALL)
            if json_match:
                chapters_data = json.loads(json_match.group(0))
                
                for idx, chapter in enumerate(chapters_data):
                    chapter_number = chapter.get("chapter_number", idx + 1)
                    chapter_title = chapter.get("chapter_title", f"第{chapter_number}章")
                    start_position = chapter.get("start_position", 0)
                    end_position = chapter.get("end_position", len(novel_content))
                    word_count = chapter.get("word_count", end_position - start_position)
                    estimated_duration = chapter.get("estimated_duration", max(5, word_count // 2000))

                    chapters.append({
                        "chapter_number": chapter_number,
                        "chapter_title": chapter_title,
                        "start_position": start_position,
                        "end_position": end_position,
                        "word_count": word_count,
                        "estimated_duration": estimated_duration
                    })

                return chapters
    except Exception as e:
        print(f"⚠️ JSON解析失败: {str(e)}")

    # 如果JSON解析失败，尝试从文本中提取
    lines = response.split('\n')
    current_chapter = None

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # 尝试匹配章节标题
        chapter_match = re.match(r'第?(\d+)[章章节集回]\s*(.*)', line)
        if chapter_match:
            if current_chapter:
                chapters.append(current_chapter)

            chapter_number = int(chapter_match.group(1))
            chapter_title = chapter_match.group(2).strip() or f"第{chapter_number}章"
            
            current_chapter = {
                "chapter_number": chapter_number,
                "chapter_title": chapter_title,
                "start_position": 0,
                "end_position": 0,
                "word_count": 0,
                "estimated_duration": 5
            }

    if current_chapter:
        chapters.append(current_chapter)

    # 如果仍然没有提取到章节，返回空列表
    if not chapters:
        return []

    # 根据章节标题在小说内容中定位
    current_pos = 0
    for idx, chapter in enumerate(chapters):
        # 查找章节标题在小说中的位置
        title_patterns = [
            f"第{chapter['chapter_number']}章",
            f"第{chapter['chapter_number']}节",
            f"第{chapter['chapter_number']}集",
            f"第{chapter['chapter_number']}回",
            f"Chapter {chapter['chapter_number']}"
        ]

        found_pos = len(novel_content)
        for pattern in title_patterns:
            pos = novel_content.find(pattern, current_pos)
            if pos != -1 and pos < found_pos:
                found_pos = pos

        chapter['start_position'] = found_pos

    # 计算每个章节的结束位置
    for idx in range(len(chapters) - 1):
        chapters[idx]['end_position'] = chapters[idx + 1]['start_position']

    if chapters:
        chapters[-1]['end_position'] = len(novel_content)

    # 计算字数和时长
    for chapter in chapters:
        chapter_text = novel_content[chapter['start_position']:chapter['end_position']]
        chapter['word_count'] = len(chapter_text)
        chapter['estimated_duration'] = max(5, chapter['word_count'] // 2000)

    return chapters


def extract_chapters_by_regex(novel_content: str) -> List[Dict[str, Any]]:
    """
    使用正则表达式提取章节信息（回退方案）

    Args:
        novel_content: 小说完整内容

    Returns:
        章节信息列表
    """
    chapters = []

    # 常见的章节标题模式
    patterns = [
        r'(第\s*\d+\s*[章节集回])\s*(.*?)\n',
        r'(Chapter\s+\d+)\s*(.*?)\n',
        r'(第\s*\d+\s*卷)\s*(.*?)\n',
    ]

    chapter_positions = []

    for pattern in patterns:
        for match in re.finditer(pattern, novel_content):
            chapter_title = match.group(0).strip()
            position = match.start()
            chapter_positions.append((position, chapter_title))

    # 按位置排序
    chapter_positions.sort(key=lambda x: x[0])

    # 去重（如果同一个位置有多种匹配，只保留第一个）
    if chapter_positions:
        unique_positions = [chapter_positions[0]]
        for pos, title in chapter_positions[1:]:
            if pos != unique_positions[-1][0]:
                unique_positions.append((pos, title))
        chapter_positions = unique_positions

    # 如果没有找到章节标题，将整本小说作为一个章节
    if not chapter_positions:
        chapters.append({
            "chapter_number": 1,
            "chapter_title": "全文",
            "start_position": 0,
            "end_position": len(novel_content),
            "word_count": len(novel_content),
            "estimated_duration": max(5, len(novel_content) // 2000)
        })
        return chapters

    # 构建章节信息
    for idx, (position, title) in enumerate(chapter_positions):
        start_pos = position
        end_pos = chapter_positions[idx + 1][0] if idx + 1 < len(chapter_positions) else len(novel_content)
        chapter_text = novel_content[start_pos:end_pos]

        # 提取章节编号
        number_match = re.search(r'第?\s*(\d+)', title)
        chapter_number = int(number_match.group(1)) if number_match else idx + 1

        chapters.append({
            "chapter_number": chapter_number,
            "chapter_title": title,
            "start_position": start_pos,
            "end_position": end_pos,
            "word_count": len(chapter_text),
            "estimated_duration": max(5, len(chapter_text) // 2000)
        })

    return chapters
