"""Save outline node for workflow 2"""
import os
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from graphs.state import SaveOutlineInput, SaveOutlineOutput


def save_outline_node(
    state: SaveOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SaveOutlineOutput:
    """
    title: Save Outline
    desc: Save generated outline to storage
    integrations: 对象存储
    """
    # 初始化对象存储
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return SaveOutlineOutput(
            saved_url="",
            message=f"❌ 初始化对象存储服务失败: {str(e)}"
        )
    
    saved_url = ""
    try:
        # 生成安全的文件名（不使用时间戳，支持覆盖）
        safe_filename, _ = get_safe_filename("outline.md", category="outline", use_timestamp=False)
        outline_key = f"outlines/{safe_filename}"
        
        # Save outline to storage
        outline_content = state.outline_content.encode('utf-8')
        storage_key = storage.upload_file(
            file_content=outline_content,
            file_name=outline_key,
            content_type="text/markdown",
            original_name=safe_filename
        )
        
        saved_url = storage_key
    except Exception as e:
        return SaveOutlineOutput(
            saved_url="",
            message=f"❌ 保存大纲失败: {str(e)}"
        )
    
    return SaveOutlineOutput(
        saved_url=saved_url,
        message="✅ 大纲已保存"
    )
