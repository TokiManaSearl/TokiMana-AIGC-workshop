"""List novels node for workflow 2"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import ListNovelsInput, ListNovelsOutput


def list_novels_node(
    state: ListNovelsInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ListNovelsOutput:
    """
    title: 列出小说
    desc: 查看所有已上传的小说
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return ListNovelsOutput(
            novels=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    novels = []
    try:
        # List files from storage
        result = storage.list_files(prefix="novels/")
        novels = []
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")

                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1]

                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                novels.append({"name": display_name, "url": url})
            except Exception as e:
                print(f"处理文件信息失败: {e}")
    except Exception as e:
        return ListNovelsOutput(
            novels=[],
            message=f"❌ 列出小说失败: {str(e)}"
        )

    if not novels:
        return ListNovelsOutput(
            novels=[],
            message="📭 暂无小说，请先上传"
        )

    return ListNovelsOutput(
        novels=novels,
        message=f"✅ 共找到 {len(novels)} 本小说"
    )
