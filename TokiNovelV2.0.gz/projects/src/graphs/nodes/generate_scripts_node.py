"""Generate scripts node for workflow 3"""
import os
import json
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from utils.llm.llm_provider import get_llm_provider
from graphs.state import GenerateScriptsInput, GenerateScriptsOutput
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading


def generate_single_episode(
    episode_num: int,
    outline_content: str,
    sp_template: str,
    up_template: str,
    llm_provider,
    llm_config: dict,
    lock: threading.Lock,
    progress_dict: dict
) -> tuple:
    """
    生成单集脚本（用于并行调用）

    Args:
        episode_num: 集数
        outline_content: 大纲内容
        sp_template: 系统提示词模板
        up_template: 用户提示词模板
        llm_provider: LLM Provider实例
        llm_config: LLM配置
        lock: 线程锁（用于保护共享资源）
        progress_dict: 进度字典（用于报告进度）

    Returns:
        tuple: (episode_num, script_content, error_message)
    """
    try:
        # 渲染提示词
        up_tpl = Template(up_template)
        user_prompt = up_tpl.render(
            outline_content=outline_content,
            episode_number=episode_num
        )

        messages = [
            {"role": "system", "content": sp_template},
            {"role": "user", "content": user_prompt}
        ]

        # 调用LLM（带超时保护）
        response = None
        try:
            # 使用Thread实现超时保护（最长180秒）
            import threading
            result = [None]
            error = [None]

            def call_llm():
                try:
                    # 使用用户配置的LLM
                    result[0] = llm_provider.call_llm_with_config(
                        llm_cfg=llm_config,
                        messages=messages
                    )
                except Exception as e:
                    error[0] = e

            # 创建线程
            thread = threading.Thread(target=call_llm)
            thread.daemon = True
            thread.start()

            # 等待线程完成，最多180秒（3分钟）
            thread.join(timeout=180)

            if thread.is_alive():
                # 超时，线程仍在运行
                raise TimeoutError(f"生成第{episode_num}集脚本超时（180秒）")

            if error[0]:
                raise error[0]

            response = result[0]
            if response is None:
                raise Exception(f"LLM调用返回空结果（第{episode_num}集）")
        except TimeoutError as te:
            raise te
        except Exception as llm_error:
            raise Exception(f"LLM调用失败: {llm_error}")

        # 提取响应内容
        script_content = response
        if script_content is None:
            script_content = ""
        if isinstance(script_content, list):
            script_content = " ".join(str(item) for item in script_content)

        # 使用线程锁保护进度报告
        with lock:
            progress_dict['completed'] += 1
            total = progress_dict['total']
            completed = progress_dict['completed']
            print(f"📊 进度：{completed}/{total}集完成 ({completed*100//total}%)")

        return episode_num, script_content, None

    except Exception as e:
        # 使用线程锁保护错误报告
        with lock:
            progress_dict['failed'] += 1
            error_msg = str(e)
            # 截断过长的错误信息
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
            print(f"❌ 生成第{episode_num}集脚本失败: {error_msg}")

        return episode_num, None, str(e)


def generate_scripts_node(
    state: GenerateScriptsInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateScriptsOutput:
    """
    title: 生成剧集脚本
    desc: 根据大纲和集数范围生成剧集脚本
    integrations: 大语言模型, 对象存储
    """
    ctx = runtime.context

    # 获取集数范围
    start_episode = state.start_episode
    end_episode = state.end_episode
    series_name = state.series_name

    # 验证集数范围
    if start_episode > end_episode:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message=f"❌ 起始集数({start_episode})不能大于结束集数({end_episode})"
        )

    if end_episode - start_episode + 1 > 5:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message="❌ 单次生成最多5集脚本"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # Get outline from input parameter first, then from storage
    outline_content = state.outline_content or ""
    
    # 如果没有提供大纲内容，尝试从多个位置读取
    if not outline_content:
        print(f"📖 尝试从存储中读取大纲...")
        
        # 尝试1: 从outlines/目录读取
        try:
            result = storage.list_files(prefix="outlines/")
            if result.get("keys"):
                outline_key = result["keys"][-1]  # Get latest outline
                if outline_key:
                    print(f"✅ 从outlines/目录找到大纲: {outline_key}")
                    content = storage.read_file(file_key=outline_key)
                    outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
        except Exception as e:
            print(f"⚠️ 从outlines/目录读取大纲失败: {e}")
        
        # 尝试2: 从根目录读取（包含大纲的文件）
        if not outline_content:
            try:
                result = storage.list_files(prefix="")
                all_files = result.get("keys", [])
                # 查找包含"大纲"或"outline"的文件
                outline_files = [f for f in all_files if "大纲" in f or "outline" in f.lower()]
                if outline_files:
                    outline_key = outline_files[-1]  # Get latest outline file
                    print(f"✅ 从根目录找到大纲文件: {outline_key}")
                    content = storage.read_file(file_key=outline_key)
                    outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
            except Exception as e:
                print(f"⚠️ 从根目录读取大纲失败: {e}")
        
        # 尝试3: 从项目根目录的assets/目录读取（直接读取文件系统）
        if not outline_content:
            try:
                from pathlib import Path
                project_root = Path(os.getenv("COZE_WORKSPACE_PATH"))
                assets_dir = project_root / "assets"
                
                # 查找包含"大纲"或"outline"的文件
                outline_files = list(assets_dir.glob("*大纲*.md")) + list(assets_dir.glob("*outline*.md"))
                if outline_files:
                    outline_path = outline_files[-1]  # Get latest outline file
                    print(f"✅ 从assets目录找到大纲文件: {outline_path}")
                    with open(outline_path, 'r', encoding='utf-8') as f:
                        outline_content = f.read()
            except Exception as e:
                print(f"⚠️ 从assets目录读取大纲失败: {e}")
    
    # 如果还是没有大纲内容，给出详细错误提示
    if not outline_content:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message="❌ 未找到大纲，请先上传大纲文件或通过'加载大纲'功能加载大纲。"
            "\n提示：大纲文件可以命名为'短剧大纲.md'或'outline.md'，上传后会自动被读取。"
        )
    
    # 打印大纲长度用于调试
    print(f"✅ 成功读取大纲，长度: {len(outline_content)}字符")

    # 获取LLM Provider和配置
    llm_provider = get_llm_provider()

    # 读取提示词模板（SP和UP）
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_scripts_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        # 使用默认提示词
        sp = """你是一位专业的动画短剧编剧。请根据提供的大纲，生成指定集数的完整脚本内容。

每集脚本必须包含以下三个部分：

1. **简介**
   - 该集的主要角色（列出角色名称）
   - 该集的主要场景（列出场景名称和地点）
   - 该集的故事梗概

2. **脚本正文**
   - 场景描述（时间、地点、氛围）
   - 人物对话（对话内容、语气、动作）
   - 动作指导（人物动作、镜头运动）

3. **台本**
   - 配音内容
   - 音效说明
   - 背景音乐

输出格式要求：
- 每集单独生成一个完整的脚本
- 使用清晰的分段和标题
- 包含所有必要的场景和对话
- 保持风格一致性
- 每集长度约800-1200字"""
        up = """请根据以下大纲，生成第{{ episode_number }}集的完整动画短剧脚本：

大纲内容：
{{ outline_content }}

集数：第{{ episode_number }}集

请生成包含简介、脚本正文、台本三个部分的完整脚本内容。"""

    # 从LLM Provider获取当前提供商的配置
    provider_config = llm_provider.get_provider_config(llm_provider.enabled_provider)
    if not provider_config:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message=f"❌ LLM提供商 {llm_provider.enabled_provider} 不存在，请先配置LLM提供商"
        )

    llm_config = provider_config.get("config", {})
    model = llm_config.get("model", "")
    if not model:
        return GenerateScriptsOutput(
            script_files=[],
            scripts_content={},
            message="❌ 未配置模型，请先在LLM提供商中配置模型"
        )

    print(f"✅ 使用LLM提供商: {llm_provider.enabled_provider}, 模型: {model}")

    # 初始化存储和进度追踪
    scripts = {}
    script_files = {}

    # 进度追踪（线程安全）
    progress_lock = threading.Lock()
    progress_dict = {'total': end_episode - start_episode + 1, 'completed': 0, 'failed': 0}

    # 根据集数范围选择并发数
    total_episodes = end_episode - start_episode + 1
    if total_episodes <= 5:
        max_workers = 3  # 小批量使用3个并发
    elif total_episodes <= 10:
        max_workers = 5  # 中等批量使用5个并发
    else:
        max_workers = 5  # 大批量也使用5个并发（避免触发限流）

    print(f"🚀 开始并行生成 {total_episodes} 集脚本（并发数：{max_workers}）")

    # 使用线程池并行生成脚本
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # 提交所有任务
        futures = []
        for episode_num in range(start_episode, end_episode + 1):
            future = executor.submit(
                generate_single_episode,
                episode_num,
                outline_content,
                sp,
                up,
                llm_provider,
                llm_config,
                progress_lock,
                progress_dict
            )
            futures.append(future)

        # 收集结果（带超时保护，最长10分钟）
        import time
        start_time = time.time()
        timeout_seconds = 600  # 10分钟总超时

        completed_count = 0
        total_count = len(futures)
        
        for future in as_completed(futures):
            # 检查是否超时
            elapsed = time.time() - start_time
            if elapsed > timeout_seconds:
                print(f"⚠️ 脚本生成总超时（{timeout_seconds}秒），已生成 {completed_count}/{total_count} 集")
                break

            episode_num, script_content, error = future.result()

            if error:
                # 生成失败，跳过该集
                completed_count += 1
                continue

            # 保存脚本内容
            scripts[f"episode_{episode_num}"] = script_content

            # 生成易于识别的文件名（同时兼容S3和本地存储）
            # 使用英文文件名：EP{集数}.md，易于识别且符合S3规范
            original_name = f"EP{episode_num:02d}.md"
            # storage_key也使用相同的英文文件名
            storage_key = f"scripts/{original_name}"

            # 确保内容是UTF-8编码
            if isinstance(script_content, str):
                script_bytes = script_content.encode('utf-8')
            else:
                script_bytes = str(script_content).encode('utf-8')

            # 上传到对象存储
            file_key = storage.upload_file(
                file_content=script_bytes,
                file_name=storage_key,
                content_type="text/markdown",
                original_name=original_name
            )

            # 生成访问URL
            try:
                script_url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                script_files[f"episode_{episode_num}"] = script_url
            except Exception as url_error:
                script_files[f"episode_{episode_num}"] = ""
                print(f"生成脚本URL失败（第{episode_num}集）: {url_error}")

            completed_count += 1

    # 输出最终统计
    completed = progress_dict['completed']
    failed = progress_dict['failed']
    print(f"\n✅ 脚本生成完成！成功：{completed}集，失败：{failed}集\n")

    # 计算生成的集数
    episode_count = len([k for k in scripts.keys() if k.startswith('episode_')])

    return GenerateScriptsOutput(
        script_files=[File(url=url, file_type="document") for url in script_files.values()],
        scripts_content=scripts,
        message=f"✅ 成功生成 {episode_count} 集脚本（第{start_episode}集-第{end_episode}集）\n"
    )
