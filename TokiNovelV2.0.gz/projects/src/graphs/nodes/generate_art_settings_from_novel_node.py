"""Generate art settings from novel node for workflow 4 - Generate character and scene art settings from original novel"""
import os
import json
from typing import Dict, List, Any, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from langchain_core.messages import SystemMessage, HumanMessage
from jinja2 import Template
from utils.storage_adapter import StorageAdapter
from utils.file.file import File, FileOps
from utils.file_utils import get_safe_filename
from utils.llm.llm_provider import get_llm_provider
from graphs.state import GenerateArtSettingsFromNovelInput, GenerateArtSettingsFromNovelOutput


def generate_art_settings_from_novel_node(
    state: GenerateArtSettingsFromNovelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateArtSettingsFromNovelOutput:
    """
    title: 根据原著生成美术设定
    desc: 分析原著小说和生成的脚本，调用LLM生成角色和场景的美术设定文档
    integrations: 大语言模型, 对象存储
    """
    novel_content = state.novel_content
    scripts = state.scripts
    series_name = state.series_name

    if not novel_content and not scripts:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message="❌ 小说内容和脚本内容都为空，无法生成美术设定"
        )

    print(f"🎨 开始根据原著生成美术设定...")

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=False)
    except Exception as e:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 获取LLM Provider
    llm_provider = get_llm_provider()

    # 读取提示词模板（SP和UP）
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_art_settings_from_novel_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 读取LLM配置失败: {str(e)}"
        )

    # 从LLM Provider获取当前提供商的配置
    provider_config = llm_provider.get_provider_config(llm_provider.enabled_provider)
    if not provider_config:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ LLM提供商 {llm_provider.enabled_provider} 不存在，请先配置LLM提供商"
        )

    llm_config = provider_config.get("config", {})
    model = llm_config.get("model", "")
    if not model:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message="❌ 未配置模型，请先在LLM提供商中配置模型"
        )

    print(f"✅ 使用LLM提供商: {llm_provider.enabled_provider}, 模型: {model}")

    # 合并脚本内容
    all_scripts_text = ""
    if scripts:
        for key, content in scripts.items():
            all_scripts_text += f"\n\n=== {key} ===\n\n{content}"
    
    if not all_scripts_text:
        all_scripts_text = "（暂无脚本内容）"

    print(f"📖 已收集脚本内容，共{len(all_scripts_text)}字")

    # 调用LLM生成美术设定
    print(f"🤖 正在调用LLM生成美术设定...")

    try:
        # 使用jinja2模板渲染用户提示词
        up_tpl = Template(up)
        user_prompt_content = up_tpl.render({
            "novel_content": novel_content[:200000] if novel_content else "",  # 限制长度避免超限
            "scripts_content": all_scripts_text[:200000],
            "series_name": series_name
        })

        # 准备消息
        messages = [
            {"role": "system", "content": sp},
            {"role": "user", "content": user_prompt_content}
        ]

        # 调用LLM（带超时保护）
        import threading
        result = [None]
        error = [None]

        def call_llm():
            try:
                result[0] = llm_provider.call_llm_with_config(
                    llm_cfg=llm_config,
                    messages=messages
                )
            except Exception as e:
                error[0] = e

        # 创建线程
        thread = threading.Thread(target=call_llm)
        thread.daemon = True
        thread.start()

        # 等待线程完成，最多300秒（5分钟）
        thread.join(timeout=300)

        if thread.is_alive():
            # 超时，线程仍在运行
            raise TimeoutError("生成美术设定超时（300秒）")

        if error[0]:
            raise error[0]

        response = result[0]
        if response is None:
            raise Exception("LLM调用返回空结果")

        print(f"✅ LLM调用成功，响应长度：{len(response)}字")

        # 解析LLM响应，提取角色和场景美术设定
        character_art_content = ""
        scene_art_content = ""
        
        # 尝试分离角色和场景美术设定
        lines: List[str] = response.split('\n')
        current_section: Optional[str] = None
        character_lines: List[str] = []
        scene_lines: List[str] = []
        
        # 使用enumerate避免类型检查问题
        for idx, line in enumerate(lines):
            line_stripped = line.strip()
            
            # 确保line_stripped是字符串类型
            if not isinstance(line_stripped, str):
                continue
            
            # 检测章节标记
            if "角色" in line_stripped and "美术" in line_stripped:
                current_section = "character"
                continue
            elif "场景" in line_stripped and "美术" in line_stripped:
                current_section = "scene"
                continue
            elif line_stripped.startswith("#") and ("角色" in line_stripped or "场景" in line_stripped):
                if "角色" in line_stripped:
                    current_section = "character"
                elif "场景" in line_stripped:
                    current_section = "scene"
                continue
            
            # 根据当前章节添加到对应列表
            if current_section == "character":
                character_lines.append(line)
            elif current_section == "scene":
                scene_lines.append(line)
            else:
                # 如果没有明确章节，尝试根据内容判断
                # type: ignore  # 类型检查器误报，line_stripped确定是字符串
                if "角色" in line_stripped or "主角" in line_stripped or "配角" in line_stripped:
                    current_section = "character"
                    character_lines.append(line)
                elif "场景" in line_stripped or "环境" in line_stripped or "背景" in line_stripped:
                    current_section = "scene"
                    scene_lines.append(line)
        
        # 如果分离失败，使用整个响应
        if not character_lines and not scene_lines:
            # 尝试按常见的分割符分割
            if "角色美术设定" in response and "场景美术设定" in response:
                parts = response.split("场景美术设定", 1)
                character_art_content = parts[0].replace("角色美术设定", "").strip()
                scene_art_content = parts[1].strip()
            else:
                # 无法分离，将整个响应作为角色美术设定
                character_art_content = response
        else:
            character_art_content = "\n".join(character_lines)
            scene_art_content = "\n".join(scene_lines)
        
        # 确保内容不为空
        if not character_art_content.strip():
            character_art_content = "（未提取到角色美术设定）"
        if not scene_art_content.strip():
            scene_art_content = "（未提取到场景美术设定）"
        
        print(f"✅ 成功提取角色美术设定（{len(character_art_content)}字）和场景美术设定（{len(scene_art_content)}字）")

        # 保存角色美术设定文件
        safe_name = get_safe_filename(series_name)
        character_filename = f"{safe_name}_CharacterArt.md"
        character_file_key = f"art_settings/{character_filename}"
        
        character_url = storage.upload_file(
            file_content=character_art_content.encode('utf-8'),
            file_name=character_file_key,
            content_type="text/markdown",
            original_name=character_filename
        )
        print(f"✅ 已保存角色美术设定文件：{character_filename}")
        
        # 保存场景美术设定文件
        scene_filename = f"{safe_name}_SceneArt.md"
        scene_file_key = f"art_settings/{scene_filename}"
        
        scene_url = storage.upload_file(
            file_content=scene_art_content.encode('utf-8'),
            file_name=scene_file_key,
            content_type="text/markdown",
            original_name=scene_filename
        )
        print(f"✅ 已保存场景美术设定文件：{scene_filename}")

        # 提取角色列表（用于返回）
        character_settings = parse_character_settings(character_art_content)
        scene_settings = parse_scene_settings(scene_art_content)

        print(f"✅ 提取到{len(character_settings)}个角色设定和{len(scene_settings)}个场景设定")

        return GenerateArtSettingsFromNovelOutput(
            character_art_url=character_file_key,
            scene_art_url=scene_file_key,
            character_settings=character_settings,
            scene_settings=scene_settings,
            message=f"✅ 成功生成美术设定文档：角色设定{len(character_settings)}个，场景设定{len(scene_settings)}个"
        )

    except TimeoutError as te:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 生成美术设定超时: {str(te)}"
        )
    except Exception as e:
        return GenerateArtSettingsFromNovelOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 生成美术设定失败: {str(e)}"
        )


def parse_character_settings(content: str) -> List[Dict[str, Any]]:
    """
    从角色美术设定内容中提取角色列表

    Args:
        content: 角色美术设定文本

    Returns:
        角色列表
    """
    characters = []
    
    # 按章节或角色名分割
    lines = content.split('\n')
    current_character = None
    
    for line in lines:
        line_stripped = line.strip()
        
        # 检测角色名（以##开头或包含"角色"）
        if line_stripped.startswith('##') or line_stripped.startswith('#'):
            if current_character:
                characters.append(current_character)
            
            # 提取角色名
            character_name = line_stripped.lstrip('#').strip()
            if not character_name:
                character_name = f"角色{len(characters) + 1}"
            
            current_character = {
                "character_name": character_name,
                "description": ""
            }
        elif current_character:
            current_character["description"] += line + "\n"
    
    # 添加最后一个角色
    if current_character:
        characters.append(current_character)
    
    # 如果没有提取到角色，创建一个默认角色
    if not characters and content.strip():
        characters.append({
            "character_name": "角色",
            "description": content.strip()
        })
    
    return characters


def parse_scene_settings(content: str) -> List[Dict[str, Any]]:
    """
    从场景美术设定内容中提取场景列表

    Args:
        content: 场景美术设定文本

    Returns:
        场景列表
    """
    scenes = []
    
    # 按章节或场景名分割
    lines = content.split('\n')
    current_scene = None
    
    for line in lines:
        line_stripped = line.strip()
        
        # 检测场景名（以##开头或包含"场景"）
        if line_stripped.startswith('##') or line_stripped.startswith('#'):
            if current_scene:
                scenes.append(current_scene)
            
            # 提取场景名
            scene_name = line_stripped.lstrip('#').strip()
            if not scene_name:
                scene_name = f"场景{len(scenes) + 1}"
            
            current_scene = {
                "scene_name": scene_name,
                "description": ""
            }
        elif current_scene:
            current_scene["description"] += line + "\n"
    
    # 添加最后一个场景
    if current_scene:
        scenes.append(current_scene)
    
    # 如果没有提取到场景，创建一个默认场景
    if not scenes and content.strip():
        scenes.append({
            "scene_name": "场景",
            "description": content.strip()
        })
    
    return scenes
