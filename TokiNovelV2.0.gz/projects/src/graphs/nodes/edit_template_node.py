"""
编辑提示词模板节点（图形化版）
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import EditTemplateInput, EditTemplateOutput


def edit_template_node(
    state: EditTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> EditTemplateOutput:
    """
    title: 编辑模板
    desc: 在编辑框中修改模板内容
    integrations: 对象存储
    """
    ctx = runtime.context

    # 暂存编辑内容（不保存）
    edited_content = state.new_content
    template_name = state.template_name

    return EditTemplateOutput(
        template_name=template_name,
        edited_content=edited_content,
        message=f"✅ 编辑内容已更新（未保存），请点击保存按钮"
    )
