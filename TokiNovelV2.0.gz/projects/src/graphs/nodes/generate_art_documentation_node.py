"""Generate art documentation node - independent function with LLM support"""
import os
import json
import re
from typing import Dict, List, Any, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from langchain_core.messages import SystemMessage, HumanMessage
from jinja2 import Template
from utils.storage_adapter import StorageAdapter
from utils.file.file import File, FileOps
from utils.llm.llm_provider import get_llm_provider
from graphs.state import GenerateArtDocumentationInput, GenerateArtDocumentationOutput


def generate_art_documentation_node(
    state: GenerateArtDocumentationInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateArtDocumentationOutput:
    """
    title: 生成美术设定文档
    desc: 分析已生成的剧集文件，调用LLM模型生成角色和场景的美术设定文档
    integrations: 大语言模型, 对象存储
    """
    start_episode = state.start_episode
    end_episode = state.end_episode
    series_name = state.series_name

    # 初始化存储适配器（使用本地存储，确保能找到本地的EP文件）
    try:
        storage = StorageAdapter(use_s3=False)
    except Exception as e:
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    print(f"🎨 开始生成美术设定文档（第{start_episode}-{end_episode}集）...")

    # 获取LLM Provider
    llm_provider = get_llm_provider()

    # 读取提示词模板（SP和UP）
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_art_documentation_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 读取LLM配置失败: {str(e)}"
        )

    # 从LLM Provider获取当前提供商的配置
    provider_config = llm_provider.get_provider_config(llm_provider.enabled_provider)
    if not provider_config:
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ LLM提供商 {llm_provider.enabled_provider} 不存在，请先配置LLM提供商"
        )

    llm_config = provider_config.get("config", {})
    model = llm_config.get("model", "")
    if not model:
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message="❌ 未配置模型，请先在LLM提供商中配置模型"
        )

    print(f"✅ 使用LLM提供商: {llm_provider.enabled_provider}, 模型: {model}")

    # 从存储中读取剧集文件
    print(f"📖 正在读取剧集文件...")
    episodes_content = {}
    all_episodes_text = ""

    try:
        # 列出所有EP开头的文件
        result = storage.list_files(prefix="")
        episode_files = [key for key in result.get("keys", []) if key.endswith(".md") and ("EP" in key or "第" in key)]

        for episode_num in range(start_episode, end_episode + 1):
            # 查找对应的剧集文件
            episode_file_key = None
            for file_key in episode_files:
                if f"EP{episode_num:02d}" in file_key or f"第{episode_num}集" in file_key:
                    episode_file_key = file_key
                    break

            if not episode_file_key:
                print(f"⚠️ 未找到第{episode_num}集文件")
                continue

            # 读取剧集内容
            content = storage.read_file(file_key=episode_file_key)
            episode_text = content.decode('utf-8') if isinstance(content, bytes) else content
            episodes_content[f"EP{episode_num:02d}"] = episode_text
            all_episodes_text += f"\n\n=== 第{episode_num}集 ===\n\n{episode_text}"

        if not episodes_content:
            return GenerateArtDocumentationOutput(
                character_art_url="",
                scene_art_url="",
                character_settings=[],
                scene_settings=[],
                message=f"❌ 未找到剧集文件（第{start_episode}-{end_episode}集），请先生成剧集脚本"
            )

        print(f"✅ 成功读取{len(episodes_content)}集内容")
    except Exception as e:
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ 读取剧集文件失败: {str(e)}"
        )

    # 调用LLM生成美术设定
    print(f"🤖 正在调用LLM生成美术设定...")

    try:
        # 获取LLM Provider
        llm_provider = get_llm_provider()

        # 使用jinja2模板渲染用户提示词
        up_tpl = Template(up)
        user_prompt_content = up_tpl.render({
            "scripts_content": all_episodes_text,
            "series_name": series_name,
            "start_episode": start_episode,
            "end_episode": end_episode
        })

        # 将LangChain消息转换为OpenAI消息格式
        messages = [
            {"role": "system", "content": sp},
            {"role": "user", "content": user_prompt_content}
        ]

        # 调用LLM
        print(f"⏳ LLM请求中，模型: {model}, max_tokens: {llm_config.get('max_tokens', 16384)}")

        # 使用用户配置的LLM
        response_content = llm_provider.call_llm_with_config(
            llm_cfg=llm_config,
            messages=messages
        )

        print(f"✅ LLM响应成功，内容长度: {len(response_content)}字符")

    except Exception as e:
        print(f"❌ LLM调用失败: {e}")
        import traceback
        traceback.print_exc()
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[],
            scene_settings=[],
            message=f"❌ LLM调用失败: {str(e)}"
        )

    # 解析LLM返回的JSON
    art_data = parse_llm_response(response_content)
    characters = art_data.get("characters", [])
    scenes = art_data.get("scenes", [])

    print(f"✅ 提取到{len(characters)}个角色，{len(scenes)}个场景")

    # 生成美术设定文档
    print(f"📝 正在生成美术设定文档...")

    character_art_content = generate_character_document(characters, series_name, start_episode, end_episode)
    scene_art_content = generate_scene_document(scenes, series_name, start_episode, end_episode)

    # 保存美术设定文档到存储
    print(f"💾 正在保存美术设定文档...")
    character_art_url = ""
    scene_art_url = ""

    try:
        # 保存角色美术设定（使用直观的文件名）
        char_filename = f"角色美术设定_EP{start_episode}-{end_episode}.md"
        char_file_key = f"art_settings/{char_filename}"
        char_url = storage.upload_file(
            file_content=character_art_content.encode('utf-8'),
            file_name=char_file_key,
            content_type="text/markdown",
            original_name=char_filename
        )
        character_art_url = char_url

        # 保存场景美术设定（使用直观的文件名）
        scene_filename = f"场景美术设定_EP{start_episode}-{end_episode}.md"
        scene_file_key = f"art_settings/{scene_filename}"
        scene_url = storage.upload_file(
            file_content=scene_art_content.encode('utf-8'),
            file_name=scene_file_key,
            content_type="text/markdown",
            original_name=scene_filename
        )
        scene_art_url = scene_url

        print(f"✅ 美术设定文档保存成功！")
    except Exception as e:
        print(f"❌ 保存美术设定文档失败: {e}")
        import traceback
        traceback.print_exc()
        return GenerateArtDocumentationOutput(
            character_art_url="",
            scene_art_url="",
            character_settings=[{"name": char.get("name", ""), "setting": char.get("setting", ""), "prompt": char.get("prompt", "")} for char in characters],
            scene_settings=[{"name": scene.get("name", ""), "setting": scene.get("setting", ""), "prompt": scene.get("prompt", "")} for scene in scenes],
            message=f"❌ 保存美术设定文档失败: {str(e)}"
        )

    # 准备输出
    character_settings_list = [{"name": char.get("name", ""), "setting": char.get("setting", ""), "prompt": char.get("prompt", "")} for char in characters]
    scene_settings_list = [{"name": scene.get("name", ""), "setting": scene.get("setting", ""), "prompt": scene.get("prompt", "")} for scene in scenes]

    success_message = f"""✅ 美术设定文档生成成功！

📄 角色美术设定：
- 文件名：{char_filename}
- URL：{character_art_url or '仅限本地访问'}
- 角色数量：{len(character_settings_list)}

📄 场景美术设定：
- 文件名：{scene_filename}
- URL：{scene_art_url or '仅限本地访问'}
- 场景数量：{len(scene_settings_list)}"""

    return GenerateArtDocumentationOutput(
        character_art_url=character_art_url,
        scene_art_url=scene_art_url,
        character_settings=character_settings_list,
        scene_settings=scene_settings_list,
        message=success_message
    )


def parse_llm_response(response: str) -> Dict[str, Any]:
    """解析LLM返回的JSON响应"""
    # 尝试提取JSON部分
    try:
        # 移除可能的Markdown代码块标记
        response = response.strip()
        if response.startswith("```"):
            # 移除开头的 ```
            response = response[3:]
            # 移除语言标识（如 json）
            if response.startswith("json"):
                response = response[4:]
            # 移除结尾的 ```
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

        # 解析JSON
        data = json.loads(response)
        return data
    except json.JSONDecodeError as e:
        print(f"❌ JSON解析失败: {e}")
        print(f"响应内容: {response[:500]}...")
        # 尝试提取JSON部分（可能包含其他文本）
        json_start = response.find("{")
        json_end = response.rfind("}") + 1
        if json_start >= 0 and json_end > json_start:
            try:
                json_str = response[json_start:json_end]
                data = json.loads(json_str)
                return data
            except json.JSONDecodeError:
                pass

        return {"characters": [], "scenes": []}


def generate_character_document(characters: List[Dict[str, Any]], series_name: str, start_episode: int, end_episode: int) -> str:
    """生成角色美术设定文档"""
    content = f"# {series_name} 角色美术设定（第{start_episode}-{end_episode}集）\n\n"
    content += "## 说明\n\n"
    content += "本文件根据剧集脚本内容，使用大语言模型分析并生成每个角色的详细美术设定和文生图提示词。\n\n"

    if not characters:
        content += "## 角色美术设定\n\n"
        content += "未检测到角色信息。\n"
        return content

    content += "## 角色美术设定\n\n"

    for char in characters:
        name = char.get("name", "未知角色")
        setting = char.get("setting", "")
        prompt = char.get("prompt", "")

        content += f"### {name}\n\n"
        if setting:
            content += f"{setting}\n\n"
        else:
            content += f"暂无详细设定\n\n"

        if prompt:
            content += f"**文生图提示词**：{prompt}\n\n"

        content += "---\n\n"

    return content


def generate_scene_document(scenes: List[Dict[str, Any]], series_name: str, start_episode: int, end_episode: int) -> str:
    """生成场景美术设定文档"""
    content = f"# {series_name} 场景美术设定（第{start_episode}-{end_episode}集）\n\n"
    content += "## 说明\n\n"
    content += "本文件根据剧集脚本内容，使用大语言模型分析并生成每个场景的详细美术设定和文生图提示词。\n\n"

    if not scenes:
        content += "## 场景美术设定\n\n"
        content += "未检测到场景信息。\n"
        return content

    content += "## 场景美术设定\n\n"

    for scene in scenes:
        name = scene.get("name", "未知场景")
        setting = scene.get("setting", "")
        prompt = scene.get("prompt", "")

        content += f"### {name}\n\n"
        if setting:
            content += f"{setting}\n\n"
        else:
            content += f"暂无详细设定\n\n"

        if prompt:
            content += f"**文生图提示词**：{prompt}\n\n"

        content += "---\n\n"

    return content
