"""Load novel node for workflow 2"""
from typing import Optional, List, Dict, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file.file import File
from utils.file.file import FileOps
from graphs.state import LoadNovelInput, LoadNovelOutput


def load_novel_node(
    state: LoadNovelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> LoadNovelOutput:
    """
    title: 加载小说
    desc: 根据小说名称从存储中加载小说内容
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return LoadNovelOutput(
            novel_name="",
            novel_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    novel_name = state.novel_name

    if not novel_name:
        return LoadNovelOutput(
            novel_name="",
            novel_content="",
            message="❌ 小说名称不能为空"
        )

    try:
        # 列出novels文件夹下所有文件
        result = storage.list_files(prefix="novels/")
        novels = []
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")
                display_name = original_name if original_name else file_key.split("/")[-1]

                # 查找匹配的小说
                if display_name == novel_name or file_key.split("/")[-1] == novel_name:
                    novels.append({"name": display_name, "url": storage.generate_presigned_url(key=file_key, expire_time=3600), "key": file_key})
            except Exception as e:
                print(f"处理文件信息失败: {e}")

        if not novels:
            return LoadNovelOutput(
                novel_name="",
                novel_content="",
                message=f"❌ 未找到小说：{novel_name}"
            )

        # 读取小说内容
        novel_url = novels[0]["url"]
        novel_file = File(url=novel_url, file_type="document")
        novel_content = FileOps.extract_text(novel_file)

        return LoadNovelOutput(
            novel_name=novel_name,
            novel_content=novel_content,
            message=f"✅ 成功加载小说：{novel_name}"
        )

    except Exception as e:
        return LoadNovelOutput(
            novel_name=novel_name,
            novel_content="",
            message=f"❌ 加载小说失败: {str(e)}"
        )
