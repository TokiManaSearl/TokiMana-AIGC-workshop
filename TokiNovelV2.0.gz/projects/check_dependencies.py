#!/usr/bin/env python
"""
Dependency Check Script for Windows
检查所有必要的依赖是否正确安装
"""

import sys
from importlib import import_module

# 定义需要检查的包及其重要性
REQUIRED_PACKAGES = {
    # 核心框架
    "langchain": "必须",
    "langchain_core": "必须",
    "langchain_openai": "必须",
    "langgraph": "必须",
    "langgraph_checkpoint": "必须",
    "langsmith": "必须",

    # Web框架
    "flask": "必须",
    "fastapi": "必须",
    "uvicorn": "必须",

    # 数据处理
    "pandas": "必须",
    "numpy": "必须",
    "openpyxl": "必须",

    # HTTP客户端
    "httpx": "必须",
    "requests": "必须",

    # 数据验证
    "pydantic": "必须",
    "pydantic_core": "必须",

    # Coze SDK
    "coze_coding_dev_sdk": "必须",
    "coze_coding_utils": "必须",
    "cozeloop": "必须",

    # OpenAI
    "openai": "必须",
    "tiktoken": "建议",

    # 文档处理
    "beautifulsoup4": "建议",
    "lxml": "建议",

    # 图像处理
    "cv2": "建议",  # opencv-python
    "PIL": "建议",  # pillow

    # 其他工具
    "jinja2": "必须",
    "yaml": "建议",  # PyYAML
}

def check_package(name):
    """检查包是否可以导入"""
    try:
        module = import_module(name)
        version = getattr(module, "__version__", "未知版本")
        return True, version
    except ImportError:
        return False, None

def main():
    print("=" * 80)
    print("依赖检查工具 (Dependency Check Tool)")
    print("=" * 80)
    print()

    # 检查 Python 版本
    print(f"Python 版本: {sys.version}")
    print()

    # 分类检查
    missing_required = []
    missing_optional = []
    installed_count = 0
    total_count = len(REQUIRED_PACKAGES)

    print("检查依赖包...")
    print("-" * 80)

    for package_name, importance in REQUIRED_PACKAGES.items():
        success, version = check_package(package_name)

        status_icon = "✅" if success else "❌"
        importance_marker = "[必须]" if importance == "必须" else "[建议]"

        if success:
            print(f"{status_icon} {package_name:30s} {version:20s} {importance_marker}")
            installed_count += 1
        else:
            print(f"{status_icon} {package_name:30s} {'未安装':20s} {importance_marker}")
            if importance == "必须":
                missing_required.append(package_name)
            else:
                missing_optional.append(package_name)

    print("-" * 80)
    print()
    print(f"安装进度: {installed_count}/{total_count} ({installed_count*100//total_count}%)")
    print()

    # 总结
    if not missing_required and not missing_optional:
        print("✅ 所有依赖都已正确安装！")
        print()
        print("你现在可以启动服务器了：")
        print("  run_server.bat")
        print()
        return 0

    if missing_required:
        print("❌ 缺少必须的依赖包：")
        for package in missing_required:
            print(f"  - {package}")
        print()
        print("请运行以下命令安装必须的依赖：")
        print("  python -m pip install -i https://mirrors.aliyun.com/pypi/simple --trusted-host mirrors.aliyun.com")
        print(f"  {' '.join(missing_required)}")
        print()

    if missing_optional:
        print("⚠️  缺少建议的依赖包（不影响基本功能）：")
        for package in missing_optional:
            print(f"  - {package}")
        print()

    # 建议
    if missing_required:
        print("建议解决方案：")
        print("1. 查看 FIX_INSTALLATION.md 获取详细帮助")
        print("2. 运行 run_server.bat 自动安装")
        print("3. 如果使用 Python 3.14，建议降级到 3.11（查看 PYTHON314_FIX.md）")
        print()
        return 1
    else:
        print("✅ 核心依赖已安装，可以启动服务器！")
        print("  部分可选功能可能受限")
        print()
        print("启动服务器：")
        print("  run_server.bat")
        print()
        return 0

if __name__ == "__main__":
    sys.exit(main())
