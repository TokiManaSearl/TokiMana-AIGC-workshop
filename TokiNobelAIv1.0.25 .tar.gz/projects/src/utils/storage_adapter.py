"""
存储适配器
提供统一的存储接口，自动在S3存储和本地存储之间切换
"""
import os
import logging
from typing import Optional
from coze_coding_dev_sdk.s3 import S3SyncStorage
from utils.local_storage import LocalStorageSimulator, get_local_storage


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)


class StorageAdapter:
    """存储适配器，支持S3存储和本地存储自动切换"""
    
    def __init__(self, use_s3: bool = None):
        # 如果环境变量 FORCE_LOCAL_STORAGE=True，强制使用本地存储
        force_local = os.getenv("FORCE_LOCAL_STORAGE", "").lower() in ("true", "1", "yes")
        
        if use_s3 is None:
            use_s3 = not force_local
        else:
            use_s3 = use_s3 and not force_local
        
        self.use_s3 = use_s3
        self.s3_storage: Optional[S3SyncStorage] = None
        self.local_storage: Optional[LocalStorageSimulator] = None
        
        if self.use_s3:
            try:
                self.s3_storage = S3SyncStorage(
                    endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
                    access_key="",
                    secret_key="",
                    bucket_name=os.getenv("COZE_BUCKET_NAME"),
                    region="cn-beijing",
                )
                logger.info("S3存储初始化成功")
            except Exception as e:
                logger.warning(f"S3存储初始化失败，降级到本地存储: {e}")
                self.use_s3 = False
                self.local_storage = get_local_storage()
        else:
            self.local_storage = get_local_storage()
            logger.info("使用本地存储")
    
    def upload_file(self, file_content: bytes, file_name: str, content_type: str = "text/plain", original_name: str = "") -> str:
        """上传文件"""
        logger.debug(f"开始上传文件: {file_name}, 大小: {len(file_content)}, 原始文件名: {original_name}")
        
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.upload_file(
                    file_content=file_content,
                    file_name=file_name,
                    content_type=content_type
                )
                logger.info(f"S3上传成功: {file_name}, 返回: {result}")
                
                # 同时备份到本地存储，以防S3不可靠
                try:
                    if self.local_storage is None:
                        self.local_storage = get_local_storage()
                    self.local_storage.upload_file(
                        file_content=file_content,
                        file_name=file_name,
                        content_type=content_type,
                        original_name=original_name
                    )
                    logger.info(f"本地存储备份成功: {file_name}")
                except Exception as e:
                    logger.warning(f"本地存储备份失败（不影响S3上传）: {e}")
                
                return result
            except Exception as e:
                logger.warning(f"S3上传失败，降级到本地存储: {e}")
                if self.local_storage is None:
                    self.local_storage = get_local_storage()
                result = self.local_storage.upload_file(
                    file_content=file_content,
                    file_name=file_name,
                    content_type=content_type,
                    original_name=original_name
                )
                logger.info(f"本地存储上传成功: {file_name}")
                return result
        else:
            result = self.local_storage.upload_file(
                file_content=file_content,
                file_name=file_name,
                content_type=content_type,
                original_name=original_name
            )
            logger.info(f"本地存储上传成功: {file_name}")
            return result
    
    def read_file(self, file_key: str) -> bytes:
        """读取文件"""
        logger.debug(f"开始读取文件: {file_key}")
        
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.read_file(file_key=file_key)
                logger.info(f"S3读取成功: {file_key}, 大小: {len(result)}")
                return result
            except Exception as e:
                logger.warning(f"S3读取失败，尝试本地存储: {e}")
                if self.local_storage is None:
                    self.local_storage = get_local_storage()
                result = self.local_storage.read_file(file_key=file_key)
                logger.info(f"本地存储读取成功: {file_key}, 大小: {len(result)}")
                return result
        else:
            result = self.local_storage.read_file(file_key=file_key)
            logger.info(f"本地存储读取成功: {file_key}, 大小: {len(result)}")
            return result
    
    def delete_file(self, file_key: str) -> bool:
        """删除文件"""
        logger.debug(f"开始删除文件: {file_key}")
        
        success = False
        
        # 同时尝试删除S3和本地存储
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.delete_file(file_key=file_key)
                logger.info(f"S3删除成功: {file_key}")
                success = result
            except Exception as e:
                logger.warning(f"S3删除失败: {e}")
        
        # 同时删除本地存储（需要移除bucket前缀）
        try:
            if self.local_storage is None:
                self.local_storage = get_local_storage()
            # 移除可能的bucket前缀
            local_key = self._strip_bucket_prefix(file_key)
            logger.debug(f"尝试删除本地文件: {local_key}")
            result = self.local_storage.delete_file(file_key=local_key)
            logger.info(f"本地存储删除: {local_key}, 结果: {result}")
            success = success or result
        except Exception as e:
            logger.warning(f"本地存储删除失败: {e}")
            logger.exception(e)
        
        logger.info(f"删除文件最终结果: {file_key}, success: {success}")
        return success
    
    def file_exists(self, file_key: str) -> bool:
        """检查文件是否存在"""
        logger.debug(f"检查文件是否存在: {file_key}")
        
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.file_exists(file_key=file_key)
                logger.info(f"S3检查文件存在: {file_key}, 结果: {result}")
                return result
            except Exception as e:
                logger.warning(f"S3检查失败，尝试本地存储: {e}")
                if self.local_storage is None:
                    self.local_storage = get_local_storage()
                result = self.local_storage.file_exists(file_key=file_key)
                logger.info(f"本地存储检查文件存在: {file_key}, 结果: {result}")
                return result
        else:
            result = self.local_storage.file_exists(file_key=file_key)
            logger.info(f"本地存储检查文件存在: {file_key}, 结果: {result}")
            return result
    
    def list_files(self, prefix: str = "", max_keys: int = 1000) -> dict:
        """列出文件"""
        logger.debug(f"开始列出文件, prefix: {prefix}, max_keys: {max_keys}")
        
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.list_files(prefix=prefix, max_keys=max_keys)
                logger.info(f"S3列表成功, 找到 {len(result.get('keys', []))} 个文件")
                # 如果S3返回空列表，尝试本地存储
                if not result.get("keys"):
                    logger.warning(f"S3列表为空，尝试本地存储")
                    if self.local_storage is None:
                        self.local_storage = get_local_storage()
                    local_result = self.local_storage.list_files(prefix=prefix, max_keys=max_keys)
                    logger.info(f"本地存储列表成功, 找到 {len(local_result.get('keys', []))} 个文件")
                    return local_result
                return result
            except Exception as e:
                logger.warning(f"S3列表失败，降级到本地存储: {e}")
                if self.local_storage is None:
                    self.local_storage = get_local_storage()
                result = self.local_storage.list_files(prefix=prefix, max_keys=max_keys)
                logger.info(f"本地存储列表成功, 找到 {len(result.get('keys', []))} 个文件")
                return result
        else:
            result = self.local_storage.list_files(prefix=prefix, max_keys=max_keys)
            logger.info(f"本地存储列表成功, 找到 {len(result.get('keys', []))} 个文件")
            return result
    
    def _strip_bucket_prefix(self, file_key: str) -> str:
        """移除S3 bucket前缀（如果存在）"""
        # S3可能返回类似 "coze_storage_7601072529431855158/files/file_xxx.md" 的key
        # 我们需要移除 "coze_storage_7601072529431855158/" 前缀
        
        # 获取bucket名称（S3 key的前部分，直到第一个斜杠）
        parts = file_key.split("/", 1)
        if len(parts) > 1:
            # 如果key格式是 "bucket_name/path/to/file"，则移除bucket_name前缀
            logger.debug(f"移除bucket前缀: {file_key} -> {parts[1]}")
            return parts[1]
        
        logger.debug(f"无需移除bucket前缀: {file_key}")
        return file_key
    
    def get_file_metadata(self, file_key: str) -> dict:
        """获取文件元数据"""
        logger.debug(f"获取文件元数据: {file_key}")

        # 优先从本地存储读取元数据（因为本地存储保存了original_name）
        if self.local_storage:
            try:
                # 先尝试直接使用file_key获取元数据
                metadata = self.local_storage.get_file_metadata(file_key)
                if metadata:
                    logger.debug(f"从本地存储读取元数据成功: {file_key}")
                    return metadata
            except Exception as e:
                logger.warning(f"从本地存储读取元数据失败: {e}")

            # 如果失败，尝试移除可能的bucket前缀
            local_key = self._strip_bucket_prefix(file_key)
            try:
                metadata = self.local_storage.get_file_metadata(local_key)
                if metadata:
                    logger.debug(f"从本地存储读取元数据成功（移除bucket前缀）: {file_key} -> {local_key}")
                    return metadata
            except Exception as e:
                logger.warning(f"从本地存储读取元数据失败（移除bucket前缀）: {e}")

        # 如果本地存储没有，尝试从S3读取（但S3可能不支持元数据）
        if self.use_s3 and self.s3_storage:
            try:
                # 检查S3是否有get_file_metadata方法
                if hasattr(self.s3_storage, 'get_file_metadata'):
                    metadata = self.s3_storage.get_file_metadata(file_key)
                    if metadata:
                        logger.debug(f"从S3读取元数据成功: {file_key}")
                        return metadata
            except Exception as e:
                logger.warning(f"从S3读取元数据失败: {e}")

        # 都没有，返回空字典
        logger.debug(f"无法获取文件元数据: {file_key}")
        return {}
    
    def generate_presigned_url(self, key: str, expire_time: int = 3600) -> str:
        """生成访问URL"""
        logger.debug(f"生成访问URL: {key}, 过期时间: {expire_time}")
        
        if self.use_s3 and self.s3_storage:
            try:
                result = self.s3_storage.generate_presigned_url(key=key, expire_time=expire_time)
                logger.info(f"S3生成URL成功: {key}")
                return result
            except Exception as e:
                logger.warning(f"S3生成URL失败，使用本地路径: {e}")
                if self.local_storage is None:
                    self.local_storage = get_local_storage()
                result = self.local_storage.generate_presigned_url(key=key, expire_time=expire_time)
                logger.info(f"本地路径: {result}")
                return result
        else:
            result = self.local_storage.generate_presigned_url(key=key, expire_time=expire_time)
            logger.info(f"本地路径: {result}")
            return result
