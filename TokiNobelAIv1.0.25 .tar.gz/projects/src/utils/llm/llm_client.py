"""
LLM客户端包装器
为现有的LLMClient提供新的LLM提供商支持
"""
from typing import Optional, Dict, Any, List, Union
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage
from utils.llm.llm_provider import get_llm_provider


class LLMClient:
    """
    LLM客户端包装器
    兼容现有的LLMClient接口，底层使用新的LLM提供商管理器
    """

    def __init__(self, ctx: Optional[Any] = None):
        """
        初始化LLM客户端

        Args:
            ctx: 上下文对象（兼容性参数，暂不使用）
        """
        self.llm_provider = get_llm_provider()
        self.ctx = ctx

    def invoke(
        self,
        messages: List[BaseMessage],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        max_completion_tokens: Optional[int] = None,
        thinking: Optional[str] = "disabled",
        **kwargs
    ) -> Any:
        """
        调用LLM

        Args:
            messages: 消息列表
            model: 模型名称
            temperature: 温度参数
            top_p: Top P参数
            max_completion_tokens: 最大完成token数
            thinking: 思考模式（暂不支持）
            **kwargs: 其他参数

        Returns:
            LLM响应对象
        """
        # 转换消息格式
        api_messages = []
        for msg in messages:
            if isinstance(msg, SystemMessage):
                api_messages.append({"role": "system", "content": msg.content})
            elif isinstance(msg, HumanMessage):
                api_messages.append({"role": "user", "content": msg.content})
            elif isinstance(msg, AIMessage):
                api_messages.append({"role": "assistant", "content": msg.content})
            else:
                # 未知消息类型，作为user处理
                api_messages.append({"role": "user", "content": str(msg.content)})

        # 调用LLM
        response_text = self.llm_provider.call_llm(
            messages=api_messages,
            model=model,
            temperature=temperature,
            max_tokens=max_completion_tokens,
            top_p=top_p,
            **kwargs
        )

        # 创建响应对象
        class Response:
            def __init__(self, content: str):
                self.content = content

        return Response(content=response_text)


def create_llm_client(ctx: Optional[Any] = None) -> LLMClient:
    """
    创建LLM客户端实例

    Args:
        ctx: 上下文对象

    Returns:
        LLMClient实例
    """
    return LLMClient(ctx=ctx)
