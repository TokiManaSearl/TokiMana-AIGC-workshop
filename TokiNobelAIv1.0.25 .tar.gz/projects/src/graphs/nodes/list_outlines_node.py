"""List outlines node for workflow 2 and 3"""
import os
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file.file import FileOps
from graphs.state import ListOutlinesInput, ListOutlinesOutput


def list_outlines_node(
    state: ListOutlinesInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ListOutlinesOutput:
    """
    title: List Outlines
    desc: List all outline files (files ending with _outline.md)
    integrations: 对象存储
    """
    ctx = runtime.context

    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return ListOutlinesOutput(
            outlines=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    outlines = []
    try:
        # List files from storage
        result = storage.list_files(prefix="")
        
        for file_key in result.get("keys", []):
            # 过滤掉空key、bucket前缀（以/结尾）和空白key
            if not file_key or not file_key.strip() or file_key.endswith("/"):
                continue
                
            # 过滤：只保留大纲文件
            # 规则1: 文件名包含"outline"（不区分大小写）
            # 规则2: 或者文件名以"_outline.md"结尾
            file_name_lower = file_key.lower()
            if "outline" not in file_name_lower:
                continue
                
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")

                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1]

                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                outlines.append({"name": display_name, "url": url})
            except Exception as e:
                print(f"处理大纲文件信息失败: {e}")
    except Exception as e:
        return ListOutlinesOutput(
            outlines=[],
            message=f"❌ 列出大纲文件失败: {str(e)}"
        )

    if not outlines:
        return ListOutlinesOutput(
            outlines=[],
            message="📭 暂无大纲文件，请先在工作流2中生成并保存大纲"
        )

    return ListOutlinesOutput(
        outlines=outlines,
        message=f"✅ 共找到 {len(outlines)} 个大纲文件"
    )
