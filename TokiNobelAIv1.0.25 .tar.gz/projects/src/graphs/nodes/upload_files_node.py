"""上传文件包节点（图形化版）"""
import os
import re
import requests
from urllib.parse import urlparse, unquote
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import UploadFilesInput, UploadFilesOutput
from utils.file.file import File, FileOps
from utils.file_utils import get_safe_filename


def extract_filename_from_url(url: str) -> str:
    """
    从URL中提取干净的文件名，移除签名等查询参数

    Args:
        url: 文件URL（可能包含签名参数）

    Returns:
        干净的文件名
    """
    # 解析URL，移除查询参数
    parsed = urlparse(url)
    # 获取路径部分
    path = parsed.path
    # 提取文件名
    filename = path.split("/")[-1]
    # URL解码（处理中文等特殊字符）
    filename = unquote(filename)
    return filename


def extract_filename_from_headers(url: str) -> str:
    """
    从HTTP响应头的Content-Disposition中提取原始文件名

    Args:
        url: 文件URL

    Returns:
        原始文件名，如果无法提取则返回空字符串
    """
    try:
        # 发送HEAD请求获取响应头（不下载文件内容）
        response = requests.head(url, timeout=30, allow_redirects=True)
        response.raise_for_status()

        # 检查Content-Disposition响应头
        content_disposition = response.headers.get('Content-Disposition', '')
        if not content_disposition:
            return ""

        # 解析Content-Disposition响应头
        # 格式1: Content-Disposition: attachment; filename="filename.ext"
        # 格式2: Content-Disposition: attachment; filename*=UTF-8''filename.ext
        match = re.search(r'filename\*?=(?:UTF-8\'\')?([^;]+)', content_disposition, re.IGNORECASE)
        if match:
            filename = match.group(1).strip('"\' ')
            return unquote(filename)

        return ""
    except Exception as e:
        # 如果获取失败，返回空字符串
        print(f"从响应头提取文件名失败: {e}")
        return ""


def upload_files_node(
    state: UploadFilesInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> UploadFilesOutput:
    """
    title: 上传文件
    desc: 点击上传按钮，上传多个文件（大纲.md、Excel模板等）
    integrations: 对象存储
    """
    ctx = runtime.context
    
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return UploadFilesOutput(
            files=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    try:
        uploaded_files = []
        
        # 遍历上传的文件列表
        for file in state.files:
            if not file:
                continue

            # 判断文件类型
            file_url = file.url
            file_ext = file_url.split(".")[-1].lower() if "." in file_url else ""
            
            if file_ext in ["md", "txt"]:
                # 文本文件 - 读取内容
                content = FileOps.extract_text(file)
                category = "outline"
                storage_prefix = "outlines/"
                content_type = "text/markdown" if file_ext == "md" else "text/plain"
                file_data = content.encode('utf-8')
            elif file_ext in ["xlsx", "xls"]:
                # Excel文件 - 读取二进制内容
                import requests
                response = requests.get(file_url)
                file_data = response.content
                category = "excel"
                storage_prefix = "excel/"
                content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if file_ext == "xlsx" else "application/vnd.ms-excel"
            else:
                # 其他文件 - 作为二进制处理
                import requests
                response = requests.get(file_url)
                file_data = response.content
                category = "file"
                storage_prefix = "files/"
                content_type = "application/octet-stream"
            
            # 提取原始文件名（按优先级）
            original_filename = ""

            # 优先级1: 从HTTP响应头中提取原始文件名
            filename_from_header = extract_filename_from_headers(file_url)
            if filename_from_header:
                original_filename = filename_from_header
            else:
                # 优先级2: 从URL路径中提取文件名（清理签名参数）
                original_filename = extract_filename_from_url(file_url)

            # 生成安全的文件名（使用时间戳，每次上传生成不同的key）
            safe_filename, file_id = get_safe_filename(
                original_filename,
                category=category,
                use_timestamp=True
            )
            
            # 构建存储key
            storage_key = f"{storage_prefix}{safe_filename}"
            
            # 上传到存储（传递原始文件名）
            file_key = storage.upload_file(
                file_content=file_data,
                file_name=storage_key,
                content_type=content_type,
                original_name=original_filename
            )
            
            uploaded_files.append({
                "name": storage_key,
                "original_name": original_filename,
                "safe_name": safe_filename,
                "url": storage.generate_presigned_url(key=file_key, expire_time=3600),
                "category": category
            })
        
        # 列出所有已上传的文件
        result = storage.list_files(prefix="")
        files_list = []
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")

                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1]

                # 生成访问URL
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                files_list.append({
                    "name": display_name,
                    "url": url,
                    "key": file_key
                })
            except Exception as e:
                print(f"处理文件信息失败: {e}")
        
        # 返回输出
        return UploadFilesOutput(
            files=files_list,
            message=f"✅ 成功上传 {len(uploaded_files)} 个文件"
        )
        
    except Exception as e:
        return UploadFilesOutput(
            files=[],
            message=f"❌ 上传文件到对象存储失败: {str(e)}"
        )
