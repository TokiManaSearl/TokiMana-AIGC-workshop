"""
选择提示词模板节点（图形化版）
"""
from pathlib import Path
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import SelectTemplateInput, SelectTemplateOutput


def select_template_node(
    state: SelectTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SelectTemplateOutput:
    """
    title: 选择模板
    desc: 从下拉框选择一个模板，查看内容
    """
    ctx = runtime.context
    
    # 处理 template_name：可能包含路径，需要提取文件名
    template_name = state.template_name
    
    # 如果包含路径分隔符，提取文件名
    if "\\" in template_name or "/" in template_name:
        template_name = Path(template_name).name
    
    if not template_name:
        return SelectTemplateOutput(
            template_name="",
            template_content="",
            message="❌ 请先从下拉框选择模板"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return SelectTemplateOutput(
            template_name="",
            template_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 列出所有模板
    result = storage.list_files(prefix="templates/")

    # 根据原始文件名查找文件
    selected_file_key = None
    for file_key in result.get("keys", []):
        try:
            # 标准化文件键（处理Windows路径的反斜杠问题）
            normalized_key = file_key.replace("\\", "/")
            
            # 获取文件元数据
            metadata = storage.get_file_metadata(normalized_key)
            original_name = metadata.get("original_name", "")
            display_name = original_name if original_name else Path(file_key).name
            
            # 匹配原始文件名或显示名称
            if original_name == template_name or display_name == template_name or Path(file_key).name == template_name:
                selected_file_key = file_key
                print(f"[DEBUG] 找到匹配的模板: {file_key}")
                break
        except Exception as e:
            print(f"获取文件元数据失败: {e}")

    if not selected_file_key:
        print(f"[DEBUG] 未找到模板: {template_name}")
        print(f"[DEBUG] 可用的文件: {result.get('keys', [])}")
        return SelectTemplateOutput(
            template_name="",
            template_content="",
            message=f"❌ 未找到模板：{template_name}"
        )

    # 读取文件内容
    try:
        file_bytes = storage.read_file(selected_file_key)
        content = file_bytes.decode('utf-8')

        return SelectTemplateOutput(
            template_name=template_name,
            template_content=content,
            message=f"✅ 已选择模板：{template_name}"
        )
    except Exception as e:
        return SelectTemplateOutput(
            template_name="",
            template_content="",
            message=f"❌ 读取模板内容失败: {str(e)}"
        )
