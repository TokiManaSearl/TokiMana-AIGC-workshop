"""Clear all files node for workflow 3"""
from typing import Dict, Any
import time
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import ClearAllFilesInput, ClearAllFilesOutput


def clear_all_files_node(
    state: ClearAllFilesInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ClearAllFilesOutput:
    """
    title: Clear All Files
    desc: Delete all files from storage (use with caution!)
    integrations: 对象存储
    """
    ctx = runtime.context

    # 调试：打印 state 的所有属性
    print(f"[DEBUG] state type: {type(state)}")
    print(f"[DEBUG] state dict: {state.model_dump()}")
    print(f"[DEBUG] delete_all = {state.delete_all} (type: {type(state.delete_all)})")
    print(f"[DEBUG] delete_scripts = {state.delete_scripts}")
    print(f"[DEBUG] delete_outlines = {state.delete_outlines}")
    print(f"[DEBUG] delete_packages = {state.delete_packages}")

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return ClearAllFilesOutput(
            files=[],
            deleted_count=0,
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    try:
        # 列出所有文件
        result = storage.list_files(prefix="")
        all_keys = result.get("keys", [])
        
        # 过滤掉空key、bucket前缀（以/结尾）和空白key
        all_keys = [key for key in all_keys if key and key.strip() and not key.endswith("/")]

        if not all_keys:
            return ClearAllFilesOutput(
                files=[],
                deleted_count=0,
                message="✅ 没有文件需要删除"
            )

        # 确认是否删除（通过文件名匹配）
        target_prefixes = []
        if state.delete_scripts:
            target_prefixes.append("scripts/")
        if state.delete_outlines:
            target_prefixes.append("outlines/")
        if state.delete_packages:
            target_prefixes.append("packages/")
        if state.delete_all:
            # 删除所有文件（包括模板、小说等）
            target_prefixes = []  # 空列表表示删除所有文件

        # 筛选要删除的文件
        keys_to_delete = []
        if not target_prefixes:
            # 删除所有文件
            keys_to_delete = all_keys
        else:
            # 只删除指定前缀的文件
            for key in all_keys:
                for prefix in target_prefixes:
                    if key.startswith(prefix):
                        keys_to_delete.append(key)
                        break

        # 执行删除
        deleted_count = 0
        for key in keys_to_delete:
            try:
                storage.delete_file(file_key=key)
                deleted_count += 1
            except Exception as e:
                print(f"删除文件 {key} 失败: {e}")

        # 等待S3更新（避免立即列表时读取到旧数据）
        time.sleep(2)

        # 获取剩余文件列表
        result = storage.list_files(prefix="")
        remaining_files = []
        for file_key in result.get("keys", []):
            try:
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "") if metadata else ""
                file_type = metadata.get("content_type", "") if metadata else ""

                # 提取文件的基本名称
                filename = file_key.split("/")[-1]

                remaining_files.append({
                    "file_key": file_key,
                    "filename": filename,
                    "original_name": original_name if original_name else filename,
                    "file_type": file_type
                })
            except Exception as e:
                print(f"读取文件元数据失败: {e}")

        # 构建返回消息
        if state.delete_all:
            msg = "删除了所有文件"
        elif state.delete_scripts and state.delete_outlines and state.delete_packages:
            msg = "删除了所有文件"
        else:
            parts = []
            if state.delete_scripts:
                parts.append("脚本文件")
            if state.delete_outlines:
                parts.append("大纲文件")
            if state.delete_packages:
                parts.append("压缩包")
            if parts:
                msg = "删除了" + "、".join(parts)
            else:
                msg = "删除了文件"

        message = f"✅ {msg}，共删除 {deleted_count} 个文件，剩余 {len(remaining_files)} 个文件"

        return ClearAllFilesOutput(
            files=remaining_files,
            deleted_count=deleted_count,
            message=message
        )

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        print(f"清理文件失败: {error_detail}")
        return ClearAllFilesOutput(
            files=[],
            deleted_count=0,
            message=f"❌ 清理文件失败: {str(e)}"
        )
