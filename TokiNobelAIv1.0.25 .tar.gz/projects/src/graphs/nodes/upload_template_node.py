"""上传提示词模板节点（图形化版）"""
import os
import re
import requests
from pathlib import Path
from urllib.parse import urlparse, unquote
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import UploadTemplateInput, UploadTemplateOutput
from utils.file.file import File, FileOps
from utils.file_utils import get_safe_filename


def extract_filename_from_url(url: str) -> str:
    """
    从URL中提取干净的文件名，移除签名等查询参数

    Args:
        url: 文件URL（可能包含签名参数）

    Returns:
        干净的文件名
    """
    import os

    # 处理URL（包含查询参数）
    if '?' in url:
        url = url.split('?')[0]

    # 标准化路径分隔符（处理Windows路径到Linux的转换）
    # 将反斜杠替换为正斜杠，确保跨平台兼容
    normalized_url = url.replace('\\', '/')

    # 使用os.path.basename提取文件名（跨平台兼容）
    filename = os.path.basename(normalized_url)
    # URL解码（处理中文等特殊字符）
    filename = unquote(filename)
    return filename


def extract_filename_from_headers(url: str) -> str:
    """
    从HTTP响应头的Content-Disposition中提取原始文件名

    Args:
        url: 文件URL

    Returns:
        原始文件名，如果无法提取则返回空字符串
    """
    try:
        # 发送HEAD请求获取响应头（不下载文件内容）
        response = requests.head(url, timeout=30, allow_redirects=True)
        response.raise_for_status()

        # 检查Content-Disposition响应头
        content_disposition = response.headers.get('Content-Disposition', '')
        if not content_disposition:
            return ""

        # 解析Content-Disposition响应头
        # 格式1: Content-Disposition: attachment; filename="filename.ext"
        # 格式2: Content-Disposition: attachment; filename*=UTF-8''filename.ext
        match = re.search(r'filename\*?=(?:UTF-8\'\')?([^;]+)', content_disposition, re.IGNORECASE)
        if match:
            filename = match.group(1).strip('"\' ')
            return unquote(filename)

        return ""
    except Exception as e:
        # 如果获取失败，返回空字符串
        print(f"从响应头提取文件名失败: {e}")
        return ""


def upload_template_node(
    state: UploadTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> UploadTemplateOutput:
    """
    title: 上传提示词模板
    desc: 点击上传按钮，上传.md提示词模板文件
    integrations: 对象存储
    """
    ctx = runtime.context
    
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return UploadTemplateOutput(
            templates=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    try:
        # 读取文件内容
        content = FileOps.extract_text(state.template_file)

        # 提取原始文件名（按优先级）
        original_filename = ""

        # 优先级1: 用户手动指定的template_name（现在由后端传递原始文件名）
        if state.template_name and state.template_name.strip():
            original_filename = state.template_name.strip()
        else:
            # 优先级2: 从HTTP响应头中提取原始文件名
            filename_from_header = extract_filename_from_headers(state.template_file.url)
            if filename_from_header:
                original_filename = filename_from_header
            else:
                # 优先级3: 从URL路径中提取文件名（清理签名参数）
                original_filename = extract_filename_from_url(state.template_file.url)

        # 生成安全的文件名（使用时间戳，每次上传生成不同的key）
        safe_filename, file_id = get_safe_filename(
            original_filename,
            category="template",
            use_timestamp=True
        )
        
        # 构建存储key
        storage_key = f"templates/{safe_filename}"
        
        # 上传到存储（传递原始文件名）
        file_key = storage.upload_file(
            file_content=content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/markdown",
            original_name=original_filename
        )
        
        # 列出所有模板文件
        result = storage.list_files(prefix="templates/")
        templates_list = []
        for file_key in result.get("keys", []):
            try:
                # 标准化文件键（处理Windows路径的反斜杠问题）
                normalized_key = file_key.replace("\\", "/")
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(normalized_key)
                original_name = metadata.get("original_name", "")
                
                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else Path(file_key).name
                
                # 生成访问URL
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                
                # 确定显示的原始文件名
                if normalized_key == storage_key:
                    # 当前刚上传的文件，使用提取的原始文件名
                    display_original_name = original_filename
                else:
                    # 其他文件，使用元数据中的原始文件名
                    display_original_name = original_name if original_name else Path(file_key).name
                
                templates_list.append({
                    "name": display_name,
                    "url": url,
                    "original_name": display_original_name
                })
            except Exception as e:
                print(f"处理文件信息失败: {e}")
        
        # 返回输出
        return UploadTemplateOutput(
            templates=templates_list,
            message=f"✅ 成功上传提示词模板：{original_filename}"
        )
        
    except Exception as e:
        return UploadTemplateOutput(
            templates=[],
            message=f"❌ 上传文件到存储失败: {str(e)}"
        )
