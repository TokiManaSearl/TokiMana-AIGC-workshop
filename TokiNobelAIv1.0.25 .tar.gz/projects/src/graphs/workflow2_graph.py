"""
图形化工作流2：小说改编大纲（鼠标操作版）
"""
from typing import Optional
from pydantic import BaseModel, Field
from langgraph.graph import StateGraph, END

# 导入节点
from graphs.nodes.upload_novel_node import upload_novel_node
from graphs.nodes.list_novels_node import list_novels_node
from graphs.nodes.delete_novel_node import delete_novel_node
from graphs.nodes.generate_outline_node import generate_outline_node


class Workflow2Input(BaseModel):
    """
    工作流2输入 - 图形化界面版本
    """
    # 上传节点参数
    upload_novel_file: Optional[dict] = Field(default=None, description="点击上传按钮时提供文件")
    
    # 删除节点参数
    delete_novel_name: str = Field(default="", description="点击删除按钮时提供小说名称")
    
    # 选择模型节点参数
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="从下拉框选择LLM模型")


class Workflow2Output(BaseModel):
    """工作流2输出"""
    novels: list = Field(default=[], description="小说列表")
    outline_content: str = Field(default="", description="生成的大纲内容")
    outline_url: str = Field(default="", description="大纲文件URL")
    message: str = Field(default="", description="操作结果消息")


class Workflow2GlobalState(BaseModel):
    """工作流2全局状态"""
    # 小说文件存储
    novels: list = Field(default=[], description="已上传的小说文件列表")
    
    # LLM模型选择
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="选择的LLM模型")
    
    # 大纲生成结果
    outline_content: str = Field(default="", description="生成的短剧剧集大纲内容")
    outline_url: str = Field(default="", description="大纲文件的URL")
    
    # 提示词模板（从工作流1读取）
    template_content: str = Field(default="", description="提示词模板内容")
    
    # 消息
    message: str = Field(default="", description="操作结果消息")
    
    # 输入字段
    upload_novel_file: Optional[dict] = Field(default=None)
    delete_novel_name: str = Field(default="")


# 创建状态图
builder = StateGraph(Workflow2GlobalState, input_schema=Workflow2Input, output_schema=Workflow2Output)

# 添加所有节点
builder.add_node("upload_novel", upload_novel_node, metadata={
    "type": "task",
    "ui": {
        "label": "上传小说",
        "widget": "file_upload",
        "description": "点击上传小说.txt文件"
    }
})

builder.add_node("list_novels", list_novels_node, metadata={
    "type": "task",
    "ui": {
        "label": "刷新列表",
        "widget": "button",
        "description": "查看所有已上传的小说"
    }
})

builder.add_node("delete_novel", delete_novel_node, metadata={
    "type": "task",
    "ui": {
        "label": "删除小说",
        "widget": "button",
        "description": "删除选中的小说",
        "input_field": "delete_novel_name"
    }
})

builder.add_node("generate_outline", generate_outline_node, metadata={
    "type": "agent",
    "ui": {
        "label": "生成大纲",
        "widget": "button",
        "description": "根据上传的小说生成短剧剧集大纲"
    },
    "llm_cfg": "config/generate_outline_cfg.json"
})

# 设置默认入口点
builder.set_entry_point("list_novels")

# 所有节点执行完后结束
builder.add_edge("upload_novel", END)
builder.add_edge("list_novels", END)
builder.add_edge("delete_novel", END)
builder.add_edge("generate_outline", END)

# 编译图
workflow2_main_graph = builder.compile()
