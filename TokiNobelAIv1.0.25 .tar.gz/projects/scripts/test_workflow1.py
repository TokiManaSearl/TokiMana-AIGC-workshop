#!/usr/bin/env python3
"""测试脚本：测试工作流1的完整流程"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from graphs.graph import call_workflow1
from graphs.state import CallWorkflow1Input
from langchain_core.runnables import RunnableConfig
from coze_coding_utils.runtime_ctx.context import new_context
from utils.file.file import File


def test_workflow1_operations():
    """测试工作流1的所有操作"""
    print("=" * 60)
    print("测试工作流1的完整流程")
    print("=" * 60)

    config = RunnableConfig()
    ctx = new_context(method="invoke")

    # 创建模拟Runtime
    class MockRuntime:
        def __init__(self, context):
            self.context = context

    mock_runtime = MockRuntime(ctx)

    # 测试1: list_templates
    print("\n测试1: list_templates")
    try:
        input_data = CallWorkflow1Input(node_name="list_templates")
        output = call_workflow1(input_data, config, mock_runtime)
        print(f"✅ 结果: {output.message}")
        print(f"   模板数量: {len(output.templates)}")
    except Exception as e:
        print(f"❌ 失败: {str(e)}")
        return False

    # 测试2: edit_template (with template_name)
    print("\n测试2: edit_template (with template_name)")
    try:
        # 如果有模板，使用第一个模板
        template_name = ""
        if output.templates:
            template_name = output.templates[0].get("name", "")
        
        if template_name:
            input_data = CallWorkflow1Input(
                node_name="edit_template",
                template_name=template_name,
                new_content="测试编辑内容"
            )
            output = call_workflow1(input_data, config, mock_runtime)
            print(f"✅ 结果: {output.message}")
            print(f"   编辑后内容: {output.selected_content[:50]}..." if len(output.selected_content) > 50 else f"   编辑后内容: {output.selected_content}")
        else:
            print("⚠️  跳过：没有可编辑的模板")
    except Exception as e:
        print(f"❌ 失败: {str(e)}")
        return False

    # 测试3: save_template (with template_name)
    print("\n测试3: save_template (with template_name)")
    try:
        if template_name:
            input_data = CallWorkflow1Input(
                node_name="save_template",
                template_name=template_name,
                new_content="测试保存内容"
            )
            output = call_workflow1(input_data, config, mock_runtime)
            print(f"✅ 结果: {output.message}")
            print(f"   保存URL: {output.saved_url[:50]}..." if len(output.saved_url) > 50 else f"   保存URL: {output.saved_url}")
        else:
            print("⚠️  跳过：没有可保存的模板")
    except Exception as e:
        print(f"❌ 失败: {str(e)}")
        return False

    print("\n" + "=" * 60)
    print("✅ 工作流1测试完成")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = test_workflow1_operations()
    sys.exit(0 if success else 1)
