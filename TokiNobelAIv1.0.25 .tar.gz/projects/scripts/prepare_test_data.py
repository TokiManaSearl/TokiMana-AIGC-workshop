#!/usr/bin/env python3
"""准备测试数据脚本"""
import os
import sys
import json

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename

def prepare_test_data():
    """准备测试数据"""
    print("=" * 60)
    print("准备测试数据")
    print("=" * 60)

    try:
        # 初始化存储
        storage = StorageAdapter(use_s3=True)

        # 创建测试大纲
        outline_content = """# 测试短剧大纲

## 剧情梗概
一个关于成长的校园故事。

## 分集大纲

### 第一集
- 标题：初入校园
- 剧情：主角第一天来到新学校，遇到了新朋友。

### 第二集
- 标题：课堂风波
- 剧情：在课堂上发生的有趣事件。

### 第三集
- 标题：友谊的考验
- 剧情：主角面临友谊的考验。
"""

        # 上传大纲
        original_name = "测试短剧大纲.md"
        safe_filename, _ = get_safe_filename(original_name, category="outlines")
        storage_key = f"outlines/{safe_filename}"

        file_key = storage.upload_file(
            file_content=outline_content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/markdown",
            original_name=original_name
        )

        print(f"✅ 测试大纲已上传: {file_key}")

        # 创建测试提示词模板
        template_content = """# 短剧改编提示词模板

## 改编要求
- 保持原作风格
- 每集500-800字
- 包含场景描述和人物对话
"""

        # 上传提示词模板
        original_name = "短剧改编提示词模板.md"
        safe_filename, _ = get_safe_filename(original_name, category="templates")
        storage_key = f"templates/{safe_filename}"

        file_key = storage.upload_file(
            file_content=template_content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/markdown",
            original_name=original_name
        )

        print(f"✅ 测试提示词模板已上传: {file_key}")

        print("\n✅ 测试数据准备完成")
        return True

    except Exception as e:
        print(f"\n❌ 测试数据准备失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = prepare_test_data()
    sys.exit(0 if success else 1)
