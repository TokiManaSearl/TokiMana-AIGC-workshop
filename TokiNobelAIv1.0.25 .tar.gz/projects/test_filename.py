#!/usr/bin/env python3
"""测试文件名生成是否正确"""
from utils.file_utils import get_safe_filename
import time

# 测试相同文件名是否生成相同key（use_timestamp=False）
name1, id1 = get_safe_filename('全年龄动画改编模板.md', category='template', use_timestamp=False)
name2, id2 = get_safe_filename('全年龄动画改编模板.md', category='template', use_timestamp=False)

print('✅ use_timestamp=False 测试（相同文件名应该生成相同key）:')
print(f'   第一次: {name1}')
print(f'   第二次: {name2}')
print(f'   是否相同: {name1 == name2}')
print()

# 测试不同文件名是否生成不同key（use_timestamp=False）
name3, id3 = get_safe_filename('另一个模板.md', category='template', use_timestamp=False)
print('✅ 不同文件名测试（应该生成不同key）:')
print(f'   name1: {name1}')
print(f'   name3: {name3}')
print(f'   是否不同: {name1 != name3}')
print()

# 测试时间戳模式（use_timestamp=True）
name4, id4 = get_safe_filename('脚本.md', category='scripts', use_timestamp=True)
time.sleep(1)
name5, id5 = get_safe_filename('脚本.md', category='scripts', use_timestamp=True)
print('✅ use_timestamp=True 测试（相同文件名应该生成不同key）:')
print(f'   第一次: {name4}')
print(f'   第二次: {name5}')
print(f'   是否不同: {name4 != name5}')
