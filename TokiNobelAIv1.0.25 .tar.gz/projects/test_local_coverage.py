#!/usr/bin/env python3
"""验证本地存储的覆盖功能"""
from utils.storage_adapter import StorageAdapter
from utils.file.file import File, FileOps
from utils.file_utils import get_safe_filename
import os

# 使用本地存储
storage = StorageAdapter(use_s3=False)

# 模拟上传两次同名模板
template_name = "全年龄动画改编模板.md"

# 第一次上传
content1 = "这是模板的第一次内容"
safe_filename1, _ = get_safe_filename(template_name, category='template', use_timestamp=False)
key1 = f"templates/{safe_filename1}"

print(f"✅ 第一次上传:")
print(f"   原始名称: {template_name}")
print(f"   安全名称: {safe_filename1}")
print(f"   存储key: {key1}")
print(f"   内容: {content1}")

storage.upload_file(
    file_content=content1.encode('utf-8'),
    file_name=key1,
    content_type="text/markdown",
    original_name=template_name
)

# 第二次上传（同名）
content2 = "这是模板的第二次内容（已修改）"
safe_filename2, _ = get_safe_filename(template_name, category='template', use_timestamp=False)
key2 = f"templates/{safe_filename2}"

print(f"\n✅ 第二次上传（同名）:")
print(f"   原始名称: {template_name}")
print(f"   安全名称: {safe_filename2}")
print(f"   存储key: {key2}")
print(f"   Key是否相同: {key1 == key2}")
print(f"   内容: {content2}")

storage.upload_file(
    file_content=content2.encode('utf-8'),
    file_name=key2,
    content_type="text/markdown",
    original_name=template_name
)

# 列出所有模板
print(f"\n✅ 列出所有模板:")
result = storage.list_files(prefix="templates/")
print(f"   找到 {len(result.get('keys', []))} 个文件:")
for k in result.get('keys', []):
    # 读取文件内容
    url = storage.generate_presigned_url(key=k, expire_time=3600)
    file_obj = File(url=url, file_type="document")
    try:
        content = FileOps.extract_text(file_obj)
    except:
        content = "[读取失败]"
    print(f"   - {k} : {content}")

# 验证最终内容
print(f"\n✅ 验证内容是否被覆盖:")
url = storage.generate_presigned_url(key=key1, expire_time=3600)
file_obj = File(url=url, file_type="document")
final_content = FileOps.extract_text(file_obj)
print(f"   最终内容: {final_content}")
print(f"   是否为第二次内容: {final_content == content2}")
