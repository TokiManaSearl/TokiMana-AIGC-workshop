# 项目结构说明

# 快速开始

## 🚀 立即使用

### 方式1：Git克隆（推荐）
```bash
git clone <仓库地址>
cd novel-to-animation-workflow
pip install -r requirements.txt
python src/main.py
```

### 方式2：下载压缩包
```bash
# 解压
tar -xzf novel-to-animation-workflow.tar.gz
cd novel-to-animation-workflow

# 安装依赖
pip install -r requirements.txt

# 启动服务
python src/main.py
```

### 方式3：快速分享脚本
```bash
# 运行分享脚本，选择分享方式
bash scripts/quick_share.sh
```

## 📖 文档导航

| 文档 | 说明 |
|-----|------|
| **使用指南.md** | 详细的操作步骤说明（必读） |
| **分享指南.md** | 如何分享给同事（Git、压缩包、API） |
| **AGENTS.md** | 工作流结构和节点说明 |
| **README.md** | 本文件 - 项目快速开始 |

## 📦 快速分享给同事

### 一键分享脚本
```bash
bash scripts/quick_share.sh
```

### 三种分享方式

1. **Git仓库分享**（推荐）
   - 适合团队协作
   - 版本管理完善
   - 详见：[分享指南.md](分享指南.md#方式1通过git仓库分享推荐)

2. **压缩包分享**
   - 适合快速单次分享
   - 无需额外配置
   - 详见：[分享指南.md](分享指南.md#方式2打包导出分享)

3. **API接口访问**
   - 适合无需源码的场景
   - 集中管理
   - 详见：[分享指南.md](分享指南.md#方式3提供api接口访问)

### 分享消息模板

**Git仓库分享**：
```
【工作流分享】小说改编动画短剧工作流系统

仓库地址：https://github.com/xxx/novel-to-animation-workflow.git

使用步骤：
1. git clone https://github.com/xxx/novel-to-animation-workflow.git
2. cd novel-to-animation-workflow
3. pip install -r requirements.txt
4. python src/main.py

详细指南：查看"使用指南.md"
```

**压缩包分享**：
```
【工作流分享】小说改编动画短剧工作流系统

下载地址：[填写网盘链接]
文件名：novel-to-animation-workflow.tar.gz
MD5校验：[填写MD5值]

使用步骤：
1. 解压：tar -xzf novel-to-animation-workflow.tar.gz
2. 安装依赖：pip install -r requirements.txt
3. 启动服务：python src/main.py

详细指南：查看"使用指南.md"
```

# 本地运行
## 运行流程
bash scripts/local_run.sh -m flow

## 运行节点
bash scripts/local_run.sh -m node -n node_name

# 启动HTTP服务
bash scripts/http_run.sh -m http -p 5000

# 快速分享
bash scripts/quick_share.sh


