#!/usr/bin/env python3
"""
测试批处理文件的路径判断逻辑
"""
import os
import sys

def test_path_detection():
    print("=" * 80)
    print("测试批处理文件路径检测逻辑")
    print("=" * 80)
    print()

    # 获取当前目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print(f"📂 脚本所在目录: {current_dir}")
    print()

    # 模拟批处理文件的逻辑
    # 1. 检查当前目录是否是项目根目录（scripts/local_server.py 是否存在）
    scripts_in_current = os.path.join(current_dir, "scripts", "local_server.py")
    if os.path.exists(scripts_in_current):
        print("✅ 当前目录是项目根目录")
        print(f"   找到: {scripts_in_current}")
        project_root = current_dir
    else:
        # 2. 检查父目录
        parent_dir = os.path.dirname(current_dir)
        scripts_in_parent = os.path.join(parent_dir, "scripts", "local_server.py")
        if os.path.exists(scripts_in_parent):
            print("✅ 父目录是项目根目录")
            print(f"   找到: {scripts_in_parent}")
            project_root = parent_dir
        else:
            print("❌ 无法找到项目根目录")
            print(f"   当前目录: {current_dir}")
            print(f"   父目录: {parent_dir}")
            return False

    print()
    print(f"🎯 项目根目录: {project_root}")
    print()

    # 验证项目结构
    print("验证项目结构:")
    check_files = [
        "scripts/local_server.py",
        "src/graphs/graph.py",
        "src/utils/local_storage.py",
        "assets/storage"
    ]

    all_ok = True
    for file_path in check_files:
        full_path = os.path.join(project_root, file_path)
        exists = os.path.exists(full_path)
        status = "✅" if exists else "❌"
        print(f"  {status} {file_path}")
        if not exists:
            all_ok = False

    print()
    if all_ok:
        print("=" * 80)
        print("✅ 所有检查通过！批处理文件逻辑正确")
        print("=" * 80)
        return True
    else:
        print("=" * 80)
        print("❌ 部分文件缺失！")
        print("=" * 80)
        return False

if __name__ == "__main__":
    success = test_path_detection()
    sys.exit(0 if success else 1)
