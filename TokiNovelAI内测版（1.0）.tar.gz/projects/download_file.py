"""
下载工作流生成的文件
运行: python download_file.py
"""

import os
import sys
import requests

# 添加项目路径到Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "src"))

from storage.s3.s3_storage import S3SyncStorage


def download_file(file_key: str, save_path: str = None):
    """
    下载S3存储中的文件

    Args:
        file_key: S3中的文件key（如：packages/packages_xxx_xxx.zip）
        save_path: 本地保存路径（可选，默认保存在/tmp/downloads/）
    """
    # 创建S3存储实例
    storage = S3SyncStorage(
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME", "coze_storage_7601072529431855158"),
        region="cn-beijing"
    )

    try:
        # 生成签名URL
        print(f"🔍 正在为文件生成签名URL...")
        print(f"   文件key: {file_key}")
        url = storage.generate_presigned_url(key=file_key, expire_time=3600)
        print(f"   URL: {url[:100]}...")
        print(f"   有效期: 1小时")
        print()

        # 下载文件
        print(f"📥 正在下载文件...")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        # 确定保存路径
        if save_path is None:
            download_dir = "/tmp/downloads"
            os.makedirs(download_dir, exist_ok=True)
            filename = file_key.split("/")[-1]
            save_path = os.path.join(download_dir, filename)

        # 保存文件
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        file_size = os.path.getsize(save_path)
        print(f"✅ 文件下载成功！")
        print(f"   保存路径: {save_path}")
        print(f"   文件大小: {file_size / 1024:.2f} KB")
        print()

        # 提取文件信息
        if file_key.startswith("packages/"):
            print(f"📦 这是一个压缩包，包含以下内容：")
            import zipfile
            with zipfile.ZipFile(save_path, 'r') as zip_ref:
                for info in zip_ref.infolist():
                    print(f"   • {info.filename} ({info.file_size} bytes)")

        return save_path

    except Exception as e:
        print(f"❌ 下载失败: {e}")
        import traceback
        traceback.print_exc()
        return None


def list_recent_packages(limit=5):
    """列出最近生成的压缩包"""
    storage = S3SyncStorage(
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME", "coze_storage_7601072529431855158"),
        region="cn-beijing"
    )

    print("=" * 60)
    print("📦 最近生成的压缩包")
    print("=" * 60)
    print()

    # 列出所有文件，然后过滤packages
    result = storage.list_files()
    packages = [key for key in result.get("keys", []) if "packages" in key and key.endswith(".zip")]

    if not packages:
        print("❌ 没有找到压缩包")
        return []

    # 按时间戳排序，取最新的几个
    packages = sorted(packages, reverse=True)[:limit]

    print(f"找到 {len(packages)} 个压缩包（最新的 {min(limit, len(packages))} 个）：\n")

    for idx, package_key in enumerate(packages, 1):
        filename = package_key.split("/")[-1]
        # 提取时间戳（从文件名中）
        timestamp = filename.split("_")[1] if "_" in filename else "unknown"
        print(f"{idx}. {filename}")
        print(f"   时间戳: {timestamp}")
        print(f"   文件key: {package_key}")
        print(f"   下载命令: python download_file.py --key '{package_key}'")
        print()

    return packages


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='下载工作流生成的文件')
    parser.add_argument('--list', action='store_true', help='列出最近生成的压缩包')
    parser.add_argument('--key', type=str, help='要下载的文件key（如：packages/packages_xxx_xxx.zip）')
    parser.add_argument('--save', type=str, help='保存路径（可选）')
    parser.add_argument('--latest', action='store_true', help='下载最新的压缩包')

    args = parser.parse_args()

    if args.list:
        # 列出最近的压缩包
        list_recent_packages()

    elif args.key:
        # 下载指定的文件
        download_file(args.key, args.save)

    elif args.latest:
        # 下载最新的压缩包
        packages = list_recent_packages(limit=1)
        if packages:
            download_file(packages[0], args.save)
        else:
            print("❌ 没有找到可下载的压缩包")

    else:
        # 默认行为：列出最近的压缩包，并提供下载选项
        print("=" * 60)
        print("📦 工作流生成文件下载工具")
        print("=" * 60)
        print()
        print("使用方法：")
        print("1. 查看最近生成的压缩包：python download_file.py --list")
        print("2. 下载指定的文件：python download_file.py --key 'packages/packages_xxx_xxx.zip'")
        print("3. 下载最新的压缩包：python download_file.py --latest")
        print()

        # 自动列出最近的压缩包
        list_recent_packages()


if __name__ == "__main__":
    main()
