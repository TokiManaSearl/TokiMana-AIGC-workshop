#!/usr/bin/env python3
"""
Simplified Server Starter with LLM Web Configuration
A simplified version that avoids complex imports for local execution
"""
import sys
import os
import subprocess
import signal
import time
import json
import re
import requests
from flask import Flask, jsonify, request

# Add project root to path
# simple_server.py is in the project root directory
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

print("="*80)
print("🚀 简化版服务器启动器 (支持Web界面LLM配置)")
print("="*80)
print()
print(f"项目根目录: {project_root}")
print(f"Python版本: {sys.version}")
print()

# Create Flask app
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

server_process = None

# LLM配置文件路径
LLM_CONFIG_PATH = os.path.join(project_root, 'config', 'llm_providers.json')
print(f"LLM配置路径: {LLM_CONFIG_PATH}")
print(f"配置文件存在: {os.path.exists(LLM_CONFIG_PATH)}")
print()


def read_llm_config():
    """读取LLM配置"""
    try:
        if os.path.exists(LLM_CONFIG_PATH):
            with open(LLM_CONFIG_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            return None
    except Exception as e:
        print(f"读取LLM配置失败: {e}")
        return None


def write_llm_config(config):
    """写入LLM配置"""
    try:
        with open(LLM_CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"写入LLM配置失败: {e}")
        return False


@app.route('/')
def index():
    """主页 - 重定向到工作流界面"""
    return '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>小说改编动画短剧工作流 - 本地版</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        h1 { color: #333; margin-bottom: 20px; }
        p { color: #666; margin-bottom: 15px; line-height: 1.6; }
        .success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            text-align: left;
        }
        .success h3 { color: #155724; margin-bottom: 10px; }
        .button {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin: 10px;
            transition: transform 0.3s;
            cursor: pointer;
        }
        .button:hover { transform: translateY(-2px); }
        .button.secondary {
            background: linear-gradient(135deg, #a8a8a8 0%, #888888 100%);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 小说改编动画短剧工作流</h1>
        <p>欢迎使用本地版工作流系统！</p>

        <div class="success">
            <h3>✨ 新功能：Web界面LLM配置</h3>
            <p>现在可以通过浏览器直接配置LLM，无需手动编辑文件！</p>
            <ul>
                <li><strong>静态版（推荐）</strong>：不依赖API，直接配置</li>
                <li><strong>动态版</strong>：从配置文件加载</li>
                <li>选择LLM提供商</li>
                <li>填写API Key和配置</li>
                <li>填写API Key和其他配置</li>
                <li>点击测试和保存</li>
            </ul>
            <p style="color: #856404; margin-top: 10px; font-size: 14px;">
                💡 支持自定义第三方API（如千牛云）
            </p>
        </div>

        <p>请选择操作：</p>
        <a href="/llm-config-static" class="button" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">⚙️ 配置LLM</a>
        <a href="/workflow" class="button secondary">📝 工作流界面</a>
        <a href="/test-page" class="button secondary">🔧 诊断测试</a>
        <a href="/status" class="button secondary">📊 系统状态</a>
    </div>
</body>
</html>
    '''


@app.route('/llm-config')
def llm_config():
    """LLM配置界面"""
    return '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LLM配置 - Web界面</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 { color: #333; margin-bottom: 10px; }
        .subtitle { color: #666; margin-bottom: 20px; }
        .tabs {
            display: flex;
            border-bottom: 2px solid #ddd;
            margin-bottom: 20px;
            overflow-x: auto;
        }
        .tab {
            padding: 12px 20px;
            cursor: pointer;
            border: none;
            background: none;
            font-size: 14px;
            color: #666;
            transition: all 0.3s;
            white-space: nowrap;
        }
        .tab:hover { background: #f5f5f5; }
        .tab.active {
            border-bottom: 3px solid #667eea;
            color: #667eea;
            font-weight: bold;
        }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group textarea { min-height: 100px; resize: vertical; }
        .form-group small { color: #999; font-size: 12px; }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.9; }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }
        .alert-success { background: #d4edda; border-left: 4px solid #28a745; color: #155724; }
        .alert-error { background: #f8d7da; border-left: 4px solid #dc3545; color: #721c24; }
        .provider-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        .provider-card {
            border: 2px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .provider-card:hover { border-color: #667eea; transform: translateY(-2px); }
        .provider-card.selected { border-color: #667eea; background: #f0f4ff; }
        .provider-name { font-size: 16px; font-weight: bold; margin-bottom: 5px; }
        .provider-desc { font-size: 13px; color: #666; }
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            color: #666;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">🔙 返回主页</a>
        <h1>⚙️ LLM配置</h1>
        <p class="subtitle">通过Web界面配置您的LLM提供商，无需手动编辑文件</p>

        <div id="alert" class="alert"></div>

        <div id="loading" class="loading">
            <p>⏳ 正在加载配置...</p>
        </div>

        <!-- 提供商列表 -->
        <div id="provider-list-view" style="display: block;">
            <h2>选择LLM提供商</h2>
            <p style="color: #666; margin-bottom: 20px;">点击卡片选择要配置的提供商</p>
            <div class="provider-list" id="provider-list">
                <p style="color: #999; text-align: center;">正在加载提供商列表...</p>
            </div>
        </div>

        <!-- 配置表单 -->
        <div id="config-form-view" style="display: none;">
            <div style="margin-bottom: 20px;">
                <button class="btn btn-secondary" onclick="showProviderList()">🔙 返回提供商列表</button>
                <h2 id="provider-title" style="display: inline-block; margin-left: 20px;"></h2>
            </div>

            <div class="form-group">
                <label>提供商ID</label>
                <input type="text" id="provider-id" readonly>
            </div>

            <div class="form-group">
                <label>API Key <span style="color: red;">*</span></label>
                <input type="password" id="api-key" placeholder="输入您的API Key">
                <small>必填项，从对应平台获取</small>
            </div>

            <div class="form-group">
                <label>API端点 <span style="color: red;">*</span></label>
                <input type="text" id="endpoint" placeholder="输入API端点URL">
                <small>必填项，API请求的完整URL</small>
            </div>

            <div class="form-group">
                <label>模型名称 <span style="color: red;">*</span></label>
                <input type="text" id="model" placeholder="输入模型名称或ID">
                <small>必填项，例如: gpt-4o-mini, deepseek-chat</small>
            </div>

            <div class="form-group">
                <label>温度</label>
                <input type="number" id="temperature" min="0" max="2" step="0.1" value="0.7">
                <small>控制生成随机性，0-2之间，默认0.7</small>
            </div>

            <div class="form-group">
                <label>最大Token数</label>
                <input type="number" id="max-tokens" min="1" value="4096">
                <small>限制输出长度，默认4096</small>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" id="enabled" checked>
                    启用此提供商
                </label>
                <small>勾选后将成为默认使用的LLM提供商</small>
            </div>

            <div style="margin-top: 30px;">
                <button class="btn btn-success" onclick="testConnection()">🧪 测试连接</button>
                <button class="btn btn-primary" onclick="saveConfig()">💾 保存配置</button>
            </div>
        </div>
    </div>

    <script>
        let currentConfig = null;
        let selectedProvider = null;

        // 页面加载时获取配置
        window.onload = function() {
            console.log('Page loaded, starting to load config...');
            loadConfig();
        };

        function showAlert(message, type) {
            console.log('Showing alert:', type, message);
            const alert = document.getElementById('alert');
            alert.className = 'alert alert-' + type;
            alert.textContent = message;
            alert.style.display = 'block';
            setTimeout(() => { alert.style.display = 'none'; }, 5000);
        }

        function showLoading(show) {
            console.log('Loading state:', show);
            document.getElementById('loading').style.display = show ? 'block' : 'none';
        }

        async function loadConfig() {
            console.log('Loading config...');
            showLoading(true);

            try {
                console.log('Fetching /api/llm/config');
                const response = await fetch('/api/llm/config');

                console.log('Response status:', response.status);
                if (!response.ok) throw new Error('获取配置失败');

                const data = await response.json();
                console.log('API Response:', data);

                if (!data.success) {
                    throw new Error(data.error || '未知错误');
                }

                if (!data.config) {
                    throw new Error('返回的配置数据为空');
                }

                currentConfig = data.config;
                console.log('Config loaded successfully:', currentConfig);
                renderProviderList();
            } catch (error) {
                console.error('Load config error:', error);
                let errorMessage = '加载配置失败: ' + error.message;
                if (error.message.includes('undefined')) {
                    errorMessage += '\n\n可能原因：配置文件不存在或格式错误\n请检查 config/llm_providers.json 文件';
                }
                showAlert(errorMessage, 'error');

                // 显示错误信息在列表区域
                document.getElementById('provider-list').innerHTML =
                    `<div style="color: red; text-align: center; padding: 20px;">
                        <h3>加载失败</h3>
                        <p>${error.message}</p>
                        <p style="color: #666; font-size: 14px;">请检查服务器日志或查看配置文件</p>
                    </div>`;
            } finally {
                console.log('Load config finished');
                showLoading(false);
            }
        }

        function renderProviderList() {
            console.log('Rendering provider list...');
            const container = document.getElementById('provider-list');
            container.innerHTML = '';

            const providers = currentConfig.providers || {};
            console.log('Providers:', providers);

            if (Object.keys(providers).length === 0) {
                container.innerHTML = '<p style="color: #999; text-align: center;">没有可用的提供商</p>';
                return;
            }

            for (const [id, provider] of Object.entries(providers)) {
                console.log('Creating card for:', id, provider);
                const card = document.createElement('div');
                card.className = 'provider-card';
                if (currentConfig.enabled_provider === id) {
                    card.classList.add('selected');
                }

                card.innerHTML = `
                    <div class="provider-name">${provider.name}</div>
                    <div class="provider-desc">${provider.description}</div>
                    ${provider.enabled ? '<div style="color: #28a745; margin-top: 5px;">✅ 已启用</div>' : ''}
                `;

                card.onclick = () => selectProvider(id);
                container.appendChild(card);
            }
            console.log('Provider list rendered');
        }

        function selectProvider(providerId) {
            selectedProvider = providerId;
            const provider = currentConfig.providers[providerId];
            const config = provider.config || {};

            document.getElementById('provider-id').value = providerId;
            document.getElementById('provider-title').textContent = provider.name;
            document.getElementById('api-key').value = config.api_key || '';
            document.getElementById('endpoint').value = config.endpoint || '';
            document.getElementById('model').value = config.model || '';
            document.getElementById('temperature').value = config.temperature || 0.7;
            document.getElementById('max-tokens').value = config.max_tokens || 4096;
            document.getElementById('enabled').checked = provider.enabled;

            document.getElementById('provider-list-view').style.display = 'none';
            document.getElementById('config-form-view').style.display = 'block';
        }

        function showProviderList() {
            document.getElementById('provider-list-view').style.display = 'block';
            document.getElementById('config-form-view').style.display = 'none';
        }

        async function testConnection() {
            const apiKey = document.getElementById('api-key').value;
            const endpoint = document.getElementById('endpoint').value;
            const model = document.getElementById('model').value;

            if (!apiKey || !endpoint || !model) {
                showAlert('请填写完整的配置信息', 'error');
                return;
            }

            showLoading(true);
            try {
                const response = await fetch('/api/llm/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        api_key: apiKey,
                        endpoint: endpoint,
                        model: model
                    })
                });

                const data = await response.json();
                if (data.success) {
                    showAlert('✅ 连接测试成功！配置有效。', 'success');
                } else {
                    showAlert('❌ 连接测试失败: ' + data.error, 'error');
                }
            } catch (error) {
                showAlert('测试请求失败: ' + error.message, 'error');
            } finally {
                showLoading(false);
            }
        }

        async function saveConfig() {
            const apiKey = document.getElementById('api-key').value;
            const endpoint = document.getElementById('endpoint').value;
            const model = document.getElementById('model').value;
            const temperature = parseFloat(document.getElementById('temperature').value);
            const maxTokens = parseInt(document.getElementById('max-tokens').value);
            const enabled = document.getElementById('enabled').checked;

            if (!apiKey || !endpoint || !model) {
                showAlert('API Key、API端点和模型名称为必填项', 'error');
                return;
            }

            const providerId = selectedProvider;
            const updateData = {
                provider_id: providerId,
                config: {
                    api_key: apiKey,
                    endpoint: endpoint,
                    model: model,
                    temperature: temperature,
                    max_tokens: maxTokens
                },
                enabled: enabled
            };

            showLoading(true);
            try {
                const response = await fetch('/api/llm/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updateData)
                });

                const data = await response.json();
                if (data.success) {
                    showAlert('✅ 配置保存成功！', 'success');
                    currentConfig = data.config;
                    renderProviderList();
                } else {
                    showAlert('保存失败: ' + data.error, 'error');
                }
            } catch (error) {
                showAlert('保存请求失败: ' + error.message, 'error');
            } finally {
                showLoading(false);
            }
        }
    </script>
</body>
</html>
    '''


@app.route('/api/llm/config', methods=['GET'])
def get_llm_config():
    """获取LLM配置"""
    try:
        config = read_llm_config()
        if config:
            return jsonify({'success': True, 'config': config})
        else:
            return jsonify({
                'success': False,
                'error': '无法读取配置文件',
                'detail': f'配置文件路径: {LLM_CONFIG_PATH}, 存在: {os.path.exists(LLM_CONFIG_PATH)}'
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'读取配置时发生错误: {str(e)}',
            'detail': str(e)
        })


@app.route('/api/llm/config', methods=['POST'])
def save_llm_config():
    """保存LLM配置"""
    try:
        data = request.json
        provider_id = data.get('provider_id')
        config_data = data.get('config', {})
        enabled = data.get('enabled', False)
        is_custom = data.get('is_custom', False)
        provider_name = data.get('name', '')

        # 读取当前配置
        current_config = read_llm_config()
        if not current_config:
            return jsonify({'success': False, 'error': '无法读取当前配置'})

        # 检查提供商ID格式（只能包含字母、数字、下划线）
        if not re.match(r'^[a-zA-Z0-9_]+$', provider_id):
            return jsonify({'success': False, 'error': '提供商ID只能包含字母、数字、下划线'})

        # 更新或新增提供商配置
        if provider_id in current_config['providers']:
            # 更新现有提供商
            current_config['providers'][provider_id]['config'] = config_data
            current_config['providers'][provider_id]['enabled'] = enabled
        else:
            # 新增提供商（自定义提供商）
            provider_config = {
                'config': config_data,
                'enabled': enabled
            }

            # 如果是自定义提供商，添加名称标记
            if is_custom and provider_name:
                provider_config['name'] = provider_name

            current_config['providers'][provider_id] = provider_config

        # 如果启用了，设置为默认提供商
        if enabled:
            # 禁用其他提供商
            for pid in current_config['providers']:
                if pid != provider_id:
                    current_config['providers'][pid]['enabled'] = False
            current_config['enabled_provider'] = provider_id

        # 保存配置
        if write_llm_config(current_config):
            return jsonify({'success': True, 'config': current_config})
        else:
            return jsonify({'success': False, 'error': '保存配置文件失败'})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/api/llm/test', methods=['POST'])
def test_llm_connection():
    """测试LLM连接"""
    try:
        data = request.json
        api_key = data.get('api_key')
        endpoint = data.get('endpoint')
        model = data.get('model')

        if not api_key or not endpoint or not model:
            return jsonify({'success': False, 'error': '缺少必要参数'})

        # 标准化endpoint
        if not endpoint.endswith('/chat/completions'):
            if endpoint.endswith('/'):
                endpoint = endpoint + 'chat/completions'
            else:
                endpoint = endpoint + '/chat/completions'

        # 发送测试请求
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

        test_data = {
            'model': model,
            'messages': [{'role': 'user', 'content': 'Hello, this is a connection test.'}],
            'max_tokens': 10
        }

        try:
            response = requests.post(
                endpoint,
                headers=headers,
                json=test_data,
                timeout=30
            )

            if response.status_code == 200:
                return jsonify({'success': True, 'message': '连接测试成功'})
            else:
                return jsonify({
                    'success': False,
                    'error': f'API返回错误: {response.status_code} - {response.text[:200]}'
                })

        except requests.exceptions.Timeout:
            return jsonify({'success': False, 'error': '请求超时，请检查网络和API端点'})
        except requests.exceptions.ConnectionError:
            return jsonify({'success': False, 'error': '连接失败，请检查API端点是否正确'})
        except Exception as e:
            return jsonify({'success': False, 'error': f'请求失败: {str(e)}'})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/test-page')
def test_page():
    """LLM配置测试页面"""
    try:
        with open('test_llm_config_page.html', 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f'测试页面加载失败: {e}'


@app.route('/llm-config-static')
def llm_config_static():
    """LLM配置页面（静态版）"""
    try:
        with open('llm_config_static.html', 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f'配置页面加载失败: {e}'


@app.route('/workflow')
def workflow():
    """工作流界面（简化版）"""
    return '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>工作流系统 - 本地版</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 900px;
            margin: 0 auto;
        }
        h1 { color: #333; margin-bottom: 20px; text-align: center; }
        .info {
            background: #d1ecf1;
            border-left: 4px solid #17a2b8;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            text-align: center;
        }
        .workflow-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .workflow-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            transition: transform 0.3s;
            border: 2px solid transparent;
        }
        .workflow-card:hover {
            transform: translateY(-5px);
            border-color: #667eea;
        }
        .workflow-icon { font-size: 48px; margin-bottom: 15px; }
        .workflow-title { font-size: 18px; font-weight: bold; color: #333; margin-bottom: 10px; }
        .workflow-desc { font-size: 14px; color: #666; line-height: 1.5; }
        a.button {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin: 10px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">🔙 返回主页</a>
        <h1>🚀 小说改编动画短剧工作流</h1>

        <div class="info">
            <h3>ℹ️ 功能说明</h3>
            <p>这是简化版工作流界面。</p>
            <p>要使用完整的工作流功能（包括提示词模板管理、大纲生成、文件包生成等），</p>
            <p>请先运行完整版服务器：<code>python scripts/local_server.py</code></p>
        </div>

        <div class="workflow-list">
            <div class="workflow-card">
                <div class="workflow-icon">📝</div>
                <div class="workflow-title">工作流1</div>
                <div class="workflow-desc">提示词模板管理</div>
            </div>
            <div class="workflow-card">
                <div class="workflow-icon">📖</div>
                <div class="workflow-title">工作流2</div>
                <div class="workflow-desc">短剧大纲生成</div>
            </div>
            <div class="workflow-card">
                <div class="workflow-icon">📦</div>
                <div class="workflow-title">工作流3</div>
                <div class="workflow-desc">完整文件包生成</div>
            </div>
        </div>

        <p style="text-align: center; margin-top: 30px;">
            <a href="/llm-config" class="button">⚙️ 配置LLM</a>
        </p>
    </div>
</body>
</html>
    '''


@app.route('/status')
def status():
    """系统状态"""
    try:
        import flask
        flask_version = flask.__version__
    except:
        flask_version = '未安装'

    status_info = {
        'python_version': sys.version,
        'project_root': project_root,
        'flask_version': flask_version,
        'llm_config_exists': os.path.exists(LLM_CONFIG_PATH),
    }

    return jsonify(status_info)


def main():
    """主函数"""
    print("\n📖 使用说明：")
    print("- 服务器地址：http://localhost:5001")
    print("- LLM配置：访问 http://localhost:5001/llm-config")
    print("- 停止服务器：按 Ctrl+C")
    print("\n✨ 新功能：Web界面LLM配置")
    print("- 在浏览器中直接配置LLM")
    print("- 无需手动编辑配置文件")
    print("- 支持连接测试")
    print()

    try:
        app.run(host='0.0.0.0', port=5001, debug=True)
    except KeyboardInterrupt:
        print("\n\n⏹️ 服务器已停止")
    except Exception as e:
        print(f"\n❌ 错误：{e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
