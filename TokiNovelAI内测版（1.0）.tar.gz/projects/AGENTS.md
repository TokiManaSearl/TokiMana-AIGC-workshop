# 小说改编动画短剧工作流系统

## 项目概述
- **名称**：小说改编动画短剧工作流系统
- **功能**：将长篇小说（10-20万字）改编成动画短剧，支持提示词模板管理、大纲生成、脚本生成、美术设定生成等功能
- **架构**：采用三个独立工作流，瀑布式执行（工作流1 → 工作流2 → 工作流3）
- **技术栈**：LangGraph 1.0, LangChain 1.0, Python 3.12, 大语言模型, Pydantic, Jinja2, 本地存储

## 节点清单

### 工作流1：提示词模板管理
| 节点名 | 文件位置 | 类型 | 功能描述 | 配置文件 |
|-------|---------|------|---------|---------|
| upload_template | `nodes/upload_template_node.py` | task | 上传提示词模板 | - |
| list_templates | `nodes/list_templates_node.py` | task | 列出所有提示词模板 | - |
| select_template | `nodes/select_template_node.py` | task | 选择提示词模板 | - |
| delete_template | `nodes/delete_template_node.py` | task | 删除提示词模板 | - |

### 工作流2：小说改编大纲生成
| 节点名 | 文件位置 | 类型 | 功能描述 | 配置文件 |
|-------|---------|------|---------|---------|
| upload_novel | `nodes/upload_novel_node.py` | task | 上传小说文件 | - |
| list_novels | `nodes/list_novels_node.py` | task | 列出所有小说 | - |
| select_novel | `nodes/select_novel_node.py` | task | 选择小说 | - |
| select_model | `nodes/select_model_node.py` | task | 选择大模型 | - |
| generate_outline | `nodes/generate_outline_node.py` | agent | 生成改编大纲 | `config/generate_outline_cfg.json` |

### 工作流3：生成改编文件包
| 节点名 | 文件位置 | 类型 | 功能描述 | 配置文件 |
|-------|---------|------|---------|---------|
| list_files | `nodes/list_files_node.py` | task | 列出所有文件 | - |
| load_template | `nodes/load_template_node.py` | task | 加载提示词模板 | - |
| list_outlines | `nodes/list_outlines_node.py` | task | 列出所有大纲 | - |
| load_outline | `nodes/load_outline_node.py` | task | 加载大纲 | - |
| generate_scripts | `nodes/generate_scripts_node.py` | agent | 生成剧集脚本（最多5集/批次，自动生成角色和场景美术设定） | `config/generate_scripts_cfg.json` |
| fill_episode_excel | `nodes/fill_episode_excel_node.py` | task | 填写分集Excel | - |
| fill_art_excel | `nodes/fill_art_excel_node.py` | task | 填写美术Excel | - |

**类型说明**：task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 工作流架构

### 工作流1：提示词模板管理
- **功能**：管理改编提示词模板（上传、列表、选择、删除）
- **核心节点**：
  - `upload_template`：上传提示词模板（支持三级优先级提取原始文件名，每次上传生成新的文件，不会覆盖旧文件）
  - `list_templates`：列出所有提示词模板（显示原始文件名）
  - `select_template`：选择提示词模板
  - `delete_template`：删除提示词模板（通过下拉框选择并删除）
- **UI优化**：
  - 模板选择下拉框旁边有[❌ 删除]按钮，方便快速删除
  - 删除后自动刷新列表
  - 每次上传都生成新文件，不会覆盖旧文件

### 工作流2：小说改编大纲生成
- **功能**：基于小说和提示词模板生成改编大纲
- **核心节点**：
  - `upload_novel`：上传小说文件（支持三级优先级提取原始文件名，每次上传生成新的文件，不会覆盖旧文件）
  - `list_novels`：列出所有小说（显示原始文件名）
  - `select_novel`：选择小说
  - `generate_outline`：生成改编大纲（使用大语言模型）
  - **自定义输出**：支持为生成的大纲指定自定义输出目录

### 工作流3：生成改编文件包
- **功能**：基于大纲生成剧集脚本，自动提取并生成角色和场景美术设定，并填写Excel模板
- **核心节点**：
  - `list_files`：列出所有文件（显示原始文件名）
  - `load_template`：加载提示词模板（用于查看）
  - `list_outlines`：列出所有大纲（用于选择）
  - `load_outline`：加载大纲内容
  - `generate_scripts`：生成剧集脚本（使用大语言模型，单次最多生成5集，自动生成角色和场景美术设定）
  - `fill_episode_excel`：填写分集Excel
  - `fill_art_excel`：填写美术Excel
- **功能特性**：
  - **批次控制**：单次最多生成5集脚本，避免超时
  - **自动美术设定**：每批次生成脚本后，自动从脚本中提取角色和场景信息，生成美术设定文档
  - **脚本格式**：每集包含简介、剧本正文、配音台本三个部分
  - **美术设定格式**：角色和场景美术设定为 `[名称]：[提示词]` 格式
  - **自定义输出**：支持为生成的文件包指定自定义输出目录

## 存储架构

### 存储适配器 (StorageAdapter)
- **位置**：`src/utils/storage_adapter.py`
- **功能**：统一的存储接口，自动在S3存储和本地存储之间切换
- **特点**：
  - 上传时同时备份到S3和本地存储
  - 读取时优先从S3读取，失败则从本地存储读取
  - 列表时如果S3返回空，自动从本地存储读取
  - 删除时同时删除S3和本地存储中的文件

### 本地存储模拟器 (LocalStorageSimulator)
- **位置**：`src/utils/local_storage.py`
- **功能**：本地文件系统存储，用于本地部署
- **特点**：
  - 支持元数据管理（content_type, size, original_name）
  - 元数据保存在 `{storage_path}/.metadata.json`
  - 文件保存在 `{storage_path}/` 目录下
  - **自定义输出目录**：支持通过 `CUSTOM_STORAGE_PATH` 环境变量指定自定义输出目录
  - **默认路径**：`assets/storage/`（相对于项目根目录）
  - **返回值**：本地文件的绝对路径

## 部署

### 本地部署
- **启动脚本**：`run_server.bat`（仅英文，避免乱码）
- **诊断脚本**：`diagnose.bat`
- **服务器**：Flask Web 服务器，运行在 `http://localhost:5000`
- **自动安装**：依赖会自动检查并安装
- **路径检测**：自动检测项目根目录

### 自定义输出目录

用户可以为存储生成的文件（大纲、文件包）指定自定义输出目录：

#### 方法1：环境变量
```bash
set CUSTOM_STORAGE_PATH=D:\MyOutputs
run_server.bat
```

#### 方法2：Web 界面
1. 打开 `http://localhost:5000`
2. 点击"设置"
3. 设置"自定义输出目录"
4. 保存配置

#### 方法3：API 请求
```bash
curl -X POST http://localhost:5000/workflow2/upload_novel \
  -F "novel_file=@novel.txt" \
  -F "custom_output_dir=D:\\MyOutputs"
```

#### 优先级
1. 环境变量 `CUSTOM_STORAGE_PATH`
2. Web 界面设置（功能开发中）
3. 默认：`assets/storage/`

## 文档

- **技术指南**：`技术说明.md` - 完整的技术文档
- **README**：`README.md` - 项目介绍
- **AGENTS.md**：本文件 - 项目结构和架构

## 快速开始

### 1. 启动服务器
```bash
run_server.bat
```

### 2. 打开 Web 界面
```
http://localhost:5000
```

### 3. 配置 LLM
点击"配置 LLM"并输入你的 API key

### 4. 使用工作流
- **工作流1**：上传和管理提示词模板
- **工作流2**：上传小说并生成大纲
- **工作流3**：生成完整的改编文件包
