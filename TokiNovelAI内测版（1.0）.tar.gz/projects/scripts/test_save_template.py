#!/usr/bin/env python3
"""测试脚本：测试工作流1的save_template节点"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from graphs.state import CallWorkflow1Input, CallWorkflow1Output, EditTemplateInput, SaveTemplateInput
from pydantic import ValidationError

def test_input_validation():
    """测试输入验证"""
    print("=" * 60)
    print("测试输入验证")
    print("=" * 60)

    # 测试1: EditTemplateInput - 缺少template_name
    print("\n测试1: EditTemplateInput - 缺少template_name（应该失败）")
    try:
        input_data = EditTemplateInput(new_content="测试内容")
        print("❌ 应该失败，但验证通过了")
        return False
    except ValidationError as e:
        print("✅ 验证失败（符合预期）")
        print(f"错误信息: {e.error_count()} 个错误")

    # 测试2: EditTemplateInput - 包含所有字段（应该成功）
    print("\n测试2: EditTemplateInput - 包含所有字段（应该成功）")
    try:
        input_data = EditTemplateInput(template_name="测试模板", new_content="测试内容")
        print("✅ 验证成功")
        print(f"  template_name: {input_data.template_name}")
        print(f"  new_content: {input_data.new_content}")
    except ValidationError as e:
        print("❌ 验证失败（不符合预期）")
        print(f"错误信息: {e}")
        return False

    # 测试3: SaveTemplateInput - 缺少template_name（应该失败）
    print("\n测试3: SaveTemplateInput - 缺少template_name（应该失败）")
    try:
        input_data = SaveTemplateInput(new_content="测试内容")
        print("❌ 应该失败，但验证通过了")
        return False
    except ValidationError as e:
        print("✅ 验证失败（符合预期）")
        print(f"错误信息: {e.error_count()} 个错误")

    # 测试4: SaveTemplateInput - 包含所有字段（应该成功）
    print("\n测试4: SaveTemplateInput - 包含所有字段（应该成功）")
    try:
        input_data = SaveTemplateInput(template_name="测试模板", edited_content="测试内容")
        print("✅ 验证成功")
        print(f"  template_name: {input_data.template_name}")
        print(f"  edited_content: {input_data.edited_content}")
    except ValidationError as e:
        print("❌ 验证失败（不符合预期）")
        print(f"错误信息: {e}")
        return False

    # 测试5: CallWorkflow1Input - save操作（应该成功）
    print("\n测试5: CallWorkflow1Input - save操作（应该成功）")
    try:
        input_data = CallWorkflow1Input(
            node_name="save_template",
            template_name="测试模板",
            new_content="测试内容"
        )
        print("✅ 验证成功")
        print(f"  workflow_id: {input_data.workflow_id}")
        print(f"  node_name: {input_data.node_name}")
        print(f"  template_name: {input_data.template_name}")
        print(f"  new_content: {input_data.new_content}")
    except ValidationError as e:
        print("❌ 验证失败（不符合预期）")
        print(f"错误信息: {e}")
        return False

    # 测试6: CallWorkflow1Input - edit操作（应该成功）
    print("\n测试6: CallWorkflow1Input - edit操作（应该成功）")
    try:
        input_data = CallWorkflow1Input(
            node_name="edit_template",
            template_name="测试模板",
            new_content="测试内容"
        )
        print("✅ 验证成功")
        print(f"  workflow_id: {input_data.workflow_id}")
        print(f"  node_name: {input_data.node_name}")
        print(f"  template_name: {input_data.template_name}")
        print(f"  new_content: {input_data.new_content}")
    except ValidationError as e:
        print("❌ 验证失败（不符合预期）")
        print(f"错误信息: {e}")
        return False

    print("\n" + "=" * 60)
    print("✅ 所有测试通过")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = test_input_validation()
    sys.exit(0 if success else 1)
