#!/usr/bin/env python3
"""测试脚本：测试所有工作流的输入输出验证"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from graphs.state import (
    CallWorkflow1Input, CallWorkflow2Input, CallWorkflow3Input,
    EditTemplateInput, SaveTemplateInput, GenerateOutlineInput,
    GenerateScriptsInput, CreatePackageInput
)
from pydantic import ValidationError

def test_all_inputs():
    """测试所有工作流的输入验证"""
    print("=" * 60)
    print("测试所有工作流的输入验证")
    print("=" * 60)

    # 测试工作流1: save_template
    print("\n测试工作流1: save_template")
    try:
        input_data = CallWorkflow1Input(
            node_name="save_template",
            template_name="测试模板",
            new_content="测试内容"
        )
        print("✅ 验证成功")
    except ValidationError as e:
        print(f"❌ 验证失败: {e}")
        return False

    # 测试工作流1: edit_template
    print("\n测试工作流1: edit_template")
    try:
        input_data = CallWorkflow1Input(
            node_name="edit_template",
            template_name="测试模板",
            new_content="测试内容"
        )
        print("✅ 验证成功")
    except ValidationError as e:
        print(f"❌ 验证失败: {e}")
        return False

    # 测试工作流2: generate_outline
    print("\n测试工作流2: generate_outline")
    try:
        input_data = CallWorkflow2Input(
            node_name="generate_outline",
            model_name="doubao-seed-1-8-251228"
        )
        print("✅ 验证成功")
    except ValidationError as e:
        print(f"❌ 验证失败: {e}")
        return False

    # 测试工作流3: generate_scripts
    print("\n测试工作流3: generate_scripts")
    try:
        input_data = CallWorkflow3Input(
            node_name="generate_scripts"
        )
        print("✅ 验证成功")
    except ValidationError as e:
        print(f"❌ 验证失败: {e}")
        return False

    # 测试工作流3: create_package
    print("\n测试工作流3: create_package")
    try:
        input_data = CallWorkflow3Input(
            node_name="create_package"
        )
        print("✅ 验证成功")
    except ValidationError as e:
        print(f"❌ 验证失败: {e}")
        return False

    # 测试节点输入输出定义
    print("\n测试节点输入输出定义")
    print("  EditTemplateInput: template_name (required), new_content (required)")
    print("  SaveTemplateInput: template_name (required), edited_content (required)")
    print("  GenerateOutlineInput: novel_content (optional), template_content (optional)")
    print("  GenerateScriptsInput: outline_content (optional), template_content (optional)")
    print("  CreatePackageInput: excel_files (optional)")

    print("\n" + "=" * 60)
    print("✅ 所有测试通过")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = test_all_inputs()
    sys.exit(0 if success else 1)
