"""
保存提示词模板节点（图形化版）
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from graphs.state import SaveTemplateInput, SaveTemplateOutput


def save_template_node(
    state: SaveTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SaveTemplateOutput:
    """
    title: 保存模板
    desc: 点击保存按钮，保存编辑后的模板
    integrations: 对象存储
    """
    ctx = runtime.context

    template_name = state.template_name
    edited_content = state.edited_content

    if not template_name or not edited_content:
        return SaveTemplateOutput(
            saved_url="",
            message="❌ 模板名称或内容不能为空"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return SaveTemplateOutput(
            saved_url="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 生成安全的文件名（不使用时间戳，相同文件名生成相同key以支持覆盖）
    safe_filename, _ = get_safe_filename(template_name, category="template", use_timestamp=False)
    storage_key = f"templates/{safe_filename}"

    # 上传文件
    try:
        file_key = storage.upload_file(
            file_content=edited_content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/markdown",
            original_name=template_name
        )

        # 生成访问URL
        file_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

        return SaveTemplateOutput(
            saved_url=file_url,
            message=f"✅ 成功保存模板：{template_name}"
        )
    except Exception as e:
        return SaveTemplateOutput(
            saved_url="",
            message=f"❌ 保存模板失败: {str(e)}"
        )
