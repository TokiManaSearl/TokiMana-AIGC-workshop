"""Delete novel node for workflow 2"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import DeleteNovelInput, DeleteNovelOutput


def delete_novel_node(
    state: DeleteNovelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> DeleteNovelOutput:
    """
    title: Delete Novel
    desc: Delete a novel by name
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return DeleteNovelOutput(
            novels=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    novels = []
    try:
        # 根据原始文件名查找对应的文件key
        target_file_key = None
        result = storage.list_files(prefix="novels/")
        
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")
                
                # 如果原始文件名匹配，则找到目标文件
                if original_name == state.novel_name or file_key.split("/")[-1] == state.novel_name:
                    target_file_key = file_key
                    break
            except Exception as e:
                print(f"读取文件元数据失败: {e}")
        
        if not target_file_key:
            # 如果没有找到，尝试直接匹配（向后兼容）
            target_file_key = f"novels/{state.novel_name}"
            if not target_file_key.endswith(".txt"):
                target_file_key += ".txt"
        
        # Delete file from storage
        if target_file_key:
            storage.delete_file(file_key=target_file_key)
        else:
            return DeleteNovelOutput(
                novels=[],
                message=f"❌ 未找到小说: {state.novel_name}"
            )
        
        # List remaining novels
        result = storage.list_files(prefix="novels/")
        novels = []
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")
                
                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1].replace(".txt", "")
                
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                novels.append({"name": display_name, "url": url})
            except Exception as e:
                print(f"处理文件信息失败: {e}")
    except Exception as e:
        return DeleteNovelOutput(
            novels=[],
            message=f"❌ 删除小说失败: {str(e)}"
        )
    
    return DeleteNovelOutput(
        novels=novels,
        message=f"✅ 小说 '{state.novel_name}' 已删除"
    )
