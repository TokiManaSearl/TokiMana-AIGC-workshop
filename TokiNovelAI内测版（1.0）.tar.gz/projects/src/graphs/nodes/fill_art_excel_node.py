"""
填写美术Excel节点
"""
import os
import tempfile
import openpyxl
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from graphs.state import FillArtExcelInput, FillArtExcelOutput


def fill_art_excel_node(
    state: FillArtExcelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> FillArtExcelOutput:
    """
    title: 填写美术资产导入Excel
    desc: 将生成的美术设定填写到美术资产导入Excel模板中，并上传到对象存储
    integrations: 对象存储
    """
    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return FillArtExcelOutput(
            excel_file=File(url="", file_type="document"),
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 创建临时目录
    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, "filled_art_excel.xlsx")

    try:
        # 创建新的Excel文件
        wb = openpyxl.Workbook()

        # 角色设定Sheet
        ws_char = wb.active
        ws_char.title = "角色设定"
        char_headers = ["角色名称", "别名", "描述", "AI提示词", "备注", "性别", "年龄", "位置", "类型", "基础特征", "发型", "面部特征", "服装", "性格", "职业"]
        ws_char.append(char_headers)

        for char in state.character_settings:
            row = [
                char.get("name", ""),
                char.get("alias", ""),
                char.get("description", ""),
                char.get("ai_prompt", ""),
                char.get("note", ""),
                char.get("gender", ""),
                char.get("age", ""),
                char.get("position", ""),
                char.get("type", ""),
                char.get("basic_features", ""),
                char.get("hairstyle", ""),
                char.get("facial_features", ""),
                char.get("clothing", ""),
                char.get("personality", ""),
                char.get("profession", "")
            ]
            ws_char.append(row)

        # 场景设定Sheet
        ws_scene = wb.create_sheet(title="场景设定")
        scene_headers = ["场景名称", "描述", "AI提示词", "环境", "备注"]
        ws_scene.append(scene_headers)

        for scene in state.scene_settings:
            row = [
                scene.get("name", ""),
                scene.get("description", ""),
                scene.get("ai_prompt", ""),
                scene.get("environment", ""),
                scene.get("note", "")
            ]
            ws_scene.append(row)

        # 道具设定Sheet
        ws_prop = wb.create_sheet(title="道具设定")
        prop_headers = ["道具名称", "描述", "AI提示词", "使用方式", "备注"]
        ws_prop.append(prop_headers)

        for prop in state.prop_settings:
            row = [
                prop.get("name", ""),
                prop.get("description", ""),
                prop.get("ai_prompt", ""),
                prop.get("usage", ""),
                prop.get("note", "")
            ]
            ws_prop.append(row)

        # 如果没有数据，添加默认行
        if not state.character_settings:
            ws_char.append(["角色1", "", "示例角色", "AI提示词", "", "男", "25", "主角", "主角", "特征", "发型", "面部", "服装", "性格", "职业"])

        if not state.scene_settings:
            ws_scene.append(["场景1", "示例场景", "AI提示词", "环境", ""])

        if not state.prop_settings:
            ws_prop.append(["道具1", "示例道具", "AI提示词", "使用方式", ""])

        # 保存Excel
        wb.save(output_path)

        # 读取Excel文件内容
        with open(output_path, 'rb') as f:
            excel_content = f.read()

        # 生成安全的文件名和中文名称（使用时间戳，每次生成不同文件名）
        original_name = "美术资产导入表_已填写.xlsx"
        safe_filename, _ = get_safe_filename(original_name, category="excel", use_timestamp=True)
        storage_key = f"excel/{safe_filename}"

        # 上传到对象存储
        file_key = storage.upload_file(
            file_content=excel_content,
            file_name=storage_key,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            original_name=original_name
        )

        # 生成访问URL
        filled_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

        return FillArtExcelOutput(
            excel_file=File(url=filled_url, file_type="document"),
            message=f"✅ 美术Excel已填写，包含{len(state.character_settings)}个角色、{len(state.scene_settings)}个场景、{len(state.prop_settings)}个道具"
        )

    except Exception as e:
        return FillArtExcelOutput(
            excel_file=File(url="", file_type="document"),
            message=f"❌ 填写美术Excel失败: {str(e)}"
        )
    finally:
        # 清理临时文件
        if os.path.exists(output_path):
            os.remove(output_path)
