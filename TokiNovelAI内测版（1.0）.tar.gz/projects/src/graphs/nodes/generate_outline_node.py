"""
生成大纲节点（图形化版）
"""
import os
import json
import time
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import GenerateOutlineInput, GenerateOutlineOutput


def generate_outline_node(
    state: GenerateOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateOutlineOutput:
    """
    title: 生成大纲
    desc: 根据上传的小说生成短剧剧集大纲
    """
    ctx = runtime.context

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return GenerateOutlineOutput(
            outline_url="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 读取小说内容
    novels_result = storage.list_files(prefix="novels/")
    novel_keys = novels_result.get("keys", [])

    if not novel_keys:
        return GenerateOutlineOutput(
            outline_url="",
            message="❌ 请先上传小说文件"
        )

    # 获取第一本小说
    novel_key = novel_keys[-1]
    try:
        novel_bytes = storage.read_file(novel_key)
        novel_content = novel_bytes.decode('utf-8')
    except Exception as e:
        return GenerateOutlineOutput(
            outline_url="",
            message=f"❌ 读取小说文件失败: {str(e)}"
        )

    # 加载提示词模板
    templates_result = storage.list_files(prefix="templates/")
    template_keys = templates_result.get("keys", [])

    if template_keys:
        template_key = template_keys[-1]  # 获取最新的模板
        try:
            template_bytes = storage.read_file(template_key)
            template_content = template_bytes.decode('utf-8')
        except Exception as e:
            template_content = "# 默认提示词模板\n## 1. 剧情伦理审查规则\n- 禁止血腥暴力、恐怖、情色、自残\n\n## 2. 角色命名规则\n- 主角类：[主角+姓名]\n- 反派类：[主要反派+姓名]\n\n## 3. 输出格式\n- 脚本需包含简介、剧本正文、结尾配音台本"
    else:
        template_content = "# 默认提示词模板\n## 1. 剧情伦理审查规则\n- 禁止血腥暴力、恐怖、情色、自残\n\n## 2. 角色命名规则\n- 主角类：[主角+姓名]\n- 反派类：[主要反派+姓名]\n\n## 3. 输出格式\n- 脚本需包含简介、剧本正文、结尾配音台本"

    # 读取LLM配置
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_outline_cfg.json")
    with open(cfg_file, 'r', encoding='utf-8') as fd:
        _cfg = json.load(fd)

    llm_config = _cfg.get("config", {})
    sp = _cfg.get("sp", "")
    up = _cfg.get("up", "")

    # 渲染用户提示词
    up_tpl = Template(up)
    user_prompt = up_tpl.render(
        template_content=template_content,
        novel_content=novel_content
    )

    # 创建LLM客户端（使用新的LLM提供商系统，自动从前端配置获取模型）
    from utils.llm.llm_client import create_llm_client
    client = create_llm_client(ctx=runtime.context)

    # 组装消息
    from langchain_core.messages import HumanMessage, SystemMessage
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    # 调用LLM（使用前端配置的模型）
    try:
        response = client.invoke(
            messages=messages,
            # 不再传递model参数，让LLM客户端自动从前端配置获取
            temperature=0.7,
            top_p=0.9,
            max_completion_tokens=32768,
            thinking="disabled"
        )

        # 提取响应内容
        if isinstance(response.content, str):
            outline_content = response.content
        else:
            outline_content = str(response.content)

        # 验证并确保内容是有效的UTF-8
        try:
            # 尝试编码为UTF-8以验证
            outline_content.encode('utf-8')
        except (UnicodeEncodeError, AttributeError) as e:
            # 尝试修复编码
            try:
                if isinstance(outline_content, bytes):
                    outline_content = outline_content.decode('utf-8', errors='replace')
            except Exception as e2:
                return GenerateOutlineOutput(
                    outline_content="",
                    outline_url="",
                    message=f"❌ 编码错误，无法保存大纲: {str(e)}"
                )

        # 保存到对象存储
        timestamp = int(time.time())
        safe_filename = f"short_drama_outline_{timestamp}.md"
        storage_key = f"outlines/{safe_filename}"

        file_key = storage.upload_file(
            file_content=outline_content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/markdown; charset=utf-8",
            original_name=f"短剧大纲_{timestamp}.md"
        )

        # 生成访问URL（本地存储模式返回绝对路径）
        outline_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

        # 如果是本地存储模式，返回本地路径
        if not storage.use_s3 and storage.local_storage:
            outline_url = storage.local_storage.generate_presigned_url(key=storage_key, expire_time=3600)
            message = f"""✅ 成功生成短剧剧集大纲！

📝 大纲信息：
   - 文件名：短剧大纲_{timestamp}.md
   - 字符数：{len(outline_content):,} 字符

💾 文件位置：
   {outline_url}

💡 使用方法：
   1. 在资源管理器中打开上述路径
   2. 找到大纲文件：短剧大纲_{timestamp}.md
   3. 用文本编辑器或Word打开查看
"""
        else:
            message = f"✅ 成功生成短剧剧集大纲！已保存到对象存储"

        return GenerateOutlineOutput(
            outline_content=outline_content,
            outline_url=outline_url,
            message=message
        )

    except Exception as e:
        return GenerateOutlineOutput(
            outline_content="",  # 必填字段，设置为空字符串
            outline_url="",
            message=f"❌ 生成大纲失败：{str(e)}"
        )
