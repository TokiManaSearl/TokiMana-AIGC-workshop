"""Save outline node for workflow 2"""
import os
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk.s3 import S3SyncStorage
from utils.file_utils import get_safe_filename
from graphs.state import SaveOutlineInput, SaveOutlineOutput


def save_outline_node(
    state: SaveOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SaveOutlineOutput:
    """
    title: Save Outline
    desc: Save generated outline to storage
    integrations: 对象存储
    """
    # 初始化对象存储
    try:
        storage = S3SyncStorage(
            endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
            access_key="",
            secret_key="",
            bucket_name=os.getenv("COZE_BUCKET_NAME"),
            region="cn-beijing",
        )
    except Exception as e:
        return SaveOutlineOutput(
            saved_url="",
            message=f"❌ 初始化对象存储服务失败: {str(e)}"
        )
    
    saved_url = ""
    try:
        # 生成安全的文件名（不使用时间戳，支持覆盖）
        safe_filename, _ = get_safe_filename("outline.md", category="outline", use_timestamp=False)
        outline_key = f"outlines/{safe_filename}"
        
        # Save outline to storage
        outline_content = state.outline_content.encode('utf-8')
        file_key = storage.upload_file(
            file_content=outline_content,
            file_name=outline_key,
            content_type="text/markdown"
        )
        
        # 生成访问URL
        saved_url = storage.generate_presigned_url(key=file_key, expire_time=3600)
    except Exception as e:
        return SaveOutlineOutput(
            saved_url="",
            message=f"❌ 保存大纲失败: {str(e)}"
        )
    
    return SaveOutlineOutput(
        saved_url=saved_url,
        message="✅ 大纲已保存"
    )
