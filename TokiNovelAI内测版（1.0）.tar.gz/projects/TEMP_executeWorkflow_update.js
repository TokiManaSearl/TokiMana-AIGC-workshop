// executeWorkflow函数的更新版本，用于替换scripts/local_server.py中的对应部分

// 执行工作流
async function executeWorkflow(workflowId, params) {
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const resultContent = document.getElementById('result-content');
    
    loading.style.display = 'block';
    result.style.display = 'none';
    
    try {
        const formData = new FormData();
        formData.append('workflow_id', workflowId);
        
        // 添加文件
        if (workflowId === 1) {
            const fileInput = document.getElementById('template_file');
            if (fileInput.files[0]) {
                formData.append('file', fileInput.files[0]);
            }
        } else if (workflowId === 2) {
            const fileInput = document.getElementById('novel_file');
            if (fileInput.files[0]) {
                formData.append('file', fileInput.files[0]);
            }
        }
        
        // 添加参数
        Object.keys(params).forEach(key => {
            formData.append(key, params[key]);
        });
        
        const response = await fetch('/execute', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            resultContent.textContent = JSON.stringify(data, null, 2);
            
            // 特殊处理：如果是工作流1的列出提示词，填充下拉框
            if (workflowId === 1 && params.node_name === 'list_templates' && data.templates) {
                populateTemplateDropdown(data.templates);
                // 同时填充工作流2的下拉框
                populateTemplateDropdownForWorkflow2(data.templates);
            }
            
            // 特殊处理：如果是工作流1的选择提示词，显示内容
            if (workflowId === 1 && params.node_name === 'select_template') {
                if (data.template_content) {
                    document.getElementById('template_content').value = data.template_content;
                }
            }
            
            // 特殊处理：如果是工作流2的加载提示词，显示内容
            if (workflowId === 2 && params.node_name === 'load_template' && data.template_content) {
                document.getElementById('template_content_w2').value = data.template_content;
            }
        } else {
            resultContent.textContent = '错误：' + (data.error || '未知错误');
        }
    } catch (error) {
        resultContent.textContent = '错误：' + error.message;
    }
    
    loading.style.display = 'none';
    result.style.display = 'block';
}

// 填充模板下拉框（工作流1）
function populateTemplateDropdown(templates) {
    const select = document.getElementById('template_select');
    const selectGroup = document.getElementById('template_select_group');
    
    // 清空现有选项
    select.innerHTML = '<option value="">-- 请选择 --</option>';
    
    // 添加模板选项
    templates.forEach(template => {
        const option = document.createElement('option');
        option.value = template.name;
        option.textContent = template.name;
        select.appendChild(option);
    });
    
    // 显示下拉框
    if (templates.length > 0) {
        selectGroup.style.display = 'block';
    }
}

// 填充模板下拉框（工作流2）
function populateTemplateDropdownForWorkflow2(templates) {
    const select = document.getElementById('template_select_w2');
    const selectGroup = document.getElementById('template_select_group_w2');
    
    // 清空现有选项
    select.innerHTML = '<option value="">-- 请选择 --</option>';
    
    // 添加模板选项
    templates.forEach(template => {
        const option = document.createElement('option');
        option.value = template.name;
        option.textContent = template.name;
        select.appendChild(option);
    });
    
    // 显示下拉框
    if (templates.length > 0) {
        selectGroup.style.display = 'block';
    }
}

// 从下拉框选择模板（工作流1）
function selectTemplateFromDropdown() {
    const select = document.getElementById('template_select');
    const selectedTemplate = select.value;
    
    if (selectedTemplate) {
        // 填充模板名称
        document.getElementById('template_name').value = selectedTemplate;
        
        // 自动切换到"选择提示词"节点
        const selectTemplateButton = document.querySelector('#workflow1-form .node-button[data-node="select_template"]');
        if (selectTemplateButton) {
            document.querySelectorAll('#workflow1-form .node-button').forEach(btn => btn.classList.remove('active'));
            selectTemplateButton.classList.add('active');
        }
    }
}

// 从下拉框选择模板（工作流2）
function selectTemplateForWorkflow2() {
    const select = document.getElementById('template_select_w2');
    const selectedTemplate = select.value;
    
    if (selectedTemplate) {
        // 自动切换到"加载提示词"节点
        const loadTemplateButton = document.querySelector('#workflow2-form .node-button[data-node="load_template"]');
        if (loadTemplateButton) {
            document.querySelectorAll('#workflow2-form .node-button').forEach(btn => btn.classList.remove('active'));
            loadTemplateButton.classList.add('active');
        }
    }
}
