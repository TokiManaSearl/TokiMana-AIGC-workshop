"""
本地文件系统存储模拟器
用于在S3存储不可用时提供备用存储方案
"""
import os
import json
from typing import Dict, List, Optional
from pathlib import Path


class LocalStorageSimulator:
    """本地文件系统存储模拟器"""

    def __init__(self, base_path: str = None):
        # 优先级：环境变量 > 参数 > 默认路径
        from pathlib import Path
        
        if base_path is None:
            # 1. 尝试从环境变量读取自定义路径
            base_path = os.getenv('CUSTOM_STORAGE_PATH')

        if base_path is None:
            # 2. 如果没有指定，使用项目根目录下的 assets/storage
            try:
                # 获取当前文件所在目录的父级（utils/），再父级（src/），再父级（项目根）
                current_file = Path(__file__)
                project_root = current_file.parent.parent.parent
                base_path = str(project_root / "assets" / "storage")
            except Exception:
                # 如果获取失败，使用默认路径
                base_path = "/tmp/local_storage"

        # 确保路径是绝对路径
        self.base_path = Path(base_path).absolute()
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._metadata_file = self.base_path / ".metadata.json"
        self._metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict[str, Dict]:
        """加载元数据"""
        if self._metadata_file.exists():
            with open(self._metadata_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_metadata(self):
        """保存元数据"""
        with open(self._metadata_file, 'w', encoding='utf-8') as f:
            json.dump(self._metadata, f, ensure_ascii=False, indent=2)
    
    def upload_file(self, file_content: bytes, file_name: str, content_type: str = "text/plain", original_name: str = "") -> str:
        """上传文件到本地存储"""
        file_path = self.base_path / file_name
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        # 保存元数据（包含原始文件名）
        # 标准化文件键（处理Windows路径的反斜杠问题）
        normalized_file_name = str(file_name).replace("\\", "/")
        self._metadata[normalized_file_name] = {
            "content_type": content_type,
            "size": len(file_content),
            "original_name": original_name  # 保存原始文件名
        }
        self._save_metadata()
        
        return str(file_name)
    
    def read_file(self, file_key: str) -> bytes:
        """读取文件内容"""
        file_path = self.base_path / file_key
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_key}")
        
        with open(file_path, 'rb') as f:
            return f.read()
    
    def delete_file(self, file_key: str) -> bool:
        """删除文件"""
        try:
            # 标准化文件键（处理Windows路径的反斜杠问题）
            normalized_key = file_key.replace("\\", "/")
            
            print(f"[DEBUG] LocalStorageSimulator.delete_file: file_key={file_key}, normalized_key={normalized_key}")
            print(f"[DEBUG] Base path: {self.base_path}")
            print(f"[DEBUG] File path: {self.base_path / file_key}")
            print(f"[DEBUG] File exists: {(self.base_path / file_key).exists()}")
            print(f"[DEBUG] Metadata keys: {list(self._metadata.keys())}")
            
            file_path = self.base_path / file_key
            
            # 检查文件是否存在
            if not file_path.exists():
                print(f"[ERROR] File not found: {file_path}")
                return False
            
            # 删除文件
            try:
                file_path.unlink()
                print(f"[DEBUG] File deleted successfully: {file_path}")
            except Exception as e:
                print(f"[ERROR] Failed to delete file: {e}")
                return False
            
            # 删除元数据
            try:
                if normalized_key in self._metadata:
                    print(f"[DEBUG] Deleting metadata for key: {normalized_key}")
                    del self._metadata[normalized_key]
                    self._save_metadata()
                    print(f"[DEBUG] Metadata deleted successfully")
                else:
                    print(f"[WARNING] Metadata key not found: {normalized_key}")
                    # 即使元数据不存在，文件已经删除，仍然返回True
                    print(f"[DEBUG] File deleted, metadata not found, returning True")
            except Exception as e:
                print(f"[WARNING] Failed to delete metadata (but file was deleted): {e}")
                # 即使元数据删除失败，文件已经删除，仍然返回True
                print(f"[DEBUG] File deleted, metadata deletion failed, returning True")
            
            return True
            
        except Exception as e:
            print(f"[ERROR] Unexpected error in delete_file: {e}")
            import traceback
            print(f"[ERROR] Traceback: {traceback.format_exc()}")
            return False
    
    def file_exists(self, file_key: str) -> bool:
        """检查文件是否存在"""
        file_path = self.base_path / file_key
        return file_path.exists()
    
    def list_files(self, prefix: str = "", max_keys: int = 1000) -> Dict[str, List[str]]:
        """列出文件"""
        keys = []
        if prefix:
            search_path = self.base_path / prefix
            if search_path.is_dir():
                for file_path in search_path.rglob("*"):
                    if file_path.is_file():
                        # 获取相对路径
                        rel_path = file_path.relative_to(self.base_path)
                        # 标准化路径分隔符为正斜杠（跨平台兼容）
                        keys.append(str(rel_path).replace("\\", "/"))
        else:
            for file_path in self.base_path.rglob("*"):
                if file_path.is_file() and file_path.name != ".metadata.json":
                    rel_path = file_path.relative_to(self.base_path)
                    # 标准化路径分隔符为正斜杠（跨平台兼容）
                    keys.append(str(rel_path).replace("\\", "/"))
        
        # 排序并限制数量
        keys = sorted(keys)[:max_keys]
        
        return {
            "keys": keys,
            "is_truncated": len(keys) >= max_keys,
            "next_continuation_token": None
        }
    
    def get_file_metadata(self, file_key: str) -> Dict:
        """获取文件元数据"""
        # 标准化文件键（处理Windows路径的反斜杠问题）
        normalized_key = file_key.replace("\\", "/")
        return self._metadata.get(normalized_key, {})
    
    def generate_presigned_url(self, key: str, expire_time: int = 3600) -> str:
        """生成访问URL（模拟）"""
        # 本地存储返回文件路径
        # 返回绝对路径，方便用户找到文件
        file_path = self.base_path / key
        return str(file_path.absolute())


# 全局实例
_local_storage_instance: Optional[LocalStorageSimulator] = None
_current_storage_path: Optional[str] = None


def get_local_storage() -> LocalStorageSimulator:
    """获取本地存储实例"""
    global _local_storage_instance, _current_storage_path
    
    # 计算当前的存储路径
    current_path = os.getenv('CUSTOM_STORAGE_PATH')
    if current_path is None:
        try:
            from pathlib import Path
            # 获取当前文件所在目录的父级（utils/），再父级（src/），再父级（项目根）
            current_file = Path(__file__)
            project_root = current_file.parent.parent.parent
            current_path = str(project_root / "assets" / "storage")
        except Exception:
            # 如果获取失败，使用默认路径
            current_path = "/tmp/local_storage"
    
    # 如果路径改变了，重新创建实例
    if _current_storage_path != current_path or _local_storage_instance is None:
        _local_storage_instance = LocalStorageSimulator(base_path=current_path)
        _current_storage_path = current_path
    
    return _local_storage_instance
