"""
LLM提供商管理器
支持多个LLM提供商：火山方舟、DeepSeek、Gemini、OpenAI、通义千问、智谱AI等
"""
import os
import json
from typing import Optional, Dict, Any, List
from enum import Enum
from openai import OpenAI


class LLMProviderType(str, Enum):
    """LLM提供商类型"""
    VOLCANO_ARK = "volcano_ark"
    DEEPSEEK = "deepseek"
    GEMINI = "gemini"
    OPENAI = "openai"
    QIANWEN = "qianwen"
    ZHIPU = "zhipu"
    CUSTOM = "custom"


class LLMProvider:
    """LLM提供商管理类"""

    def __init__(self, config_path: Optional[str] = None):
        """
        初始化LLM提供商管理器

        Args:
            config_path: 配置文件路径，默认为 config/llm_providers.json
        """
        self.project_root = os.getenv("COZE_WORKSPACE_PATH", "")
        if config_path is None:
            config_path = os.path.join(self.project_root, "config", "llm_providers.json")

        self.config_path = config_path
        self.config = self._load_config()
        self.enabled_provider = self._get_enabled_provider()

    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        if not os.path.exists(self.config_path):
            # 如果配置文件不存在，返回默认配置
            return {
                "enabled_provider": "",
                "providers": {}
            }

        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        return config

    def _save_config(self) -> None:
        """保存配置文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def _get_enabled_provider(self) -> str:
        """获取当前启用的提供商"""
        # 优先使用环境变量
        env_provider = os.getenv("LLM_PROVIDER")
        if env_provider and env_provider in self.config.get("providers", {}):
            return env_provider

        # 否则使用配置文件中的设置
        return self.config.get("enabled_provider", "")

    def get_providers_list(self) -> List[Dict[str, Any]]:
        """获取所有提供商列表"""
        providers = []
        for provider_id, provider_config in self.config.get("providers", {}).items():
            providers.append({
                "id": provider_id,
                "name": provider_config.get("name", provider_id),
                "description": provider_config.get("description", ""),
                "enabled": provider_config.get("enabled", False),
                "configured": bool(provider_config.get("config", {}).get("api_key", ""))
            })
        return providers

    def get_provider_config(self, provider_id: str) -> Optional[Dict[str, Any]]:
        """获取指定提供商的配置"""
        return self.config.get("providers", {}).get(provider_id)

    def update_provider_config(self, provider_id: str, config: Dict[str, Any]) -> bool:
        """
        更新提供商配置

        Args:
            provider_id: 提供商ID
            config: 配置字典

        Returns:
            是否更新成功
        """
        if provider_id not in self.config.get("providers", {}):
            return False

        self.config["providers"][provider_id]["config"].update(config)
        self._save_config()
        return True

    def enable_provider(self, provider_id: str) -> bool:
        """
        启用指定的提供商

        Args:
            provider_id: 提供商ID

        Returns:
            是否启用成功
        """
        if provider_id not in self.config.get("providers", {}):
            return False

        # 禁用所有提供商
        for pid in self.config["providers"]:
            self.config["providers"][pid]["enabled"] = False

        # 启用指定的提供商
        self.config["providers"][provider_id]["enabled"] = True
        self.config["enabled_provider"] = provider_id
        self._save_config()

        # 更新当前启用的提供商
        self.enabled_provider = provider_id
        return True

    def get_current_provider(self) -> str:
        """获取当前启用的提供商ID"""
        return self.enabled_provider

    def get_client(self) -> OpenAI:
        """
        获取OpenAI客户端（兼容所有OpenAI兼容的API）

        Returns:
            OpenAI客户端实例

        Raises:
            ValueError: 如果未配置提供商或API Key
        """
        if not self.enabled_provider:
            raise ValueError("未启用任何提供商，请先在前端配置页面选择并启用一个提供商")
        
        provider_config = self.get_provider_config(self.enabled_provider)
        if not provider_config:
            raise ValueError(f"提供商 {self.enabled_provider} 不存在")

        config = provider_config.get("config", {})

        # 检查是否配置了API Key
        api_key = config.get("api_key", "")
        if not api_key:
            # 尝试从环境变量读取
            env_key = f"{self.enabled_provider.upper()}_API_KEY"
            api_key = os.getenv(env_key, "")

            if not api_key:
                raise ValueError(f"未配置API Key，请在前端配置页面或环境变量中设置 {env_key}")

        # 创建OpenAI客户端（添加超时保护）
        endpoint = config.get("endpoint", "")
        if not endpoint:
            raise ValueError("未配置API端点")

        # 导入httpx.Timeout用于设置超时
        try:
            from httpx import Timeout
            # 设置超时：连接超时10秒，读取超时600秒（10分钟）
            timeout = Timeout(connect=10.0, read=600.0, write=30.0, pool=30.0)
            client = OpenAI(
                api_key=api_key,
                base_url=endpoint,
                timeout=timeout,
                max_retries=2  # 最多重试2次
            )
        except ImportError:
            # 如果httpx不可用，使用简单的数字超时
            client = OpenAI(
                api_key=api_key,
                base_url=endpoint,
                timeout=600.0,  # 10分钟超时
                max_retries=2
            )

        return client

    def call_llm(
        self,
        messages: List[Any],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        调用LLM

        Args:
            messages: 消息列表
            model: 模型名称（可选，默认使用配置中的模型）
            temperature: 温度参数（可选）
            max_tokens: 最大token数（可选）
            **kwargs: 其他参数

        Returns:
            LLM返回的文本内容
        """
        # 获取提供商配置
        provider_config = self.get_provider_config(self.enabled_provider)
        if not provider_config:
            raise ValueError(f"提供商 {self.enabled_provider} 不存在")

        config = provider_config.get("config", {})

        # 获取模型参数
        llm_model = model or config.get("model", "")
        if not llm_model:
            raise ValueError("未配置模型名称")

        # 获取温度参数，确保是float类型
        if temperature is not None:
            llm_temperature = float(temperature)
        else:
            llm_temperature = float(config.get("temperature", 0.7))

        # 获取最大token数，确保是int类型
        if max_tokens is not None:
            llm_max_tokens = int(max_tokens)
        else:
            llm_max_tokens = int(config.get("max_tokens", 4096))

        # 获取客户端
        client = self.get_client()

        # 计算输入token数量（估算）
        input_text = "\n".join([msg.get("content", "") for msg in messages])
        estimated_input_tokens = len(input_text) // 2  # 粗略估算：2个字符≈1个token

        # 调用LLM（添加日志输出）
        print(f"\n🤖 调用LLM模型：{llm_model}")
        print(f"📊 输入参数：")
        print(f"   - 温度：{llm_temperature}")
        print(f"   - 最大token数：{llm_max_tokens}")
        print(f"   - 估算输入token数：{estimated_input_tokens:,} 字符")
        print(f"⏳ 正在请求LLM API（最长等待10分钟）...")
        
        try:
            import time
            start_time = time.time()
            
            response = client.chat.completions.create(
                model=llm_model,
                messages=messages,
                temperature=llm_temperature,
                max_tokens=llm_max_tokens,
                **kwargs
            )
            
            elapsed_time = time.time() - start_time
            output_text = response.choices[0].message.content
            
            # 计算输出token数量（估算）
            estimated_output_tokens = len(output_text) // 2
            
            print(f"✅ LLM调用成功！")
            print(f"📊 输出统计：")
            print(f"   - 耗时：{elapsed_time:.1f}秒")
            print(f"   - 估算输出token数：{estimated_output_tokens:,} 字符")
            print(f"   - 速度：{estimated_output_tokens / elapsed_time:.1f} 字符/秒")
            print(f"")
            
            return output_text
        except Exception as e:
            print(f"❌ LLM调用失败！")
            error_msg = str(e)
            # 提供更详细的错误提示
            if "timeout" in error_msg.lower() or "timed out" in error_msg.lower():
                raise Exception(
                    f"LLM调用超时（10分钟）。可能的原因：\n"
                    f"1. 输入内容太长（约{estimated_input_tokens:,} 字符）\n"
                    f"2. 服务器处理时间过长\n"
                    f"3. 网络连接问题\n"
                    f"建议：尝试缩短输入内容或使用更快的模型\n"
                    f"原始错误: {error_msg}"
                )
            elif "no available channels" in error_msg:
                raise Exception(
                    f"LLM调用失败：模型 '{llm_model}' 不可用。请检查：\n"
                    f"1. 模型ID格式是否正确（火山方舟应为 'ep-xxxxx' 格式）\n"
                    f"2. 接入点是否已创建并启用\n"
                    f"3. API Key是否正确\n"
                    f"原始错误: {error_msg}"
                )
            elif "401" in error_msg or "Unauthorized" in error_msg or "Invalid API key" in error_msg:
                raise Exception(
                    f"LLM调用失败：API Key无效或未配置。请检查：\n"
                    f"1. API Key是否正确填写\n"
                    f"2. API Key是否已过期\n"
                    f"原始错误: {error_msg}"
                )
            elif "404" in error_msg or "Not Found" in error_msg:
                raise Exception(
                    f"LLM调用失败：模型 '{llm_model}' 不存在。请检查：\n"
                    f"1. 模型ID是否正确（火山方舟应为 'ep-xxxxx' 格式）\n"
                    f"2. 接入点是否已创建\n"
                    f"原始错误: {error_msg}"
                )
            else:
                raise Exception(f"LLM调用失败: {error_msg}")
    
    def call_llm_with_config(
        self,
        llm_cfg: Dict[str, Any],
        messages: List[Any],
        **kwargs
    ) -> str:
        """
        使用指定的LLM配置调用LLM

        Args:
            llm_cfg: LLM配置字典
            messages: 消息列表
            **kwargs: 其他参数

        Returns:
            LLM返回的文本内容
        """
        # 获取模型参数
        model = llm_cfg.get("model", "")
        if not model:
            raise ValueError("未配置模型名称")

        # 确保temperature是float类型
        temperature = float(llm_cfg.get("temperature", 0.7))
        # 确保max_tokens是int类型
        max_tokens = int(llm_cfg.get("max_tokens", 4096))

        return self.call_llm(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs
        )

    def get_models_list(self, provider_id: str) -> List[Dict[str, str]]:
        """
        获取指定提供商的模型列表

        Args:
            provider_id: 提供商ID

        Returns:
            模型列表
        """
        models_config = self.config.get("models", {}).get(provider_id, {})
        models = []
        for model_id, model_name in models_config.items():
            models.append({
                "id": model_id,
                "name": model_name
            })
        return models

    def test_connection(self, provider_id: Optional[str] = None) -> Dict[str, Any]:
        """
        测试LLM连接

        Args:
            provider_id: 提供商ID（可选，默认测试当前启用的提供商）

        Returns:
            测试结果
        """
        target_provider = provider_id if provider_id else self.enabled_provider

        if not target_provider:
            return {
                "success": False,
                "message": "未启用任何提供商"
            }

        try:
            # 获取提供商配置
            provider_config = self.get_provider_config(target_provider)
            if not provider_config:
                return {
                    "success": False,
                    "message": f"提供商 {target_provider} 不存在"
                }

            config = provider_config.get("config", {})
            api_key = config.get("api_key", "")
            if not api_key:
                return {
                    "success": False,
                    "message": "未配置API Key"
                }

            # 测试调用
            test_messages = [
                {"role": "user", "content": "Hello, this is a test message."}
            ]

            # 如果测试的是不同的提供商，需要临时切换
            original_provider = self.enabled_provider
            if provider_id and provider_id != self.enabled_provider:
                self.enabled_provider = provider_id

            try:
                response = self.call_llm(
                    messages=test_messages,
                    max_tokens=100
                )
                return {
                    "success": True,
                    "message": "连接测试成功",
                    "response": response[:100] + "..." if len(response) > 100 else response
                }
            finally:
                # 恢复原始提供商
                if provider_id and provider_id != original_provider:
                    self.enabled_provider = original_provider

        except Exception as e:
            return {
                "success": False,
                "message": f"连接测试失败: {str(e)}"
            }


# 全局实例
_llm_provider_instance: Optional[LLMProvider] = None


def get_llm_provider(config_path: Optional[str] = None) -> LLMProvider:
    """
    获取LLM提供商实例（单例模式）

    Args:
        config_path: 配置文件路径（可选）

    Returns:
        LLMProvider实例
    """
    global _llm_provider_instance
    if _llm_provider_instance is None:
        _llm_provider_instance = LLMProvider(config_path=config_path)
    return _llm_provider_instance
