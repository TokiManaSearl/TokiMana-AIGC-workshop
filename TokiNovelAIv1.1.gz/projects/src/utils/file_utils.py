"""文件名工具函数 - 用于处理S3对象存储的文件名规范"""
import re
import uuid
import hashlib
from typing import Tuple


def sanitize_filename(filename: str, prefix: str = "") -> Tuple[str, str]:
    """
    清理文件名以符合S3对象命名规范
    
    S3命名规范：
    1. 长度 1-1024 字节
    2. 仅允许字母、数字、点(.)、下划线(_)、短横(-)、目录分隔符(/)
    3. 不允许空格或以下特殊字符：? # & %% { } ^ [ ] ` \\ < > ~ | " ' + = : ;
    4. 不以 / 开头或结尾，且不包含连续的 //
    
    Args:
        filename: 原始文件名（可能包含中文、空格等）
        prefix: 文件前缀（如 "templates/"、"novels/"）
    
    Returns:
        Tuple[清理后的文件名, 原始文件名的MD5哈希]
    """
    # 提取文件扩展名
    if "." in filename:
        name_part, ext_part = filename.rsplit(".", 1)
        # 清理扩展名
        ext_part = re.sub(r'[^a-zA-Z0-9]', '', ext_part).lower()
        if ext_part:
            ext = f".{ext_part}"
        else:
            ext = ""
    else:
        name_part = filename
        ext = ""
    
    # 计算原始文件名的MD5哈希（用于后续识别）
    original_hash = hashlib.md5(filename.encode('utf-8')).hexdigest()[:8]
    
    # 方案1: 尝试转换为拼音或简化中文
    # 移除非法字符
    sanitized = re.sub(r'[^a-zA-Z0-9._/-]', '', name_part)
    
    # 如果清理后为空或太短，使用哈希值
    if not sanitized or len(sanitized) < 3:
        # 使用时间戳 + 随机ID + 原始哈希
        import time
        timestamp = int(time.time())
        random_id = str(uuid.uuid4())[:8]
        sanitized = f"file_{timestamp}_{original_hash}_{random_id}"
    
    # 确保不超过1024字节
    max_length = 1024
    if len(sanitized.encode('utf-8')) > max_length:
        # 截断但保留后缀
        available = max_length - len(ext.encode('utf-8'))
        while len(sanitized[:available].encode('utf-8')) > available:
            available -= 1
        sanitized = sanitized[:available]
    
    # 移除连续的点和短横
    sanitized = re.sub(r'\.{2,}', '.', sanitized)
    sanitized = re.sub(r'-{2,}', '-', sanitized)
    
    # 移除开头和结尾的点、短横、斜杠
    sanitized = sanitized.strip('./-')
    
    # 拼接完整的文件名
    clean_filename = f"{sanitized}{ext}"
    
    # 添加前缀（如果有）
    if prefix:
        # 确保前缀不以/结尾，且不以/开头
        prefix = prefix.strip('/')
        clean_filename = f"{prefix}/{clean_filename}"
    
    return clean_filename, original_hash


def get_safe_filename(original_filename: str, category: str = "files", use_timestamp: bool = False) -> Tuple[str, str]:
    """
    获取安全的文件名（推荐使用的简化版本）

    Args:
        original_filename: 原始文件名
        category: 文件类别（templates/novels/files/outlines等）
        use_timestamp: 是否使用时间戳（默认False，相同文件名生成相同key以支持覆盖）

    Returns:
        Tuple[安全文件名, 文件ID]
    """
    import time

    # 提取扩展名
    if "." in original_filename:
        _, ext = original_filename.rsplit(".", 1)
        ext = re.sub(r'[^a-zA-Z0-9]', '', ext).lower()
        if ext:
            ext = f".{ext}"
    else:
        ext = ""

    # 生成唯一ID
    if use_timestamp:
        # 使用时间戳（每次上传生成不同的key）
        timestamp = int(time.time())
        file_id = hashlib.md5(
            f"{original_filename}{timestamp}".encode('utf-8')
        ).hexdigest()[:12]
        # 构建安全文件名：类别_时间戳_随机ID.扩展名
        safe_filename = f"{category}_{timestamp}_{file_id}{ext}"
    else:
        # 不使用时间戳（相同文件名生成相同key，支持覆盖）
        file_id = hashlib.md5(
            original_filename.encode('utf-8')
        ).hexdigest()[:12]
        # 构建安全文件名：类别_文件名哈希.扩展名
        safe_filename = f"{category}_{file_id}{ext}"

    return safe_filename, file_id
