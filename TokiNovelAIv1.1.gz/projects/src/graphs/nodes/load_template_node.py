"""
加载提示词模板节点（工作流2）
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import LoadTemplateInput, LoadTemplateOutput


def load_template_node(
    state: LoadTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> LoadTemplateOutput:
    """
    title: 加载提示词
    desc: 加载提示词模板内容
    """
    ctx = runtime.context

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return LoadTemplateOutput(
            template_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 列出所有模板
    result = storage.list_files(prefix="templates/")
    keys = result.get("keys", [])

    if not keys:
        # 使用默认模板
        template_content = "# 默认提示词模板\n## 1. 剧情伦理审查规则\n- 禁止血腥暴力、恐怖、情色、自残\n\n## 2. 角色命名规则\n- 主角类：[主角+姓名]\n- 反派类：[主要反派+姓名]\n\n## 3. 输出格式\n- 脚本需包含简介、剧本正文、结尾配音台本"
        return LoadTemplateOutput(
            template_content=template_content,
            message="⚠️ 未找到模板，使用默认模板"
        )

    # 获取第一个模板（按上传时间）
    template_key = keys[-1]  # 假设最后一个是最新的

    # 读取文件内容
    try:
        file_bytes = storage.read_file(template_key)
        template_content = file_bytes.decode('utf-8')

        return LoadTemplateOutput(
            template_content=template_content,
            message=f"✅ 成功加载模板：{template_key}"
        )
    except Exception as e:
        print(f"加载模板失败: {e}")
        # 失败时使用默认模板
        template_content = "# 默认提示词模板\n## 1. 剧情伦理审查规则\n- 禁止血腥暴力、恐怖、情色、自残\n\n## 2. 角色命名规则\n- 主角类：[主角+姓名]\n- 反派类：[主要反派+姓名]\n\n## 3. 输出格式\n- 脚本需包含简介、剧本正文、结尾配音台本"
        return LoadTemplateOutput(
            template_content=template_content,
            message=f"❌ 加载模板失败: {str(e)}，使用默认模板"
        )
