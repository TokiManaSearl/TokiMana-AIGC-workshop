"""
列出提示词模板节点（图形化版）
"""
import os
from pathlib import Path
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import ListTemplatesInput, ListTemplatesOutput


def list_templates_node(state: ListTemplatesInput, config: RunnableConfig, runtime: Runtime[Context]) -> ListTemplatesOutput:
    """
    title: 列出提示词
    desc: 查看所有已上传的提示词模板
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return ListTemplatesOutput(
            templates=[],
            selected_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    # 列出所有模板文件
    try:
        result = storage.list_files(prefix="templates/")
        templates_list = []
        keys = result.get("keys", [])
        
        print(f"[DEBUG] 列出模板文件，找到 {len(keys)} 个文件")
        print(f"[DEBUG] keys: {keys}")
        
        for key in keys:
            try:
                file_data = storage.read_file(file_key=key)
                file_content = file_data.decode("utf-8")
                
                # 标准化文件键（处理Windows路径的反斜杠问题）
                normalized_key = key.replace("\\", "/")
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(normalized_key)
                original_name = metadata.get("original_name", "")
                
                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else Path(key).name
                
                # 生成访问URL
                url = storage.generate_presigned_url(key=key, expire_time=3600)
                
                templates_list.append({
                    "name": display_name,
                    "file_key": key,  # 添加文件key，用于删除操作
                    "url": url,
                    "content": file_content
                })
                
                print(f"[DEBUG] 成功读取文件: {display_name} (file_key: {key}, 原始文件名: {original_name})")
            except Exception as e:
                print(f"[ERROR] 读取文件 {key} 失败: {e}")
        
        # 返回输出
        if templates_list:
            message = f"✅ 当前共有 {len(templates_list)} 个模板"
        else:
            message = "📭 暂无模板，请先上传"
            print("[DEBUG] 没有找到任何模板文件")
        
        return ListTemplatesOutput(
            templates=templates_list,
            selected_content="",
            message=message
        )
        
    except Exception as e:
        print(f"[ERROR] 列出模板失败: {e}")
        return ListTemplatesOutput(
            templates=[],
            selected_content="",
            message=f"❌ 列出模板失败: {str(e)}"
        )
