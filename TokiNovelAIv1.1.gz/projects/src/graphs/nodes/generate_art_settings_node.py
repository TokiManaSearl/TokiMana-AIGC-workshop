"""Generate art settings node for workflow 3"""
import os
import json
import time
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from langchain_core.messages import SystemMessage, HumanMessage
from graphs.state import GenerateArtSettingsInput, GenerateArtSettingsOutput


def generate_art_settings_node(
    state: GenerateArtSettingsInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateArtSettingsOutput:
    """
    title: Generate Art Settings
    desc: 根据大纲生成场景美术设定、角色美术设定、道具美术设定
    integrations: 大语言模型, 对象存储
    """
    ctx = runtime.context

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return GenerateArtSettingsOutput(
            character_settings=[],
            scene_settings=[],
            prop_settings=[],
            character_settings_content="",
            scene_settings_content="",
            prop_settings_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # Get outline from input parameter first, then from storage
    outline_content = state.outline_content or ""
    if not outline_content:
        try:
            # Read outline from storage
            result = storage.list_files(prefix="outlines/")
            if result.get("keys"):
                outline_key = result["keys"][-1]  # Get latest outline
                if outline_key:
                    content = storage.read_file(file_key=outline_key)
                    outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
        except Exception as e:
            return GenerateArtSettingsOutput(
                character_settings=[],
                scene_settings=[],
                prop_settings=[],
                character_settings_content="",
                scene_settings_content="",
                prop_settings_content="",
                message=f"❌ 读取大纲失败: {str(e)}"
            )

    if not outline_content:
        return GenerateArtSettingsOutput(
            character_settings=[],
            scene_settings=[],
            prop_settings=[],
            character_settings_content="",
            scene_settings_content="",
            prop_settings_content="",
            message="❌ 未找到大纲，请先生成大纲"
        )

    # 读取LLM配置
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_art_settings_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)

        llm_config = _cfg.get("config", {})
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        # 使用默认配置
        llm_config = {
            "model": "doubao-seed-1-8-251228",
            "temperature": 0.8,
            "top_p": 0.9,
            "max_completion_tokens": 8192,
            "thinking": "disabled"
        }
        sp = """你是一位专业的动画美术设定专家。请根据提供的大纲，生成完整的场景美术设定、角色美术设定、道具美术设定。

请按照以下格式输出：

## 角色美术设定
[角色名称1]：[masterpiece, best quality, ultra-detailed, 角色外观描述（年龄、性别、体型、特征、服装、配饰等），性格特点，姿态和表情，艺术风格，光影效果]
[角色名称2]：[masterpiece, best quality, ultra-detailed, 角色外观描述，性格特点，姿态和表情，艺术风格，光影效果]

## 场景美术设定
[场景名称1]：[masterpiece, best quality, ultra-detailed, 场景环境描述（时间、地点、氛围、地形、建筑、植被等），光线和阴影，镜头角度，艺术风格]
[场景名称2]：[masterpiece, best quality, ultra-detailed, 场景环境描述，光线和阴影，镜头角度，艺术风格]

## 道具美术设定
[道具名称1]：[masterpiece, best quality, ultra-detailed, 道具外观描述（材质、颜色、形状、功能、特殊效果等），使用状态，光影效果]
[道具名称2]：[masterpiece, best quality, ultra-detailed, 道具外观描述，使用状态，光影效果]

要求：
1. 每个美术设定必须包含足够的视觉细节，确保AI文生图工具能够生成高质量的图像
2. 提示词必须包含：masterpiece, best quality, ultra-detailed 等质量关键词
3. 遵循香蕉pro文生图提示词格式
4. 生成不少于5个角色设定、5个场景设定、5个道具设定"""
        up = """请根据以下大纲，生成完整的美术设定：

大纲内容：
{{ outline_content }}

请生成角色美术设定、场景美术设定、道具美术设定。"""

    # 创建LLM客户端（使用新的LLM提供商系统，自动从前端配置获取模型）
    from utils.llm.llm_client import create_llm_client
    client = create_llm_client(ctx=runtime.context)

    # 生成美术设定
    try:
        # 渲染用户提示词
        up_tpl = Template(up)
        user_prompt = up_tpl.render(outline_content=outline_content)

        messages = [
            SystemMessage(content=sp),
            HumanMessage(content=user_prompt)
        ]

        # 调用LLM
        response = client.invoke(
            messages=messages,
            temperature=llm_config.get("temperature", 0.8),
            top_p=llm_config.get("top_p", 0.9),
            max_completion_tokens=llm_config.get("max_completion_tokens", 8192),
            thinking=llm_config.get("thinking", "disabled")
        )

        # 提取响应内容
        art_settings_content = response.content
        if isinstance(art_settings_content, list):
            art_settings_content = " ".join(str(item) for item in art_settings_content)

        # 解析美术设定内容
        character_settings = []
        scene_settings = []
        prop_settings = []
        character_settings_content = ""
        scene_settings_content = ""
        prop_settings_content = ""

        # 提取角色美术设定
        if "## 角色美术设定" in art_settings_content:
            character_section = art_settings_content.split("## 角色美术设定")[1]
            if "## 场景美术设定" in character_section:
                character_section = character_section.split("## 场景美术设定")[0]
            elif "## 道具美术设定" in character_section:
                character_section = character_section.split("## 道具美术设定")[0]
            character_settings_content = character_section.strip()

            # 解析每个角色设定
            import re
            character_pattern = r'\[([^\]]+)\]：\s*\[([^\]]+)\]'
            character_matches = re.findall(character_pattern, character_settings_content)
            for match in character_matches:
                character_name = match[0].strip()
                character_prompt = match[1].strip()
                character_settings.append({
                    "name": character_name,
                    "prompt": character_prompt
                })

        # 提取场景美术设定
        if "## 场景美术设定" in art_settings_content:
            scene_section = art_settings_content.split("## 场景美术设定")[1]
            if "## 道具美术设定" in scene_section:
                scene_section = scene_section.split("## 道具美术设定")[0]
            scene_settings_content = scene_section.strip()

            # 解析每个场景设定
            scene_pattern = r'\[([^\]]+)\]：\s*\[([^\]]+)\]'
            scene_matches = re.findall(scene_pattern, scene_settings_content)
            for match in scene_matches:
                scene_name = match[0].strip()
                scene_prompt = match[1].strip()
                scene_settings.append({
                    "name": scene_name,
                    "prompt": scene_prompt
                })

        # 提取道具美术设定
        if "## 道具美术设定" in art_settings_content:
            prop_section = art_settings_content.split("## 道具美术设定")[1]
            prop_settings_content = prop_section.strip()

            # 解析每个道具设定
            prop_pattern = r'\[([^\]]+)\]：\s*\[([^\]]+)\]'
            prop_matches = re.findall(prop_pattern, prop_settings_content)
            for match in prop_matches:
                prop_name = match[0].strip()
                prop_prompt = match[1].strip()
                prop_settings.append({
                    "name": prop_name,
                    "prompt": prop_prompt
                })

        # 保存美术设定内容到文件
        timestamp = int(time.time())
        art_files = []

        # 保存角色美术设定
        if character_settings_content:
            character_filename = f"角色美术设定_{timestamp}.md"
            character_key = f"art_settings/character_{timestamp}.md"
            storage.upload_file(
                file_content=character_settings_content.encode('utf-8'),
                file_name=character_key,
                content_type="text/markdown",
                original_name=character_filename
            )
            art_files.append({
                "type": "character",
                "name": character_filename,
                "key": character_key
            })

        # 保存场景美术设定
        if scene_settings_content:
            scene_filename = f"场景美术设定_{timestamp}.md"
            scene_key = f"art_settings/scene_{timestamp}.md"
            storage.upload_file(
                file_content=scene_settings_content.encode('utf-8'),
                file_name=scene_key,
                content_type="text/markdown",
                original_name=scene_filename
            )
            art_files.append({
                "type": "scene",
                "name": scene_filename,
                "key": scene_key
            })

        # 保存道具美术设定
        if prop_settings_content:
            prop_filename = f"道具美术设定_{timestamp}.md"
            prop_key = f"art_settings/prop_{timestamp}.md"
            storage.upload_file(
                file_content=prop_settings_content.encode('utf-8'),
                file_name=prop_key,
                content_type="text/markdown",
                original_name=prop_filename
            )
            art_files.append({
                "type": "prop",
                "name": prop_filename,
                "key": prop_key
            })

        message = f"✅ 成功生成美术设定\n"
        message += f"👥 角色：{len(character_settings)}个\n"
        message += f"🏰 场景：{len(scene_settings)}个\n"
        message += f"🔧 道具：{len(prop_settings)}个"

        return GenerateArtSettingsOutput(
            character_settings=character_settings,
            scene_settings=scene_settings,
            prop_settings=prop_settings,
            character_settings_content=character_settings_content,
            scene_settings_content=scene_settings_content,
            prop_settings_content=prop_settings_content,
            message=message
        )

    except Exception as e:
        import traceback
        error_msg = f"❌ 生成美术设定失败: {str(e)}\n{traceback.format_exc()}"
        print(error_msg)
        return GenerateArtSettingsOutput(
            character_settings=[],
            scene_settings=[],
            prop_settings=[],
            character_settings_content="",
            scene_settings_content="",
            prop_settings_content="",
            message=error_msg
        )
