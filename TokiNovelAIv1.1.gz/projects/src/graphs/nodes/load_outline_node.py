"""Load outline node for workflow 3"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file.file import FileOps
from graphs.state import LoadOutlineInput, LoadOutlineOutput


def load_outline_node(
    state: LoadOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> LoadOutlineOutput:
    """
    title: 加载大纲
    desc: 加载大纲文件内容
    integrations: 对象存储
    """
    ctx = runtime.context

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return LoadOutlineOutput(
            outline_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    try:
        # 从文件URL读取内容
        outline_content = FileOps.extract_text(state.outline_file)

        if not outline_content:
            return LoadOutlineOutput(
                outline_content="",
                message="❌ 大纲文件内容为空"
            )

        return LoadOutlineOutput(
            outline_content=outline_content,
            message=f"✅ 成功加载大纲文件"
        )
    except Exception as e:
        print(f"加载大纲文件失败: {e}")
        return LoadOutlineOutput(
            outline_content="",
            message=f"❌ 加载大纲文件失败: {str(e)}"
        )
