"""
分析大纲节点（工作流3）
"""
import os
import json
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.llm.llm_provider import get_llm_provider
from graphs.state import AnalyzeOutlineInput, AnalyzeOutlineOutput

def analyze_outline_node(
    state: AnalyzeOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> AnalyzeOutlineOutput:
    """
    title: 分析短剧剧集大纲
    desc: 使用LLM分析大纲，提取关键信息用于后续脚本生成
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 从config读取LLM配置
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), config['metadata']['llm_cfg'])
    with open(cfg_file, 'r', encoding='utf-8') as fd:
        _cfg = json.load(fd)

    llm_config = _cfg.get("config", {})
    sp = _cfg.get("sp", "")
    up = _cfg.get("up", "")

    # 渲染用户提示词
    up_tpl = Template(up)
    user_prompt = up_tpl.render(
        outline_content=state.outline_content,
        template_content=state.template_content
    )

    # 获取LLM Provider
    llm_provider = get_llm_provider()

    # 组装消息
    messages = [
        {"role": "system", "content": sp},
        {"role": "user", "content": user_prompt}
    ]

    # 调用LLM
    analysis_result = llm_provider.call_llm_with_config(
        llm_cfg=llm_config,
        messages=messages
    )

    return AnalyzeOutlineOutput(
        analysis_result=analysis_result
    )
