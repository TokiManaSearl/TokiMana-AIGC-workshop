"""Delete template node for workflow 1"""
import os
from pathlib import Path
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import DeleteTemplateInput, DeleteTemplateOutput


def delete_template_node(
    state: DeleteTemplateInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> DeleteTemplateOutput:
    """
    title: Delete Template
    desc: Delete a template by name
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return DeleteTemplateOutput(
            templates=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    templates = []
    try:
        # 处理 template_name：可能包含路径，需要提取文件名
        # 示例输入："templates\\template_74284399f232" 或 "template_74284399f232"
        template_name = state.template_name
        
        # 如果包含路径分隔符，提取文件名
        if "\\" in template_name or "/" in template_name:
            template_name = Path(template_name).name
        
        # 根据原始文件名查找对应的文件key
        # 因为列表显示的是原始文件名，但存储使用的是安全文件名
        target_file_key = None
        result = storage.list_files(prefix="templates/")
        
        print(f"[DEBUG] ===== 删除模板调试信息 =====")
        print(f"[DEBUG] 要删除的模板名: {template_name}")
        print(f"[DEBUG] 找到的文件数: {len(result.get('keys', []))}")
        print(f"[DEBUG] 文件keys: {result.get('keys', [])}")
        
        for file_key in result.get("keys", []):
            try:
                # 标准化文件键（处理Windows路径的反斜杠问题）
                normalized_key = file_key.replace("\\", "/")
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(normalized_key)
                original_name = metadata.get("original_name", "")
                
                # 获取文件的显示名称
                display_name = original_name if original_name else Path(file_key).name
                
                print(f"[DEBUG] 检查文件: {file_key}")
                print(f"[DEBUG]  标准化key: {normalized_key}")
                print(f"[DEBUG]  原始文件名: {original_name}")
                print(f"[DEBUG]  显示名称: {display_name}")
                print(f"[DEBUG]  匹配检查: original_name==template_name={original_name==template_name}, display_name==template_name={display_name==template_name}")
                
                # 如果原始文件名或显示名称匹配，则找到目标文件
                if original_name == template_name or display_name == template_name or Path(file_key).name == template_name:
                    target_file_key = file_key
                    print(f"[DEBUG] ✅ 找到目标文件: {target_file_key}")
                    break
            except Exception as e:
                print(f"[ERROR] 读取文件元数据失败: {e}")
        
        if not target_file_key:
            print(f"[DEBUG] ❌ 未找到匹配的文件")
            return DeleteTemplateOutput(
                templates=[],
                message=f"❌ 未找到模板: {template_name}"
            )
        
        print(f"[DEBUG] ===== 开始删除文件 =====")
        print(f"[DEBUG] 目标文件key: {target_file_key}")
        
        # 直接尝试删除文件，不依赖file_exists检查
        # 因为file_exists和实际文件状态可能不一致（缓存、并发等原因）
        try:
            success = storage.delete_file(file_key=target_file_key)
            print(f"[DEBUG] 删除结果: success={success}")
        except Exception as e:
            print(f"[ERROR] 删除操作抛出异常: {e}")
            import traceback
            print(f"[ERROR] Traceback: {traceback.format_exc()}")
            return DeleteTemplateOutput(
                templates=[],
                message=f"❌ 删除文件时发生异常: {str(e)}"
            )
        
        if not success:
            print(f"[DEBUG] ❌ 删除失败（可能文件已被删除或权限不足）")
            # 删除失败时，仍然列出剩余文件，让用户看到当前状态
            result = storage.list_files(prefix="templates/")
            templates = []
            for file_key in result.get("keys", []):
                try:
                    normalized_key = file_key.replace("\\", "/")
                    metadata = storage.get_file_metadata(normalized_key)
                    original_name = metadata.get("original_name", "")
                    display_name = original_name if original_name else Path(file_key).name
                    url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                    templates.append({"name": display_name, "url": url})
                except Exception as e:
                    print(f"[ERROR] 处理剩余模板失败: {e}")
            
            return DeleteTemplateOutput(
                templates=templates,
                message=f"❌ 删除文件失败: {target_file_key}（可能文件已被删除或权限不足，请查看当前列表）"
            )
        
        print(f"[DEBUG] ✅ 删除成功")
        print(f"[DEBUG] ===== 删除完成 =====")
        
        # List remaining templates
        result = storage.list_files(prefix="templates/")
        templates = []
        for file_key in result.get("keys", []):
            try:
                # 标准化文件键（处理Windows路径的反斜杠问题）
                normalized_key = file_key.replace("\\", "/")
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(normalized_key)
                original_name = metadata.get("original_name", "")
                
                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else Path(file_key).name
                
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                templates.append({"name": display_name, "url": url})
                
                print(f"[DEBUG] 剩余模板: {display_name}")
            except Exception as e:
                print(f"[ERROR] 处理剩余模板失败: {e}")
        
        print(f"[DEBUG] ===== 删除操作完成，剩余模板数: {len(templates)} =====")
        
        return DeleteTemplateOutput(
            templates=templates,
            message=f"✅ 模板 '{template_name}' 已删除"
        )
        
    except Exception as e:
        print(f"[ERROR] 删除模板异常: {e}")
        import traceback
        print(f"[ERROR] Traceback: {traceback.format_exc()}")
        return DeleteTemplateOutput(
            templates=[],
            message=f"❌ 删除模板失败: {str(e)}"
        )
