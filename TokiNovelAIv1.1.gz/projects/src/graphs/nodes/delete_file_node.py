"""Delete file node for workflow 3"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import DeleteFileInput, DeleteFileOutput


def delete_file_node(
    state: DeleteFileInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> DeleteFileOutput:
    """
    title: Delete File
    desc: Delete a file by name
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return DeleteFileOutput(
            files=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    files = []
    try:
        # 读取本地存储的元数据
        from utils.local_storage import get_local_storage
        local_storage = get_local_storage()
        local_metadata = local_storage._load_metadata()
        
        # 根据原始文件名查找对应的文件key
        target_file_key = None
        result = storage.list_files(prefix="")
        
        for file_key in result.get("keys", []):
            try:
                # 提取文件的基本名称（移除可能的bucket前缀和路径）
                filename = file_key.split("/")[-1]
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                
                # 如果没有找到，尝试在本地元数据中查找
                if not metadata or not metadata.get("original_name"):
                    # 遍历本地元数据，查找匹配的文件
                    for local_key, local_meta in local_metadata.items():
                        local_filename = local_key.split("/")[-1]
                        # 匹配文件名（移除时间戳和哈希部分）
                        s3_parts = filename.rsplit("_", 1)
                        local_parts = local_filename.rsplit(".", 1)
                        
                        if len(s3_parts) > 0:
                            base_name = s3_parts[0]
                            local_base = local_parts[0]
                            
                            if base_name == local_base:
                                metadata = local_meta
                                break
                
                original_name = metadata.get("original_name", "") if metadata else ""
                
                # 如果原始文件名匹配，则找到目标文件
                if original_name == state.file_name:
                    target_file_key = file_key
                    break
            except Exception as e:
                print(f"读取文件元数据失败: {e}")
        
        # Delete file from storage
        if target_file_key:
            storage.delete_file(file_key=target_file_key)
        else:
            return DeleteFileOutput(
                files=[],
                message=f"❌ 未找到文件: {state.file_name}"
            )
        
        # List remaining files
        result = storage.list_files(prefix="")
        files = []
        for file_key in result.get("keys", []):
            try:
                # 提取文件的基本名称（移除可能的bucket前缀和路径）
                filename = file_key.split("/")[-1]
                
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                
                # 如果没有找到，尝试在本地元数据中查找
                if not metadata or not metadata.get("original_name"):
                    # 遍历本地元数据，查找匹配的文件
                    for local_key, local_meta in local_metadata.items():
                        local_filename = local_key.split("/")[-1]
                        # 匹配文件名（移除时间戳和哈希部分）
                        s3_parts = filename.rsplit("_", 1)
                        local_parts = local_filename.rsplit(".", 1)
                        
                        if len(s3_parts) > 0:
                            base_name = s3_parts[0]
                            local_base = local_parts[0]
                            
                            if base_name == local_base:
                                metadata = local_meta
                                break
                
                original_name = metadata.get("original_name", "") if metadata else ""
                
                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else filename
                
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                files.append({"name": display_name, "url": url})
            except Exception as e:
                print(f"处理文件信息失败: {e}")
    except Exception as e:
        return DeleteFileOutput(
            files=[],
            message=f"❌ 删除文件失败: {str(e)}"
        )
    
    return DeleteFileOutput(
        files=files,
        message=f"✅ 文件 '{state.file_name}' 已删除"
    )
