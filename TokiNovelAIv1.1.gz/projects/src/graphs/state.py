"""
全局状态定义：支持三个独立工作流的状态模型
"""
from typing import List, Optional, Literal, Dict, Any
from pydantic import BaseModel, Field
from utils.file.file import File

# ============================================================================
# 工作流1：提示词模板管理
# ============================================================================

class Workflow1GlobalState(BaseModel):
    """工作流1全局状态"""
    uploaded_templates: List[Dict[str, Any]] = Field(default=[], description="已上传的提示词模板列表（包含文件名、URL、内容等）")
    selected_template_name: str = Field(default="", description="用户选择的提示词模板名称")
    selected_template_content: str = Field(default="", description="当前选中的提示词模板内容")
    edited_template_content: str = Field(default="", description="用户编辑后的提示词模板内容")
    saved_template_url: str = Field(default="", description="保存后的提示词模板URL")

class Workflow1Input(BaseModel):
    """工作流1输入"""
    template_file: Optional[File] = Field(default=None, description="上传的提示词模板.md文件")
    action: Literal["upload", "list", "delete", "select", "edit", "save"] = Field(
        ..., description="操作类型：upload-上传，list-列出，delete-删除，select-选择，edit-编辑，save-保存"
    )
    template_name: str = Field(default="", description="模板名称（用于选择、删除、保存操作）")
    new_content: str = Field(default="", description="编辑后的新内容（用于保存操作）")

class Workflow1Output(BaseModel):
    """工作流1输出"""
    action: str = Field(..., description="执行的操作类型")
    templates: List[Dict[str, Any]] = Field(default=[], description="模板列表（用于list操作）")
    selected_content: str = Field(default="", description="选中的模板内容（用于select操作）")
    saved_url: str = Field(default="", description="保存后的URL（用于save操作）")
    message: str = Field(default="", description="操作结果消息")

# 工作流1节点输入输出定义

class UploadTemplateInput(BaseModel):
    """上传提示词模板节点输入"""
    template_file: File = Field(..., description="上传的提示词模板.md文件")
    template_name: str = Field(default="", description="原始文件名（如果URL中的文件名不是真实的文件名，可以手动指定）")

class UploadTemplateOutput(BaseModel):
    """上传提示词模板节点输出"""
    templates: List[Dict[str, Any]] = Field(default=[], description="更新后的模板列表")
    message: str = Field(..., description="上传结果消息")

class ListTemplatesInput(BaseModel):
    """列出提示词模板节点输入"""
    pass

class ListTemplatesOutput(BaseModel):
    """列出提示词模板节点输出"""
    templates: List[Dict[str, Any]] = Field(default=[], description="模板列表")
    message: str = Field(..., description="操作结果消息")

class DeleteTemplateInput(BaseModel):
    """删除提示词模板节点输入"""
    template_name: str = Field(..., description="要删除的模板名称")

class DeleteTemplateOutput(BaseModel):
    """删除提示词模板节点输出"""
    templates: List[Dict[str, Any]] = Field(default=[], description="更新后的模板列表")
    message: str = Field(..., description="删除结果消息")

class SelectTemplateInput(BaseModel):
    """选择提示词模板节点输入"""
    template_name: str = Field(..., description="要选择的模板名称")

class SelectTemplateOutput(BaseModel):
    """选择提示词模板节点输出"""
    template_name: str = Field(..., description="选中的模板名称")
    template_content: str = Field(..., description="模板内容")
    message: str = Field(..., description="操作结果消息")

class EditTemplateInput(BaseModel):
    """编辑提示词模板节点输入"""
    template_name: str = Field(..., description="正在编辑的模板名称")
    new_content: str = Field(..., description="编辑后的内容")

class EditTemplateOutput(BaseModel):
    """编辑提示词模板节点输出"""
    template_name: str = Field(..., description="模板名称")
    edited_content: str = Field(..., description="编辑后的内容")
    message: str = Field(..., description="操作结果消息")

class SaveTemplateInput(BaseModel):
    """保存提示词模板节点输入"""
    template_name: str = Field(..., description="模板名称")
    edited_content: str = Field(..., description="编辑后的内容")

class SaveTemplateOutput(BaseModel):
    """保存提示词模板节点输出"""
    saved_url: str = Field(..., description="保存后的URL")
    message: str = Field(..., description="保存结果消息")


# ============================================================================
# 工作流2：小说改编大纲
# ============================================================================

class Workflow2GlobalState(BaseModel):
    """工作流2全局状态"""
    novel_file: Optional[File] = Field(default=None, description="上传的小说.txt文件")
    uploaded_novels: List[Dict[str, Any]] = Field(default=[], description="已上传的小说文件列表")
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="选择的LLM模型")
    template_content: str = Field(default="", description="从工作流1获取的提示词模板内容")
    outline_content: str = Field(default="", description="生成的短剧剧集大纲内容")
    outline_file_url: str = Field(default="", description="大纲文件的URL")
    novel_content: str = Field(default="", description="加载的小说内容（用于load_novel操作）")

class Workflow2Input(BaseModel):
    """工作流2输入"""
    novel_file: Optional[File] = Field(default=None, description="上传的小说.txt文件")
    action: Literal["upload", "list", "delete", "generate_outline"] = Field(
        ..., description="操作类型：upload-上传，list-列出，delete-删除，generate_outline-生成大纲"
    )

class Workflow2Output(BaseModel):
    """工作流2输出"""
    action: str = Field(..., description="执行的操作类型")
    novels: List[Dict[str, Any]] = Field(default=[], description="小说列表（用于list操作）")
    outline_content: str = Field(default="", description="生成的大纲内容（用于generate_outline操作）")
    outline_url: str = Field(default="", description="大纲文件URL（用于generate_outline操作）")
    message: str = Field(default="", description="操作结果消息")

# 工作流2节点输入输出定义

class UploadNovelInput(BaseModel):
    """上传小说节点输入"""
    novel_file: File = Field(..., description="上传的小说.txt文件")
    novel_name: str = Field(default="", description="原始文件名（如果URL中的文件名不是真实的文件名，可以手动指定）")

class UploadNovelOutput(BaseModel):
    """上传小说节点输出"""
    novels: List[Dict[str, Any]] = Field(default=[], description="更新后的小说列表")
    message: str = Field(..., description="上传结果消息")

class ListNovelsInput(BaseModel):
    """列出小说节点输入"""
    pass

class ListNovelsOutput(BaseModel):
    """列出小说节点输出"""
    novels: List[Dict[str, Any]] = Field(default=[], description="小说列表")
    message: str = Field(..., description="操作结果消息")

class DeleteNovelInput(BaseModel):
    """删除小说节点输入"""
    novel_name: str = Field(..., description="要删除的小说名称")

class DeleteNovelOutput(BaseModel):
    """删除小说节点输出"""
    novels: List[Dict[str, Any]] = Field(default=[], description="更新后的小说列表")
    message: str = Field(..., description="删除结果消息")

class LoadNovelInput(BaseModel):
    """加载小说节点输入"""
    novel_name: str = Field(..., description="要加载的小说名称")

class LoadNovelOutput(BaseModel):
    """加载小说节点输出"""
    novel_name: str = Field(..., description="加载的小说名称")
    novel_content: str = Field(..., description="小说内容")
    message: str = Field(..., description="操作结果消息")

class LoadTemplateInput(BaseModel):
    """加载提示词模板节点输入"""
    pass

class LoadTemplateOutput(BaseModel):
    """加载提示词模板节点输出"""
    template_content: str = Field(..., description="提示词模板内容")
    message: str = Field(..., description="操作结果消息")

class GenerateOutlineInput(BaseModel):
    """生成大纲节点输入"""
    novel_content: str = Field(default="", description="小说内容（可选，如果为空则从存储中读取）")
    template_content: str = Field(default="", description="提示词模板内容（可选，如果为空则从存储中读取）")

class GenerateOutlineOutput(BaseModel):
    """生成大纲节点输出"""
    outline_content: str = Field(..., description="生成的大纲内容")
    outline_url: str = Field(..., description="生成的大纲URL（可能为空）")
    message: str = Field(..., description="操作结果消息")

class SaveOutlineInput(BaseModel):
    """保存大纲节点输入"""
    outline_content: str = Field(..., description="大纲内容")

class SaveOutlineOutput(BaseModel):
    """保存大纲节点输出"""
    outline_url: str = Field(..., description="保存后的URL")
    message: str = Field(..., description="保存结果消息")


# ============================================================================
# 工作流3：生成改编文件包
# ============================================================================

class Workflow3GlobalState(BaseModel):
    """工作流3全局状态"""
    outline_file: Optional[File] = Field(default=None, description="上传的短剧剧集大纲.md文件")
    episode_excel: Optional[File] = Field(default=None, description="上传的剧集导入Excel模板")
    art_excel: Optional[File] = Field(default=None, description="上传的美术资产导入Excel模板")
    uploaded_files: List[Dict[str, Any]] = Field(default=[], description="已上传的文件列表")
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="选择的LLM模型")
    template_content: str = Field(default="", description="从工作流1获取的提示词模板内容")
    outline_content: str = Field(default="", description="短剧剧集大纲内容")
    generated_files: Dict[str, Any] = Field(default={}, description="生成的所有文件（脚本、台本、美术设定等）")
    filled_excel_files: Dict[str, str] = Field(default={}, description="填写好的Excel文件（URL）")
    final_package_url: str = Field(default="", description="最终压缩包URL")
    # generate_episodes 节点专用参数
    start_episode: int = Field(default=1, ge=1, description="起始集数（从1开始）")
    end_episode: int = Field(default=10, ge=1, description="结束集数（最多30集）")
    series_name: str = Field(default="动画短剧", description="短剧名称（用于文件命名）")

class Workflow3Input(BaseModel):
    """工作流3输入"""
    outline_file: Optional[File] = Field(default=None, description="上传的短剧剧集大纲.md文件")
    episode_excel: Optional[File] = Field(default=None, description="上传的剧集导入Excel模板")
    art_excel: Optional[File] = Field(default=None, description="上传的美术资产导入Excel模板")
    action: Literal["upload", "list", "delete", "generate_package"] = Field(
        ..., description="操作类型：upload-上传，list-列出，delete-删除，generate_package-生成文件包"
    )

class Workflow3Output(BaseModel):
    """工作流3输出"""
    action: str = Field(..., description="执行的操作类型")
    files: List[Dict[str, Any]] = Field(default=[], description="文件列表（用于list操作）")
    package_url: str = Field(default="", description="最终压缩包URL（用于generate_package操作）")
    message: str = Field(default="", description="操作结果消息")

# 工作流3节点输入输出定义

class UploadFilesInput(BaseModel):
    """上传文件节点输入"""
    files: List[File] = Field(default=[], description="上传的文件列表")

class UploadFilesOutput(BaseModel):
    """上传文件节点输出"""
    files: List[Dict[str, Any]] = Field(default=[], description="更新后的文件列表")
    message: str = Field(..., description="上传结果消息")

class ListFilesInput(BaseModel):
    """列出文件节点输入"""
    pass

class ListFilesOutput(BaseModel):
    """列出文件节点输出"""
    files: List[Dict[str, Any]] = Field(default=[], description="文件列表")
    message: str = Field(..., description="操作结果消息")

class DeleteFileInput(BaseModel):
    """删除文件节点输入"""
    file_name: str = Field(..., description="要删除的文件名称")

class DeleteFileOutput(BaseModel):
    """删除文件节点输出"""
    files: List[Dict[str, Any]] = Field(default=[], description="更新后的文件列表")
    message: str = Field(..., description="删除结果消息")

class ClearAllFilesInput(BaseModel):
    """清理所有文件节点输入"""
    delete_scripts: bool = Field(default=False, description="是否删除所有脚本文件")
    delete_outlines: bool = Field(default=False, description="是否删除所有大纲文件")
    delete_packages: bool = Field(default=False, description="是否删除所有压缩包")
    delete_all: bool = Field(default=False, description="是否删除所有文件（包括模板、小说等）")

class ClearAllFilesOutput(BaseModel):
    """清理所有文件节点输出"""
    files: List[Dict[str, Any]] = Field(default=[], description="剩余的文件列表")
    deleted_count: int = Field(default=0, description="删除的文件数量")
    message: str = Field(..., description="操作结果消息")

class LoadOutlineInput(BaseModel):
    """加载大纲节点输入"""
    outline_file: File = Field(..., description="短剧剧集大纲文件")

class LoadOutlineOutput(BaseModel):
    """加载大纲节点输出"""
    outline_content: str = Field(..., description="大纲内容")
    message: str = Field(..., description="操作结果消息")

class ListOutlinesInput(BaseModel):
    """列出大纲节点输入"""
    pass

class ListOutlinesOutput(BaseModel):
    """列出大纲节点输出"""
    outlines: List[Dict[str, Any]] = Field(default=[], description="大纲文件列表（包含文件名、URL等）")
    message: str = Field(..., description="操作结果消息")

class SelectOutlineInput(BaseModel):
    """选择大纲节点输入"""
    outline_name: str = Field(..., description="要选择的大纲名称")

class SelectOutlineOutput(BaseModel):
    """选择大纲节点输出"""
    outline_name: str = Field(..., description="选中的大纲名称")
    outline_content: str = Field(..., description="大纲内容")
    message: str = Field(..., description="操作结果消息")

class AnalyzeOutlineInput(BaseModel):
    """分析大纲节点输入"""
    outline_content: str = Field(..., description="大纲内容")
    template_content: str = Field(..., description="提示词模板内容")

class AnalyzeOutlineOutput(BaseModel):
    """分析大纲节点输出"""
    analysis_result: str = Field(..., description="分析结果")
    message: str = Field(..., description="操作结果消息")

class GenerateScriptsInput(BaseModel):
    """生成脚本节点输入"""
    start_episode: int = Field(default=1, ge=1, description="起始集数（从1开始）")
    end_episode: int = Field(default=3, ge=1, le=5, description="结束集数（最多5集）")
    series_name: str = Field(default="动画短剧", description="短剧名称（用于文件命名）")
    outline_content: str = Field(default="", description="大纲内容（如果为空则从存储中读取）")
    template_content: str = Field(default="", description="提示词模板内容（如果为空则从存储中读取）")

class GenerateScriptsOutput(BaseModel):
    """生成脚本节点输出"""
    script_files: List[File] = Field(default=[], description="生成的脚本文件列表")
    character_art_file: File = Field(default=File(url="", file_type="document"), description="角色美术设定文件")
    scene_art_file: File = Field(default=File(url="", file_type="document"), description="场景美术设定文件")
    scripts_content: Dict[str, str] = Field(default={}, description="脚本内容字典（key为episode_1/episode_2/episode_3，value为脚本文本）")
    character_art_content: str = Field(default="", description="角色美术设定文本内容")
    scene_art_content: str = Field(default="", description="场景美术设定文本内容")
    message: str = Field(..., description="操作结果消息")

class Generate60EpisodesInput(BaseModel):
    """生成60集脚本节点输入"""
    pass

class Generate60EpisodesOutput(BaseModel):
    """生成60集脚本节点输出"""
    package_url: str = Field(..., description="生成的压缩包URL")
    message: str = Field(..., description="操作结果消息")

class GenerateEpisodesInput(BaseModel):
    """生成指定范围集数脚本节点输入"""
    start_episode: int = Field(default=1, ge=1, description="起始集数（从1开始）")
    end_episode: int = Field(default=10, ge=1, description="结束集数（最多30集）")
    series_name: str = Field(default="动画短剧", description="短剧名称（用于文件命名）")

class GenerateEpisodesOutput(BaseModel):
    """生成指定范围集数脚本节点输出"""
    package_url: str = Field(..., description="生成的压缩包URL")
    message: str = Field(..., description="操作结果消息")

class GenerateArtSettingsInput(BaseModel):
    """生成美术设定节点输入"""
    outline_content: str = Field(default="", description="大纲内容（可选，如果为空则从存储中读取）")
    template_content: str = Field(default="", description="提示词模板内容（可选，如果为空则从存储中读取）")

class GenerateArtSettingsOutput(BaseModel):
    """生成美术设定节点输出"""
    character_settings: List[Dict[str, Any]] = Field(default=[], description="角色美术设定清单")
    scene_settings: List[Dict[str, Any]] = Field(default=[], description="场景美术设定清单")
    prop_settings: List[Dict[str, Any]] = Field(default=[], description="道具美术设定清单")
    character_settings_content: str = Field(default="", description="角色美术设定文本内容")
    scene_settings_content: str = Field(default="", description="场景美术设定文本内容")
    prop_settings_content: str = Field(default="", description="道具美术设定文本内容")
    message: str = Field(..., description="操作结果消息")

class FillEpisodeExcelInput(BaseModel):
    """填写剧集Excel节点输入"""
    script_files: List[File] = Field(default=[], description="生成的脚本文件列表")

class FillEpisodeExcelOutput(BaseModel):
    """填写剧集Excel节点输出"""
    excel_file: File = Field(..., description="填写后的剧集Excel文件")
    message: str = Field(..., description="操作结果消息")

class FillArtExcelInput(BaseModel):
    """填写美术Excel节点输入"""
    character_settings: List[Dict[str, Any]] = Field(default=[], description="角色美术设定")
    scene_settings: List[Dict[str, Any]] = Field(default=[], description="场景美术设定")
    prop_settings: List[Dict[str, Any]] = Field(default=[], description="道具美术设定")

class FillArtExcelOutput(BaseModel):
    """填写美术Excel节点输出"""
    excel_file: File = Field(..., description="填写后的美术Excel文件")
    message: str = Field(..., description="操作结果消息")

class CreatePackageInput(BaseModel):
    """创建压缩包节点输入"""
    excel_files: List[File] = Field(default=[], description="所有生成的Excel文件（剧集Excel、美术Excel）")

class CreatePackageOutput(BaseModel):
    """创建压缩包节点输出"""
    package_file: File = Field(..., description="最终压缩包文件")
    message: str = Field(..., description="创建结果消息")

# ============================================================================
# 主图路由节点输入输出定义
# ============================================================================

class CallWorkflow1Input(BaseModel):
    """调用工作流1节点输入"""
    workflow_id: int = Field(default=1, description="工作流ID")
    node_name: str = Field(..., description="要执行的节点名称")
    template_file: Optional[File] = Field(default=None, description="上传的提示词模板.md文件（仅upload操作需要）")
    template_name: str = Field(default="", description="模板名称（用于select、delete、save操作）")
    new_content: str = Field(default="", description="编辑后的新内容（用于save操作）")

class CallWorkflow1Output(BaseModel):
    """调用工作流1节点输出"""
    workflow_id: int = Field(default=1, description="工作流ID")
    action: str = Field(..., description="执行的操作类型")
    templates: List[Dict[str, Any]] = Field(default=[], description="模板列表（用于list操作）")
    selected_content: str = Field(default="", description="选中的模板内容（用于select操作）")
    saved_url: str = Field(default="", description="保存后的URL（用于save操作）")
    message: str = Field(..., description="操作结果消息")

class CallWorkflow2Input(BaseModel):
    """调用工作流2节点输入"""
    workflow_id: int = Field(default=2, description="工作流ID")
    node_name: str = Field(..., description="要执行的节点名称")
    novel_file: Optional[File] = Field(default=None, description="上传的小说.md或.txt文件（仅upload操作需要）")
    novel_name: str = Field(default="", description="小说名称（用于delete操作）")
    llm_model: str = Field(default="", description="选择的大模型名称（仅generate_outline需要）")

class CallWorkflow2Output(BaseModel):
    """调用工作流2节点输出"""
    workflow_id: int = Field(default=2, description="工作流ID")
    action: str = Field(..., description="执行的操作类型")
    novels: List[Dict[str, Any]] = Field(default=[], description="小说列表（用于list操作）")
    novel_content: str = Field(default="", description="加载的小说内容（仅load_novel返回）")
    outline_content: str = Field(default="", description="生成的短剧大纲内容（仅generate_outline返回）")
    outline_url: str = Field(default="", description="生成的短剧大纲URL（仅generate_outline返回）")
    template_content: str = Field(default="", description="加载的提示词模板内容（仅load_template返回）")
    message: str = Field(..., description="操作结果消息")

class CallWorkflow3Input(BaseModel):
    """调用工作流3节点输入"""
    workflow_id: int = Field(default=3, description="工作流ID")
    node_name: Optional[str] = Field(default=None, description="要执行的节点名称（可选，如果不指定或为full_flow则执行完整流程）")
    files: List[File] = Field(default=[], description="上传的文件列表（仅upload操作需要）")
    file_name: str = Field(default="", description="文件名称（用于delete操作）")
    llm_model: str = Field(default="", description="选择的大模型名称（仅generate_scripts/generate_art_settings需要）")
    outline_file: Optional[File] = Field(default=None, description="上传的短剧剧集大纲文件（仅load_outline需要）")
    outline_url: str = Field(default="", description="大纲URL（用于generate_scripts节点）")
    outline_content: str = Field(default="", description="大纲内容（用于generate_scripts节点）")
    template_content: str = Field(default="", description="提示词模板内容（用于generate_scripts节点）")
    # generate_episodes 节点专用参数
    start_episode: int = Field(default=1, ge=1, description="起始集数（从1开始）")
    end_episode: int = Field(default=10, ge=1, description="结束集数（最多30集）")
    series_name: str = Field(default="动画短剧", description="短剧名称（用于文件命名）")
    # clear_all_files 节点专用参数
    delete_scripts: bool = Field(default=False, description="是否删除所有脚本文件")
    delete_outlines: bool = Field(default=False, description="是否删除所有大纲文件")
    delete_packages: bool = Field(default=False, description="是否删除所有压缩包")
    delete_all: bool = Field(default=False, description="是否删除所有文件（包括模板、小说等）")

class CallWorkflow3Output(BaseModel):
    """调用工作流3节点输出"""
    workflow_id: int = Field(default=3, description="工作流ID")
    action: str = Field(..., description="执行的操作类型")
    files: List[Dict[str, Any]] = Field(default=[], description="文件列表（用于list操作）")
    outline_content: str = Field(default="", description="短剧剧集大纲内容（仅load_outline返回）")
    analysis_result: str = Field(default="", description="大纲分析结果（仅analyze_outline返回）")
    scripts: Dict[str, str] = Field(default={}, description="生成的脚本字典（仅generate_scripts返回）")
    character_settings: List[Dict[str, Any]] = Field(default=[], description="角色美术设定（仅generate_art_settings返回）")
    scene_settings: List[Dict[str, Any]] = Field(default=[], description="场景美术设定（仅generate_art_settings返回）")
    prop_settings: List[Dict[str, Any]] = Field(default=[], description="道具美术设定（仅generate_art_settings返回）")
    package_url: str = Field(default="", description="最终压缩包URL（仅create_package返回）")
    episode_excel_url: str = Field(default="", description="剧集导入表Excel URL（仅fill_excel返回）")
    art_excel_url: str = Field(default="", description="美术资产导入表Excel URL（仅fill_excel返回）")
    message: str = Field(..., description="操作结果消息")
# ============================================================================
# 生成美术设定文档节点（独立功能）
# ============================================================================

class GenerateArtDocumentationInput(BaseModel):
    """生成美术设定文档节点输入"""
    start_episode: int = Field(default=1, ge=1, description="起始集数（从1开始）")
    end_episode: int = Field(default=10, ge=1, description="结束集数")
    series_name: str = Field(default="动画短剧", description="短剧名称（用于文件命名）")


class GenerateArtDocumentationOutput(BaseModel):
    """生成美术设定文档节点输出"""
    character_art_url: str = Field(default="", description="角色美术设定文档URL")
    scene_art_url: str = Field(default="", description="场景美术设定文档URL")
    character_settings: List[Dict[str, Any]] = Field(default=[], description="角色美术设定列表")
    scene_settings: List[Dict[str, Any]] = Field(default=[], description="场景美术设定列表")
    message: str = Field(..., description="操作结果消息")
