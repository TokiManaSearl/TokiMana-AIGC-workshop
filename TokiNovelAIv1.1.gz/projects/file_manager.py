"""
本地文件管理工具
运行: python file_manager.py
"""

import os
import sys
from pathlib import Path

# 本地存储根目录
STORAGE_ROOT = "/tmp/local_storage"


def show_tree(path=None, max_depth=2, current_depth=0):
    """显示目录树结构"""
    if path is None:
        path = STORAGE_ROOT

    path = Path(path)

    if current_depth > max_depth:
        return

    # 获取所有文件和目录
    items = sorted(path.iterdir())

    for item in items:
        # 缩进
        indent = "  " * current_depth

        if item.is_dir():
            print(f"{indent}📁 {item.name}/")
            # 递归显示子目录
            show_tree(item, max_depth, current_depth + 1)
        else:
            # 显示文件大小
            size = item.stat().st_size
            if size < 1024:
                size_str = f"{size} B"
            elif size < 1024 * 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size / 1024 / 1024:.1f} MB"
            print(f"{indent}📄 {item.name} ({size_str})")


def list_directory(path=None, show_details=True):
    """列出目录内容"""
    if path is None:
        path = STORAGE_ROOT

    path = Path(path)

    if not path.exists():
        print(f"❌ 目录不存在: {path}")
        return []

    if not path.is_dir():
        print(f"❌ 不是一个目录: {path}")
        return []

    print(f"\n📂 {path}")
    print("=" * 80)

    # 获取所有文件和目录
    items = sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name))

    directories = []
    files = []

    for item in items:
        if item.is_dir():
            directories.append(item)
        else:
            files.append(item)

    # 显示目录
    if directories:
        print("\n📁 目录：")
        for d in directories:
            count = len(list(d.iterdir())) if d.is_dir() else 0
            print(f"  • {d.name}/ ({count} 个项目)")

    # 显示文件
    if files:
        print("\n📄 文件：")
        for f in files:
            size = f.stat().st_size
            mtime = f.stat().st_mtime
            import time
            time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(mtime))

            if size < 1024:
                size_str = f"{size} B"
            elif size < 1024 * 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size / 1024 / 1024:.1f} MB"

            print(f"  • {f.name}")
            if show_details:
                print(f"      大小: {size_str}, 修改时间: {time_str}")

    print()
    return directories + files


def show_file_content(file_path, lines=50):
    """显示文件内容"""
    file_path = Path(file_path)

    if not file_path.exists():
        print(f"❌ 文件不存在: {file_path}")
        return

    if not file_path.is_file():
        print(f"❌ 不是一个文件: {file_path}")
        return

    print(f"\n📄 {file_path.name}")
    print("=" * 80)

    # 判断文件类型
    suffix = file_path.suffix.lower()

    if suffix in ['.md', '.txt']:
        # 文本文件
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content_lines = f.readlines()

            total_lines = len(content_lines)
            show_lines = min(lines, total_lines)

            print(f"总行数: {total_lines}, 显示前 {show_lines} 行:\n")

            for i, line in enumerate(content_lines[:show_lines], 1):
                print(f"{i:4d} | {line.rstrip()}")

            if total_lines > show_lines:
                print(f"\n... (还有 {total_lines - show_lines} 行)")

        except Exception as e:
            print(f"❌ 读取文件失败: {e}")

    elif suffix in ['.zip']:
        # 压缩文件
        import zipfile
        try:
            with zipfile.ZipFile(file_path, 'r') as z:
                print("压缩包内容：\n")
                for info in z.infolist():
                    size_str = f"{info.file_size} B"
                    if info.file_size > 1024:
                        size_str = f"{info.file_size / 1024:.1f} KB"
                    print(f"  • {info.filename} ({size_str})")
        except Exception as e:
            print(f"❌ 读取压缩包失败: {e}")

    else:
        print(f"⚠️  不支持的文件类型: {suffix}")
        print(f"文件大小: {file_path.stat().st_size} bytes")


def find_files(pattern, path=None):
    """查找文件"""
    if path is None:
        path = STORAGE_ROOT

    path = Path(path)

    if not path.exists():
        print(f"❌ 目录不存在: {path}")
        return []

    print(f"\n🔍 在 {path} 中查找 '{pattern}'")
    print("=" * 80)

    matches = list(path.rglob(f"*{pattern}*"))

    if not matches:
        print("❌ 没有找到匹配的文件")
        return []

    print(f"找到 {len(matches)} 个匹配的文件：\n")

    for match in matches:
        size = match.stat().st_size
        if size < 1024:
            size_str = f"{size} B"
        elif size < 1024 * 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size / 1024 / 1024:.1f} MB"

        rel_path = match.relative_to(STORAGE_ROOT)
        print(f"  • {rel_path} ({size_str})")

    return matches


def get_stats():
    """显示存储统计信息"""
    print("\n📊 存储统计")
    print("=" * 80)

    root = Path(STORAGE_ROOT)

    if not root.exists():
        print("❌ 存储目录不存在")
        return

    # 统计各类型文件
    stats = {}

    for item in root.rglob("*"):
        if item.is_file():
            suffix = item.suffix
            size = item.stat().st_size

            if suffix not in stats:
                stats[suffix] = {"count": 0, "total_size": 0}

            stats[suffix]["count"] += 1
            stats[suffix]["total_size"] += size

    # 按文件数量排序
    sorted_stats = sorted(stats.items(), key=lambda x: x[1]["count"], reverse=True)

    print("\n文件类型统计：\n")
    print(f"{'类型':<15} {'文件数':>10} {'总大小':>15}")
    print("-" * 40)

    total_files = 0
    total_size = 0

    for suffix, data in sorted_stats:
        count = data["count"]
        size = data["total_size"]

        total_files += count
        total_size += size

        if size < 1024 * 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size / 1024 / 1024:.1f} MB"

        print(f"{suffix or '(无扩展名)':<15} {count:>10} {size_str:>15}")

    print("-" * 40)
    print(f"{'总计':<15} {total_files:>10} {total_size / 1024 / 1024:>15.1f} MB")
    print()


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='本地文件管理工具')
    parser.add_argument('--tree', action='store_true', help='显示目录树结构')
    parser.add_argument('--list', type=str, nargs='?', const='', help='列出目录内容（可指定路径）')
    parser.add_argument('--show', type=str, help='显示文件内容')
    parser.add_argument('--find', type=str, help='查找文件')
    parser.add_argument('--stats', action='store_true', help='显示存储统计信息')
    parser.add_argument('--lines', type=int, default=50, help='显示文件的行数（默认50）')

    args = parser.parse_args()

    if args.tree:
        print("\n📂 本地存储目录树结构")
        print("=" * 80)
        show_tree()

    elif args.list is not None:
        path = args.list if args.list else None
        list_directory(path)

    elif args.show:
        show_file_content(args.show, args.lines)

    elif args.find:
        find_files(args.find)

    elif args.stats:
        get_stats()

    else:
        # 默认显示帮助
        print("=" * 80)
        print("📂 本地文件管理工具")
        print("=" * 80)
        print()
        print("存储目录: /tmp/local_storage/")
        print()
        print("使用方法：")
        print("  --tree              显示目录树结构")
        print("  --list [path]       列出目录内容（可指定路径）")
        print("  --show <file>       显示文件内容")
        print("  --find <pattern>    查找文件")
        print("  --stats             显示存储统计信息")
        print("  --lines <n>         显示文件的行数（默认50）")
        print()
        print("示例：")
        print("  python file_manager.py --tree")
        print("  python file_manager.py --list /tmp/local_storage/scripts/")
        print("  python file_manager.py --show /tmp/local_storage/scripts/第1集.md")
        print("  python file_manager.py --find '第1集'")
        print("  python file_manager.py --stats")
        print()
        print("默认显示存储目录内容：")
        print()

        # 默认显示存储目录
        list_directory()


if __name__ == "__main__":
    main()
