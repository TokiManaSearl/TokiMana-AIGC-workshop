#!/usr/bin/env python3
"""
本地HTTP服务器
在脱离扣子沙盒的情况下运行工作流系统
"""
import os
import sys
import json
import subprocess
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from werkzeug.utils import secure_filename
import traceback
from datetime import datetime

# 添加项目根目录和src目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_path = os.path.join(project_root, 'src')

# 设置COZE_WORKSPACE_PATH环境变量（所有节点都需要使用）
os.environ['COZE_WORKSPACE_PATH'] = project_root

# 强制使用本地存储（无需配置S3）
os.environ['FORCE_LOCAL_STORAGE'] = 'True'

sys.path.insert(0, project_root)
sys.path.insert(0, src_path)

from graphs.graph import main_graph
from utils.llm.llm_provider import get_llm_provider

# 创建Flask应用
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 最大上传16MB

# 存储临时文件
UPLOAD_FOLDER = '/tmp/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route('/')
def index():
    """主页"""
    return render_template_string(r'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>朱鹭的小说改编短剧脚本工作流系统V1.0</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: url('/assets/20220220114352_00099.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        .workflow-tabs {
            display: flex;
            margin-bottom: 30px;
            border-bottom: 2px solid #eee;
        }
        .workflow-tab {
            padding: 15px 30px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            font-weight: bold;
            color: #666;
            transition: all 0.3s;
        }
        .workflow-tab:hover {
            color: #667eea;
            background: #f8f9fa;
        }
        .workflow-tab.active {
            border-bottom-color: #667eea;
            color: #667eea;
        }
        .provider-card {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        .provider-card:hover {
            border-color: #667eea;
        }
        .provider-card.enabled {
            border-color: #667eea;
            background: #f8f9ff;
        }
        .provider-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .provider-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        .provider-description {
            color: #666;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .provider-config {
            display: none;
            margin-top: 15px;
        }
        .provider-config.show {
            display: block;
        }
        .config-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        .config-row .form-group {
            flex: 1;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-badge.configured {
            background: #d4edda;
            color: #155724;
        }
        .status-badge.not-configured {
            background: #f8d7da;
            color: #721c24;
        }
        .status-badge.enabled {
            background: #cce5ff;
            color: #004085;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        button:active {
            transform: translateY(0);
        }
        .result {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #667eea;
            display: none;
        }
        .result h3 {
            margin-bottom: 15px;
            color: #333;
        }
        .result pre {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .loading {
            display: none;
            text-align: center;
            padding: 40px;
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .node-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .node-button {
            background: white;
            color: #333;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        .node-button:hover {
            border-color: #667eea;
            background: #f8f9fa;
        }
        .node-button.active {
            border-color: #667eea;
            background: #667eea;
            color: white;
        }
        .file-input {
            position: relative;
            overflow: hidden;
            display: inline-block;
        }
        .file-input input[type=file] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .file-input-label {
            display: block;
            padding: 12px;
            background: #f8f9fa;
            border: 2px dashed #ccc;
            border-radius: 5px;
            text-align: center;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📚 朱鹭的小说改编短剧脚本工作流系统V1.0</h1>
        
        <div class="workflow-tabs">
            <div class="workflow-tab active" data-workflow="1">工作流1：提示词模板管理</div>
            <div class="workflow-tab" data-workflow="2">工作流2：短剧大纲生成</div>
            <div class="workflow-tab" data-workflow="3">工作流3：完整文件包生成</div>
            <div class="workflow-tab" data-workflow="llm">⚙️ LLM配置</div>
        </div>

        <div id="workflow1-form">
            <h2>工作流1：提示词模板管理</h2>
            <div class="form-group">
                <label>选择操作：</label>
                <div class="node-buttons">
                    <div class="node-button active" data-node="upload_template">上传提示词</div>
                    <div class="node-button" data-node="list_templates">列出提示词</div>
                    <div class="node-button" data-node="select_template">选择提示词</div>
                </div>
            </div>
            
            <!-- 模板选择下拉框（在列出提示词后自动填充） -->
            <div class="form-group" id="template_select_group" style="display: none;">
                <label>选择模板：</label>
                <select id="template_select" onchange="selectTemplateFromDropdown()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 点击"列出提示词"后，可以从这里选择已上传的模板
                </small>
            </div>
            
            <div class="form-group">
                <label>模板名称：</label>
                <input type="text" id="template_name" placeholder="例如：修仙主题改编模板" readonly>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 从下拉框选择模板后，名称会自动填充
                </small>
            </div>

            <div class="form-group">
                <label>提示词内容：</label>
                <textarea id="template_content" rows="10" placeholder="选择模板后，内容会自动显示..."></textarea>
            </div>

            <div class="form-group">
                <label>上传文件：</label>
                <div class="file-input">
                    <label class="file-input-label" for="template_file">点击选择文件</label>
                    <input type="file" id="template_file" accept=".md,.txt">
                </div>
                <div id="template_file_name" style="margin-top: 10px; color: #667eea;"></div>
            </div>

            <button onclick="executeWorkflow1()">执行</button>
        </div>

        <div id="workflow2-form" style="display: none;">
            <h2>工作流2：短剧大纲生成</h2>
            <div class="form-group">
                <label>选择操作：</label>
                <div class="node-buttons">
                    <div class="node-button active" data-node="upload_novel">上传小说</div>
                    <div class="node-button" data-node="list_novels">列出小说</div>
                    <div class="node-button" data-node="load_novel">加载小说</div>
                    <div class="node-button" data-node="load_template">加载提示词</div>
                    <div class="node-button" data-node="generate_outline">生成大纲</div>
                </div>
            </div>

            <!-- 小说选择下拉框（在列出小说后自动填充） -->
            <div class="form-group" id="novel_select_group_w2" style="display: none;">
                <label>选择小说：</label>
                <select id="novel_select_w2" onchange="selectNovelForWorkflow2()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 点击"列出小说"后，可以从这里选择已上传的小说
                </small>
            </div>
            
            <div class="form-group">
                <label>小说内容：</label>
                <textarea id="novel_content_w2" rows="5" placeholder="点击"加载小说"后，内容会自动显示..." readonly></textarea>
            </div>

            <!-- 提示词模板选择（用于加载提示词节点） -->
            <div class="form-group" id="template_select_group_w2" style="display: none;">
                <label>选择提示词模板：</label>
                <select id="template_select_w2" onchange="selectTemplateForWorkflow2()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 从工作流1中选择一个提示词模板，然后点击"加载提示词"查看内容
                </small>
            </div>

            <div class="form-group">
                <label>提示词模板内容：</label>
                <textarea id="template_content_w2" rows="5" placeholder="点击"加载提示词"后，内容会自动显示..." readonly></textarea>
            </div>

            <!-- 大纲选择下拉框（在列出大纲后自动填充） -->
            <div class="form-group" id="outline_select_group_w2" style="display: none;">
                <label>选择大纲：</label>
                <select id="outline_select_w2" onchange="selectOutlineForWorkflow2()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 列出大纲后选择一个大纲文件，然后点击"选择大纲"保存
                </small>
            </div>
            <div class="form-group">
                <label>大纲内容：</label>
                <textarea id="outline_content_w2" rows="5" placeholder="点击"选择大纲"后，内容会自动显示..." readonly></textarea>
            </div>

            <div class="form-group">
                <label>小说名称：</label>
                <input type="text" id="novel_name" placeholder="例如：炸炉炼丹师">
            </div>

            <div class="form-group">
                <label>上传小说文件：</label>
                <div class="file-input">
                    <label class="file-input-label" for="novel_file">点击选择文件</label>
                    <input type="file" id="novel_file" accept=".txt">
                </div>
                <div id="novel_file_name" style="margin-top: 10px; color: #667eea;"></div>
            </div>

            <div class="form-group">
                <label>自定义输出目录（可选）：</label>
                <input type="text" id="custom_output_dir_w2" placeholder="例如：C:\Users\Administrator\Downloads">
                <small style="color: #666; font-size: 12px;">留空则使用默认路径：assets/storage</small>
            </div>

            <button onclick="executeWorkflow2()">执行</button>
        </div>

        <div id="workflow3-form" style="display: none;">
            <h2>工作流3：完整文件包生成</h2>
            <div class="form-group">
                <label>选择操作：</label>
                <div class="node-buttons">
                    <div class="node-button active" data-node="load_template">加载提示词</div>
                    <div class="node-button" data-node="list_outlines">列出大纲</div>
                    <div class="node-button" data-node="load_outline">加载大纲</div>
                    <div class="node-button" data-node="generate_scripts">生成剧集脚本</div>
                    <div class="node-button" data-node="generate_art_documentation">生成美术设定文档</div>
                </div>
            </div>

            <!-- 提示词模板选择（用于加载提示词节点） -->
            <div class="form-group" id="template_select_group_w3" style="display: none;">
                <label>选择提示词模板：</label>
                <select id="template_select_w3" onchange="selectTemplateForWorkflow3()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 从工作流1中选择一个提示词模板，然后点击"加载提示词"查看内容
                </small>
            </div>
            <div class="form-group">
                <label>提示词模板内容：</label>
                <textarea id="template_content_w3" rows="5" placeholder="点击"加载提示词"后，内容会自动显示..." readonly></textarea>
            </div>

            <!-- 大纲选择下拉框（在列出大纲后自动填充） -->
            <div class="form-group" id="outline_select_group_w3" style="display: none;">
                <label>选择大纲：</label>
                <select id="outline_select_w3" onchange="selectOutlineForWorkflow3()">
                    <option value="">-- 请选择 --</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 点击"列出大纲"后，可以从这里选择已生成的大纲文件
                </small>
            </div>
            <div class="form-group">
                <label>大纲内容：</label>
                <textarea id="outline_content_w3" rows="5" placeholder="点击"加载大纲"后，内容会自动显示..." readonly></textarea>
            </div>

            <div class="form-group">
                <label>起始集数：</label>
                <input type="number" id="start_episode" value="1" min="1">
            </div>

            <div class="form-group">
                <label>结束集数：</label>
                <input type="number" id="end_episode" value="3" min="1" max="5">
                <small style="color: #666; font-size: 12px;">⚠️ 单次最多生成5集脚本，每批会自动生成角色和场景美术设定</small>
            </div>

            <div class="form-group">
                <label>短剧名称：</label>
                <input type="text" id="series_name" placeholder="例如：炸炉炼丹师动画短剧">
            </div>

            <div class="form-group">
                <label>自定义输出目录（可选）：</label>
                <input type="text" id="custom_output_dir_w3" placeholder="例如：C:\Users\Administrator\Downloads">
                <small style="color: #666; font-size: 12px;">留空则使用默认路径：assets/storage</small>
            </div>

            <button onclick="executeWorkflow3()">执行</button>
        </div>

        <div id="workflowllm-form" style="display: none;">
            <h2>⚙️ LLM配置</h2>
            <div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px; border-left: 4px solid #667eea;">
                <h3 style="margin-bottom: 10px; color: #333;">💡 配置说明</h3>
                <p style="color: #666; line-height: 1.6;">
                    在本地运行时，需要配置您自己的LLM API Key。系统支持多个提供商，包括：
                    <strong>火山引擎方舟（豆包、DeepSeek、Kimi）</strong>、
                    <strong>DeepSeek官方</strong>、
                    <strong>Google Gemini</strong>、
                    <strong>OpenAI GPT</strong>、
                    <strong>通义千问</strong>、
                    <strong>智谱AI</strong>等。
                </p>
            </div>

            <div id="providers-container" style="margin-top: 20px;">
                <!-- 提供商卡片会通过JavaScript动态加载 -->
                <div class="loading" style="display: block;">
                    <div class="spinner"></div>
                    <p>正在加载提供商列表...</p>
                </div>
            </div>

            <div id="provider-form" style="display: none; margin-top: 20px;">
                <h3 id="provider-title" style="margin-bottom: 15px; color: #333;">配置提供商</h3>
                
                <div class="form-group">
                    <label>API Key：</label>
                    <input type="password" id="api_key" placeholder="请输入API Key">
                    <small style="color: #666; display: block; margin-top: 5px;">
                        🔒 您的API Key会被安全保存在本地配置文件中
                    </small>
                </div>

                <div class="form-group">
                    <label>API端点：</label>
                    <input type="text" id="api_endpoint" placeholder="API端点URL">
                </div>

                <div class="form-group">
                    <label>模型名称：</label>
                    <input type="text" id="api_model" placeholder="模型名称">
                </div>

                <div class="config-row">
                    <div class="form-group">
                        <label>温度 (Temperature)：</label>
                        <input type="number" id="api_temperature" value="0.7" min="0" max="2" step="0.1">
                    </div>
                    <div class="form-group">
                        <label>最大Token数：</label>
                        <input type="number" id="api_max_tokens" value="4096" min="100" step="100">
                    </div>
                </div>

                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button onclick="testProviderConnection()" style="flex: 1;">🧪 测试连接</button>
                    <button onclick="saveProviderConfig()" style="flex: 1;">💾 保存配置</button>
                </div>

                <button onclick="enableProvider()" style="margin-top: 10px; background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    ✅ 启用此提供商
                </button>
            </div>
        </div>

        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p>正在执行，请稍候...</p>
        </div>

        <div class="result" id="result">
            <h3>执行结果</h3>
            <pre id="result-content"></pre>
        </div>
    </div>

    <script>
        // 工作流切换
        document.querySelectorAll('.workflow-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                // 移除所有active类
                document.querySelectorAll('.workflow-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('[id^="workflow"][id$="-form"]').forEach(f => f.style.display = 'none');
                
                // 添加active类
                this.classList.add('active');
                const workflow = this.dataset.workflow;
                document.getElementById(`workflow${workflow}-form`).style.display = 'block';
            });
        });

        // 节点按钮切换
        document.querySelectorAll('.node-button').forEach(btn => {
            btn.addEventListener('click', function() {
                const parent = this.parentElement;
                parent.querySelectorAll('.node-button').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // 文件选择显示文件名
        document.getElementById('template_file').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : '';
            document.getElementById('template_file_name').textContent = fileName;
        });

        document.getElementById('novel_file').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : '';
            document.getElementById('novel_file_name').textContent = fileName;
        });

        // 执行工作流（通用函数）
        async function executeWorkflow(workflowId, params) {
            const loading = document.getElementById('loading');
            const result = document.getElementById('result');
            const resultContent = document.getElementById('result-content');
            
            loading.style.display = 'block';
            result.style.display = 'none';
            
            try {
                const formData = new FormData();
                formData.append('workflow_id', workflowId);
                
                // 添加文件
                if (workflowId === 1) {
                    const fileInput = document.getElementById('template_file');
                    if (fileInput.files[0]) {
                        formData.append('file', fileInput.files[0]);
                    }
                } else if (workflowId === 2) {
                    const fileInput = document.getElementById('novel_file');
                    if (fileInput.files[0]) {
                        formData.append('file', fileInput.files[0]);
                    }
                    
                    // 特殊处理：如果是选择大纲节点，添加outline_name参数
                    if (params.node_name === 'select_outline') {
                        const outlineSelect = document.getElementById('outline_select_w2');
                        if (outlineSelect) {
                            formData.append('outline_name', outlineSelect.value);
                        }
                    }
                } else if (workflowId === 3) {
                    // 特殊处理：如果是加载大纲节点，添加outline_name参数
                    if (params.node_name === 'load_outline') {
                        const outlineSelect = document.getElementById('outline_select_w3');
                        if (outlineSelect) {
                            formData.append('outline_name', outlineSelect.value);
                        }
                    }
                }
                
                // 添加参数
                Object.keys(params).forEach(key => {
                    formData.append(key, params[key]);
                });
                
                const response = await fetch('/execute', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    resultContent.textContent = JSON.stringify(data, null, 2);
                    
                    // 特殊处理：如果是工作流1的列出提示词，填充下拉框并添加删除提示
                    if (workflowId === 1 && params.node_name === 'list_templates' && data.templates) {
                        populateTemplateDropdown(data.templates);
                        // 同时填充工作流2和工作流3的下拉框
                        populateTemplateDropdownForWorkflow2(data.templates);
                        populateTemplateDropdownForWorkflow3(data.templates);
                        // 添加手动删除文件的提示
                        if (data.templates && data.templates.length > 0) {
                            const deleteTip = document.createElement('div');
                            deleteTip.style.marginTop = '15px';
                            deleteTip.style.padding = '10px';
                            deleteTip.style.backgroundColor = '#f0f8ff';
                            deleteTip.style.border = '1px solid #b0d4ff';
                            deleteTip.style.borderRadius = '5px';
                            deleteTip.innerHTML = `
                                <strong style="color: #0066cc;">💡 如何删除模板？</strong>
                                <ul style="margin-top: 5px; margin-left: 20px; color: #333;">
                                    <li>查看模板列表中的"文件路径"</li>
                                    <li>打开文件资源管理器，进入 <code>assets/storage/templates</code> 目录</li>
                                    <li>找到对应的文件并手动删除</li>
                                    <li>刷新页面或重新点击"列出提示词"，列表会自动更新</li>
                                </ul>
                            `;
                            result.appendChild(deleteTip);
                        }
                    }
                    
                    // 特殊处理：如果是工作流1的选择提示词，显示内容
                    if (workflowId === 1 && params.node_name === 'select_template') {
                        if (data.template_content) {
                            document.getElementById('template_content').value = data.template_content;
                        }
                    }
                    
                    // 特殊处理：如果是工作流2的列出小说，填充小说下拉框
                    if (workflowId === 2 && params.node_name === 'list_novels' && data.novels) {
                        populateNovelDropdownForWorkflow2(data.novels);
                    }
                    
                    // 特殊处理：如果是工作流2的加载小说，显示内容
                    if (workflowId === 2 && params.node_name === 'load_novel' && data.novel_content) {
                        document.getElementById('novel_content_w2').value = data.novel_content;
                    }
                    
                    // 特殊处理：如果是工作流2的加载提示词，显示内容
                    if (workflowId === 2 && params.node_name === 'load_template' && data.template_content) {
                        document.getElementById('template_content_w2').value = data.template_content;
                    }
                    
                    // 特殊处理：如果是工作流2的列出大纲，填充大纲下拉框
                    if (workflowId === 2 && params.node_name === 'list_outlines' && data.outlines) {
                        populateOutlineDropdownForWorkflow2(data.outlines);
                    }
                    
                    // 特殊处理：如果是工作流3的列出大纲，填充大纲下拉框
                    if (workflowId === 3 && params.node_name === 'list_outlines' && data.outlines) {
                        populateOutlineDropdownForWorkflow3(data.outlines);
                    }
                    
                    // 特殊处理：如果是工作流2的选择大纲，显示内容
                    if (workflowId === 2 && params.node_name === 'select_outline' && data.outline_content) {
                        document.getElementById('outline_content_w2').value = data.outline_content;
                    }
                    
                    // 特殊处理：如果是工作流3的加载提示词，显示内容
                    if (workflowId === 3 && params.node_name === 'load_template' && data.template_content) {
                        document.getElementById('template_content_w3').value = data.template_content;
                    }
                    
                    // 特殊处理：如果是工作流3的列出大纲，填充大纲下拉框
                    if (workflowId === 3 && params.node_name === 'list_outlines' && data.outlines) {
                        populateOutlineDropdownForWorkflow3(data.outlines);
                    }
                    
                    // 特殊处理：如果是工作流3的加载大纲，显示内容
                    if (workflowId === 3 && params.node_name === 'load_outline' && data.outline_content) {
                        document.getElementById('outline_content_w3').value = data.outline_content;
                    }
                    
                    // 特殊处理：如果是工作流3的生成美术设定文档，显示结果
                    if (workflowId === 3 && params.node_name === 'generate_art_documentation' && data.message) {
                        // 在结果区域显示完整消息
                        const artResult = document.createElement('div');
                        artResult.style.marginTop = '15px';
                        artResult.style.padding = '15px';
                        artResult.style.backgroundColor = '#fff8e1';
                        artResult.style.border = '1px solid #ffb300';
                        artResult.style.borderRadius = '5px';
                        artResult.style.whiteSpace = 'pre-wrap';
                        artResult.textContent = data.message;
                        result.appendChild(artResult);
                    }
                } else {
                    resultContent.textContent = '错误：' + (data.error || '未知错误');
                }
            } catch (error) {
                resultContent.textContent = '错误：' + error.message;
            }
            
            loading.style.display = 'none';
            result.style.display = 'block';
        }
        
        // 填充模板下拉框（工作流1）
        function populateTemplateDropdown(templates) {
            const select = document.getElementById('template_select');
            const selectGroup = document.getElementById('template_select_group');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加模板选项
            templates.forEach(template => {
                const option = document.createElement('option');
                option.value = template.file_key;  // 使用file_key作为value
                option.textContent = template.name;  // 显示原始文件名
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (templates.length > 0) {
                selectGroup.style.display = 'block';
            }
        }
        
        // 填充小说下拉框（工作流2）
        function populateNovelDropdownForWorkflow2(novels) {
            const select = document.getElementById('novel_select_w2');
            const selectGroup = document.getElementById('novel_select_group_w2');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加小说选项
            novels.forEach(novel => {
                const option = document.createElement('option');
                option.value = novel.name;  // 使用小说名称作为value
                option.textContent = novel.name;  // 显示小说名称
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (novels.length > 0) {
                selectGroup.style.display = 'block';
            }
        }

        // 从下拉框选择小说（工作流2）
        function selectNovelForWorkflow2() {
            const select = document.getElementById('novel_select_w2');
            const selectedNovelName = select.value;
            
            if (selectedNovelName) {
                // 存储小说名称供后续使用
                window.selectedNovelName = selectedNovelName;
                console.log('小说名称已选择:', selectedNovelName);
                
                // 自动切换到"加载小说"节点
                const loadNovelButton = document.querySelector('#workflow2-form .node-button[data-node="load_novel"]');
                if (loadNovelButton) {
                    document.querySelectorAll('#workflow2-form .node-button').forEach(btn => btn.classList.remove('active'));
                    loadNovelButton.classList.add('active');
                }
            }
        }
        
        // 填充模板下拉框（工作流2）
        function populateTemplateDropdownForWorkflow2(templates) {
            const select = document.getElementById('template_select_w2');
            const selectGroup = document.getElementById('template_select_group_w2');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加模板选项
            templates.forEach(template => {
                const option = document.createElement('option');
                option.value = template.name;
                option.textContent = template.name;
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (templates.length > 0) {
                selectGroup.style.display = 'block';
            }
        }
        
        // 填充模板下拉框（工作流3）
        function populateTemplateDropdownForWorkflow3(templates) {
            const select = document.getElementById('template_select_w3');
            const selectGroup = document.getElementById('template_select_group_w3');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加模板选项
            templates.forEach(template => {
                const option = document.createElement('option');
                option.value = template.name;
                option.textContent = template.name;
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (templates.length > 0) {
                selectGroup.style.display = 'block';
            }
        }
        
        // 从下拉框选择模板（工作流1）
        function selectTemplateFromDropdown() {
            const select = document.getElementById('template_select');
            const fileKey = select.value;  // file_key (如 "templates/template_1769878816_aac8368b1e10.md")
            
            if (fileKey) {
                // 获取显示的名称（原始文件名）
                const displayName = select.options[select.selectedIndex].textContent;
                
                // 填充模板名称（不填充删除模板名称，让用户手动输入）
                document.getElementById('template_name').value = displayName;
                
                // 自动切换到"选择提示词"节点
                const selectTemplateButton = document.querySelector('#workflow1-form .node-button[data-node="select_template"]');
                if (selectTemplateButton) {
                    document.querySelectorAll('#workflow1-form .node-button').forEach(btn => btn.classList.remove('active'));
                    selectTemplateButton.classList.add('active');
                }
            }
        }
        
        // 从下拉框选择模板（工作流2）
        function selectTemplateForWorkflow2() {
            const select = document.getElementById('template_select_w2');
            const selectedTemplate = select.value;
            
            if (selectedTemplate) {
                // 自动切换到"加载提示词"节点
                const loadTemplateButton = document.querySelector('#workflow2-form .node-button[data-node="load_template"]');
                if (loadTemplateButton) {
                    document.querySelectorAll('#workflow2-form .node-button').forEach(btn => btn.classList.remove('active'));
                    loadTemplateButton.classList.add('active');
                }
            }
        }

        // 填充大纲下拉框（工作流2）
        function populateOutlineDropdownForWorkflow2(outlines) {
            const select = document.getElementById('outline_select_w2');
            const selectGroup = document.getElementById('outline_select_group_w2');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加大纲选项
            outlines.forEach(outline => {
                const option = document.createElement('option');
                option.value = outline.name;  // 使用大纲名称作为value
                option.textContent = outline.name;  // 显示大纲名称
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (outlines.length > 0) {
                selectGroup.style.display = 'block';
            }
        }

        // 从下拉框选择大纲（工作流2）
        function selectOutlineForWorkflow2() {
            const select = document.getElementById('outline_select_w2');
            const selectedOutlineName = select.value;
            
            if (selectedOutlineName) {
                // 自动切换到"选择大纲"节点
                const selectOutlineButton = document.querySelector('#workflow2-form .node-button[data-node="select_outline"]');
                if (selectOutlineButton) {
                    document.querySelectorAll('#workflow2-form .node-button').forEach(btn => btn.classList.remove('active'));
                    selectOutlineButton.classList.add('active');
                }
            }
        }
        
        // 填充模板下拉框（工作流3）
        function populateTemplateDropdownForWorkflow3(templates) {
            const select = document.getElementById('template_select_w3');
            const selectGroup = document.getElementById('template_select_group_w3');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加模板选项
            templates.forEach(template => {
                const option = document.createElement('option');
                option.value = template.name;
                option.textContent = template.name;
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (templates.length > 0) {
                selectGroup.style.display = 'block';
            }
        }

        // 从下拉框选择模板（工作流3）
        function selectTemplateForWorkflow3() {
            const select = document.getElementById('template_select_w3');
            const selectedTemplate = select.value;
            
            if (selectedTemplate) {
                // 自动切换到"加载提示词"节点
                const loadTemplateButton = document.querySelector('#workflow3-form .node-button[data-node="load_template"]');
                if (loadTemplateButton) {
                    document.querySelectorAll('#workflow3-form .node-button').forEach(btn => btn.classList.remove('active'));
                    loadTemplateButton.classList.add('active');
                }
            }
        }

        // 填充大纲下拉框（工作流3）
        function populateOutlineDropdownForWorkflow3(outlines) {
            const select = document.getElementById('outline_select_w3');
            const selectGroup = document.getElementById('outline_select_group_w3');
            
            // 清空现有选项
            select.innerHTML = '<option value="">-- 请选择 --</option>';
            
            // 添加大纲选项
            outlines.forEach(outline => {
                const option = document.createElement('option');
                option.value = outline.name;  // 使用大纲名称作为value
                option.textContent = outline.name;  // 显示大纲名称
                select.appendChild(option);
            });
            
            // 显示下拉框
            if (outlines.length > 0) {
                selectGroup.style.display = 'block';
            }
        }

        // 从下拉框选择大纲（工作流3）
        function selectOutlineForWorkflow3() {
            const select = document.getElementById('outline_select_w3');
            const selectedOutlineName = select.value;
            
            if (selectedOutlineName) {
                // 存储大纲名称供后续使用
                window.selectedOutlineName = selectedOutlineName;
                console.log('大纲名称已选择:', selectedOutlineName);
                
                // 自动切换到"加载大纲"节点
                const loadOutlineButton = document.querySelector('#workflow3-form .node-button[data-node="load_outline"]');
                if (loadOutlineButton) {
                    document.querySelectorAll('#workflow3-form .node-button').forEach(btn => btn.classList.remove('active'));
                    loadOutlineButton.classList.add('active');
                }
            }
        }

        // 执行工作流1
        async function executeWorkflow1() {
            const node = document.querySelector('#workflow1-form .node-button.active').dataset.node;
            const templateName = document.getElementById('template_name').value;
            const templateContent = document.getElementById('template_content').value;
            
            // 构建基础参数
            const params = {
                node_name: node,
                template_name: templateName,
                new_content: templateContent
            };
            
            await executeWorkflow(1, params);
        }

        // 执行工作流2
        async function executeWorkflow2() {
            const node = document.querySelector('#workflow2-form .node-button.active').dataset.node;
            const novelName = document.getElementById('novel_name').value;
            const customOutputDir = document.getElementById('custom_output_dir_w2').value;
            const templateSelect = document.getElementById('template_select_w2');
            const novelSelect = document.getElementById('novel_select_w2');
            
            const params = {
                node_name: node,
                novel_name: novelName
            };
            
            // 如果是加载小说节点，使用下拉框选择小说名称
            if (node === 'load_novel' && (novelSelect.value || window.selectedNovelName)) {
                params.novel_name = novelSelect.value || window.selectedNovelName;
            }
            
            // 如果是加载提示词节点，添加模板名称
            if (node === 'load_template' && templateSelect.value) {
                params.template_name = templateSelect.value;
            }
            
            // 如果是生成脚本节点，添加大纲内容（如果已选择）
            if (node === 'generate_scripts' && window.selectedOutlineContent) {
                params.outline_content = window.selectedOutlineContent;
            }
            
            // 如果指定了自定义输出目录，添加到参数中
            if (customOutputDir && customOutputDir.trim()) {
                params.custom_output_dir = customOutputDir.trim();
            }
            
            await executeWorkflow(2, params);
        }

        // 执行工作流3
        async function executeWorkflow3() {
            const node = document.querySelector('#workflow3-form .node-button.active').dataset.node;
            const startEpisode = document.getElementById('start_episode').value;
            const endEpisode = document.getElementById('end_episode').value;
            const seriesName = document.getElementById('series_name').value;
            const customOutputDir = document.getElementById('custom_output_dir_w3').value;
            const templateSelect = document.getElementById('template_select_w3');
            const outlineSelect = document.getElementById('outline_select_w3');
            
            const params = {
                node_name: node,
                start_episode: parseInt(startEpisode),
                end_episode: parseInt(endEpisode),
                series_name: series_name
            };
            
            // 如果是加载提示词节点，添加模板名称
            if (node === 'load_template' && templateSelect.value) {
                params.template_name = templateSelect.value;
            }
            
            // 如果是加载大纲节点，添加大纲名称（使用window.selectedOutlineName）
            if (node === 'load_outline' && (outlineSelect.value || window.selectedOutlineName)) {
                params.outline_name = outlineSelect.value || window.selectedOutlineName;
            }
            
            // 如果指定了自定义输出目录，添加到参数中
            if (customOutputDir && customOutputDir.trim()) {
                params.custom_output_dir = customOutputDir.trim();
            }
            
            await executeWorkflow(3, params);
        }


        // LLM配置相关函数
        let currentProviderId = null;

        // 加载提供商列表
        async function loadProviders() {
            const container = document.getElementById('providers-container');
            
            try {
                const response = await fetch('/llm/providers');
                const data = await response.json();
                
                if (response.ok && data.success) {
                    renderProviders(data.providers, data.enabled_provider);
                } else {
                    container.innerHTML = `<p style="color: red;">加载失败：${data.message || '未知错误'}</p>`;
                }
            } catch (error) {
                container.innerHTML = `<p style="color: red;">加载失败：${error.message}</p>`;
            }
        }

        // 渲染提供商列表
        function renderProviders(providers, enabledProvider) {
            const container = document.getElementById('providers-container');
            
            if (providers.length === 0) {
                container.innerHTML = '<p style="color: #666;">暂无可用提供商</p>';
                return;
            }
            
            let html = '';
            providers.forEach(provider => {
                const statusClass = provider.configured ? 'configured' : 'not-configured';
                const statusText = provider.configured ? '已配置' : '未配置';
                const enabledClass = provider.enabled ? 'enabled' : '';
                const enabledText = provider.enabled ? '✅ 已启用' : '';
                
                html += `
                    <div class="provider-card ${enabledClass}" data-provider="${provider.id}">
                        <div class="provider-header">
                            <div>
                                <div class="provider-name">${provider.name}</div>
                                <div class="provider-description">${provider.description}</div>
                            </div>
                            <div>
                                <span class="status-badge ${statusClass}">${statusText}</span>
                                ${enabledText ? `<span class="status-badge enabled">${enabledText}</span>` : ''}
                            </div>
                        </div>
                        <button onclick="openProviderConfig('${provider.id}')" style="width: auto; padding: 8px 20px; font-size: 14px;">
                            ⚙️ 配置
                        </button>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        // 打开提供商配置
        async function openProviderConfig(providerId) {
            currentProviderId = providerId;
            
            try {
                const response = await fetch(`/llm/provider/${providerId}`);
                const data = await response.json();
                
                if (response.ok && data.success) {
                    const provider = data.provider;
                    
                    document.getElementById('provider-title').textContent = `配置：${provider.name}`;
                    document.getElementById('api_key').value = provider.config.api_key || '';
                    document.getElementById('api_endpoint').value = provider.config.endpoint || '';
                    document.getElementById('api_model').value = provider.config.model || '';
                    document.getElementById('api_temperature').value = provider.config.temperature || 0.7;
                    document.getElementById('api_max_tokens').value = provider.config.max_tokens || 4096;
                    
                    document.getElementById('provider-form').style.display = 'block';
                } else {
                    alert('加载提供商配置失败：' + (data.message || '未知错误'));
                }
            } catch (error) {
                alert('加载提供商配置失败：' + error.message);
            }
        }

        // 测试连接
        async function testProviderConnection() {
            if (!currentProviderId) {
                alert('请先选择一个提供商');
                return;
            }
            
            const apiKey = document.getElementById('api_key').value;
            const endpoint = document.getElementById('api_endpoint').value;
            const model = document.getElementById('api_model').value;
            const temperature = document.getElementById('api_temperature').value;
            const maxTokens = document.getElementById('api_max_tokens').value;
            
            if (!apiKey) {
                alert('请先输入API Key');
                return;
            }
            
            if (!model) {
                alert('请先输入模型名称');
                return;
            }
            
            try {
                const response = await fetch(`/llm/test/${currentProviderId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        api_key: apiKey,
                        endpoint: endpoint,
                        model: model,
                        temperature: temperature,
                        max_tokens: maxTokens
                    })
                });
                
                const data = await response.json();
                
                if (response.ok && data.success) {
                    alert('✅ ' + data.message);
                } else {
                    alert('❌ ' + (data.message || '连接失败'));
                }
            } catch (error) {
                alert('❌ 连接失败：' + error.message);
            }
        }

        // 保存配置
        async function saveProviderConfig() {
            if (!currentProviderId) {
                alert('请先选择一个提供商');
                return;
            }
            
            const config = {
                api_key: document.getElementById('api_key').value,
                endpoint: document.getElementById('api_endpoint').value,
                model: document.getElementById('api_model').value,
                temperature: parseFloat(document.getElementById('api_temperature').value),
                max_tokens: parseInt(document.getElementById('api_max_tokens').value)
            };
            
            if (!config.api_key) {
                alert('请输入API Key');
                return;
            }
            
            try {
                const response = await fetch(`/llm/provider/${currentProviderId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(config)
                });
                
                const data = await response.json();
                
                if (response.ok && data.success) {
                    alert('✅ 配置保存成功！');
                    loadProviders(); // 重新加载列表
                } else {
                    alert('❌ 保存失败：' + (data.message || '未知错误'));
                }
            } catch (error) {
                alert('❌ 保存失败：' + error.message);
            }
        }

        // 启用提供商
        async function enableProvider() {
            if (!currentProviderId) {
                alert('请先选择一个提供商');
                return;
            }
            
            try {
                const response = await fetch(`/llm/enable/${currentProviderId}`, {
                    method: 'POST'
                });
                
                const data = await response.json();
                
                if (response.ok && data.success) {
                    alert('✅ 已启用提供商：' + currentProviderId);
                    loadProviders(); // 重新加载列表
                    document.getElementById('provider-form').style.display = 'none';
                } else {
                    alert('❌ 启用失败：' + (data.message || '未知错误'));
                }
            } catch (error) {
                alert('❌ 启用失败：' + error.message);
            }
        }

        // 页面加载时加载提供商列表
        document.addEventListener('DOMContentLoaded', function() {
            // 当切换到LLM配置标签时，加载提供商列表
            document.querySelector('[data-workflow="llm"]').addEventListener('click', loadProviders);
        });
    </script>

    <!-- 版权声明 -->
    <footer style="margin-top: 40px; padding: 20px; text-align: center; color: #999; font-size: 12px; border-top: 1px solid #eee;">
        <p>本项目仓库地址 https://github.com/TokiManaSearl/TokiMana-AIGC-workshop；群 1079058923</p>
        <p>本工作流软件开源免费，仅供学习使用；</p>
        <p>禁止用于洗稿或其他涉灰产业务。禁止商用，尤其是禁止拿去收费卖课；</p>
        <p>最终解释权归作者所有</p>
    </footer>
</body>
</html>
    r''')


@app.route('/assets/<path:filename>')
def serve_assets(filename):
    """提供assets目录下的文件访问"""
    assets_path = os.path.join(project_root, 'assets')
    return send_from_directory(assets_path, filename)


@app.route('/execute', methods=['POST'])
def execute_workflow():
    """执行工作流"""
    try:
        workflow_id = int(request.form.get('workflow_id', 1))
        node_name = request.form.get('node_name', '')
        
        # 构造输入参数
        inputs = {
            'workflow_id': workflow_id,
            'node_name': node_name
        }
        
        # 添加其他参数
        if 'template_name' in request.form:
            inputs['template_name'] = request.form['template_name']
        if 'new_content' in request.form:
            inputs['new_content'] = request.form['new_content']
        if 'novel_name' in request.form:
            inputs['novel_name'] = request.form['novel_name']
        if 'model_name' in request.form:
            inputs['model_name'] = request.form['model_name']
        if 'start_episode' in request.form:
            inputs['start_episode'] = int(request.form['start_episode'])
        if 'end_episode' in request.form:
            inputs['end_episode'] = int(request.form['end_episode'])
        if 'series_name' in request.form:
            inputs['series_name'] = request.form['series_name']
        if 'file_type' in request.form:
            inputs['file_type'] = request.form['file_type']
        if 'outline_name' in request.form:
            inputs['outline_name'] = request.form['outline_name']
        if 'original_filename' in request.form:
            inputs['original_filename'] = request.form['original_filename']
        
        # 支持自定义输出目录
        if 'custom_output_dir' in request.form:
            custom_output_dir = request.form['custom_output_dir']
            if custom_output_dir:
                # 设置环境变量，供工作流节点使用
                os.environ['CUSTOM_STORAGE_PATH'] = custom_output_dir
                # 重新获取存储实例
                from utils.local_storage import _local_storage_instance
                if _local_storage_instance is not None:
                    # 清除全局实例，强制重新创建
                    _local_storage_instance = None
        
        # 处理文件上传
        if 'file' in request.files:
            file = request.files['file']
            if file:
                # 直接使用浏览器传递的原始文件名（不使用secure_filename，因为它会移除中文字符）
                original_filename = file.filename
                print(f"[DEBUG] Original filename from file object: {file.filename}")
                print(f"[DEBUG] Original filename (after): {original_filename}")
                print(f"[DEBUG] UPLOAD_FOLDER: {UPLOAD_FOLDER}")
                
                # 生成安全的存储文件名（包含时间戳，避免文件名冲突）
                import time
                import hashlib
                # 对原始文件名进行哈希，生成安全的存储文件名
                file_hash = hashlib.md5(f"{original_filename}{time.time()}".encode()).hexdigest()[:8]
                file_ext = os.path.splitext(original_filename)[1]
                safe_storage_filename = f"{file_hash}{file_ext}"
                
                filepath = os.path.join(UPLOAD_FOLDER, safe_storage_filename)
                print(f"[DEBUG] Final filepath: {filepath}")
                file.save(filepath)
                inputs['file'] = filepath
                inputs['original_filename'] = original_filename  # 保存原始文件名
        
        # 如果传递了自定义输出目录，添加到输入中
        if 'custom_output_dir' in request.form:
            inputs['custom_output_dir'] = request.form['custom_output_dir']
        
        # 选择对应的工作流图和节点函数
        if workflow_id == 1:
            # 工作流1：提示词模板管理
            from graphs.nodes.upload_template_node import upload_template_node
            from graphs.nodes.list_templates_node import list_templates_node
            from graphs.nodes.select_template_node import select_template_node

            # 根据node_name选择对应的节点函数
            node_functions = {
                'upload_template': upload_template_node,
                'list_templates': list_templates_node,
                'select_template': select_template_node
            }

            if node_name not in node_functions:
                return jsonify({'error': f'无效的节点名称: {node_name}'}), 400

            # 创建Context和Config
            from langgraph.runtime import Runtime
            from coze_coding_utils.runtime_ctx.context import Context
            from langchain_core.runnables import RunnableConfig
            from utils.file.file import File
            from graphs.state import (
                UploadTemplateInput,
                ListTemplatesInput,
                SelectTemplateInput
            )

            ctx = Context(
                run_id="local_run",
                space_id="local_space",
                project_id="local_project"
            )
            runtime = Runtime(context=ctx)
            config = RunnableConfig()

            # 根据node_name创建对应的输入模型
            node_input = None
            if node_name == 'upload_template':
                # 上传模板
                file_url = inputs.get('file', '')
                template_name = inputs.get('template_name', '') or inputs.get('original_filename', '')
                node_input = UploadTemplateInput(
                    template_file=File(url=file_url) if file_url else None,
                    template_name=template_name
                )
            elif node_name == 'list_templates':
                # 列出模板
                node_input = ListTemplatesInput()
            elif node_name == 'select_template':
                # 选择模板
                template_name = inputs.get('template_name', '')
                node_input = SelectTemplateInput(template_name=template_name)

            # 调用节点函数
            output = node_functions[node_name](node_input, config, runtime)

            # 转换为字典（Pydantic模型无法直接序列化）
            if hasattr(output, 'model_dump'):
                output_dict = output.model_dump()
            elif hasattr(output, 'dict'):
                output_dict = output.dict()
            else:
                output_dict = output

            return jsonify(output_dict)

        elif workflow_id == 2:
            # 工作流2：短剧大纲生成
            from graphs.nodes.upload_novel_node import upload_novel_node
            from graphs.nodes.list_novels_node import list_novels_node
            from graphs.nodes.load_novel_node import load_novel_node
            from graphs.nodes.load_template_node import load_template_node
            from graphs.nodes.generate_outline_node import generate_outline_node

            node_functions = {
                'upload_novel': upload_novel_node,
                'list_novels': list_novels_node,
                'load_novel': load_novel_node,
                'load_template': load_template_node,
                'generate_outline': generate_outline_node
            }

            if node_name not in node_functions:
                return jsonify({'error': f'无效的节点名称: {node_name}'}), 400

            # 创建Context和Config
            from langgraph.runtime import Runtime
            from coze_coding_utils.runtime_ctx.context import Context
            from langchain_core.runnables import RunnableConfig
            from utils.file.file import File
            from graphs.state import (
                UploadNovelInput,
                ListNovelsInput,
                LoadNovelInput,
                LoadTemplateInput,
                GenerateOutlineInput
            )

            ctx = Context(
                run_id="local_run",
                space_id="local_space",
                project_id="local_project"
            )
            runtime = Runtime(context=ctx)
            config = RunnableConfig()

            # 根据node_name创建对应的输入模型
            node_input = None
            if node_name == 'upload_novel':
                # 上传小说
                file_url = inputs.get('file', '')
                # 优先使用original_filename（如果有新上传的文件），其次使用novel_name（用户指定的）
                original_filename = inputs.get('original_filename', '')
                if original_filename and file_url:
                    novel_name = original_filename
                else:
                    novel_name = inputs.get('novel_name', '')
                node_input = UploadNovelInput(
                    novel_file=File(url=file_url) if file_url else None,
                    novel_name=novel_name
                )
            elif node_name == 'list_novels':
                # 列出小说
                node_input = ListNovelsInput()
            elif node_name == 'load_novel':
                # 加载小说
                novel_name = inputs.get('novel_name', '')
                node_input = LoadNovelInput(novel_name=novel_name)
            elif node_name == 'load_template':
                # 加载提示词模板
                node_input = LoadTemplateInput()
            elif node_name == 'generate_outline':
                # 生成大纲
                node_input = GenerateOutlineInput()

            output = node_functions[node_name](node_input, config, runtime)

            # 转换为字典（Pydantic模型无法直接序列化）
            if hasattr(output, 'model_dump'):
                output_dict = output.model_dump()
            elif hasattr(output, 'dict'):
                output_dict = output.dict()
            else:
                output_dict = output

            return jsonify(output_dict)

        elif workflow_id == 3:
            # 工作流3：完整文件包生成
            from graphs.nodes.load_outline_node import load_outline_node
            from graphs.nodes.generate_scripts_node import generate_scripts_node
            from graphs.nodes.load_template_node import load_template_node
            from graphs.nodes.list_outlines_node import list_outlines_node
            from graphs.nodes.generate_art_documentation_node import generate_art_documentation_node
            from graphs.state import (
                LoadOutlineInput,
                GenerateScriptsInput,
                LoadTemplateInput,
                ListOutlinesInput,
                GenerateArtDocumentationInput
            )

            node_functions = {
                'load_template': load_template_node,
                'list_outlines': list_outlines_node,
                'load_outline': load_outline_node,
                'generate_scripts': generate_scripts_node,
                'generate_art_documentation': generate_art_documentation_node
            }

            if node_name not in node_functions:
                return jsonify({'error': f'无效的节点名称: {node_name}'}), 400

            # 创建Context和Config
            from langgraph.runtime import Runtime
            from coze_coding_utils.runtime_ctx.context import Context
            from langchain_core.runnables import RunnableConfig
            from utils.file.file import File

            ctx = Context(
                run_id="local_run",
                space_id="local_space",
                project_id="local_project"
            )
            runtime = Runtime(context=ctx)
            config = RunnableConfig()

            # 根据node_name创建对应的输入模型
            node_input = None
            if node_name == 'load_template':
                # 加载提示词模板
                node_input = LoadTemplateInput()
            elif node_name == 'list_outlines':
                # 列出大纲
                node_input = ListOutlinesInput()
            elif node_name == 'load_outline':
                # 加载大纲文件
                outline_url = inputs.get('outline_url', '')
                outline_name = inputs.get('outline_name', '')
                if outline_name:
                    # 如果有outline_name参数，先找到对应的outline文件
                    from utils.storage_adapter import StorageAdapter
                    storage = StorageAdapter()
                    result = storage.list_files(prefix="")
                    outline_key = None
                    for key in result.get("keys", []):
                        if "outline" in key.lower():
                            # 获取文件元数据
                            metadata = storage.get_file_metadata(key)
                            if metadata.get("original_name") == outline_name:
                                outline_key = key
                                break
                    if outline_key:
                        outline_url = storage.generate_presigned_url(key=outline_key, expire_time=3600)
                    else:
                        return jsonify({'error': f'未找到大纲：{outline_name}'}), 400
                if not outline_url:
                    return jsonify({'error': '请先选择大纲文件'}), 400
                outline_file = File(url=outline_url)
                node_input = LoadOutlineInput(outline_file=outline_file)
            elif node_name == 'generate_scripts':
                # 生成脚本
                start_episode = int(inputs.get('start_episode', 1))
                end_episode = int(inputs.get('end_episode', 3))
                series_name = inputs.get('series_name', '动画短剧')
                outline_content = inputs.get('outline_content', '')
                template_content = inputs.get('template_content', '')
                node_input = GenerateScriptsInput(
                    start_episode=start_episode,
                    end_episode=end_episode,
                    series_name=series_name,
                    outline_content=outline_content,
                    template_content=template_content
                )
            elif node_name == 'generate_art_documentation':
                # 生成美术设定文档
                start_episode = int(inputs.get('start_episode', 1))
                end_episode = int(inputs.get('end_episode', 10))
                series_name = inputs.get('series_name', '动画短剧')
                node_input = GenerateArtDocumentationInput(
                    start_episode=start_episode,
                    end_episode=end_episode,
                    series_name=series_name
                )

            output = node_functions[node_name](node_input, config, runtime)

            # 转换为字典（Pydantic模型无法直接序列化）
            if hasattr(output, 'model_dump'):
                output_dict = output.model_dump()
            elif hasattr(output, 'dict'):
                output_dict = output.dict()
            else:
                output_dict = output

            return jsonify(output_dict)
    
    except Exception as e:
        error_msg = f'执行失败：{str(e)}\n\n{traceback.format_exc()}'
        print(f"\n[{datetime.now()}] 执行失败")
        print(error_msg)
        return jsonify({'error': error_msg}), 500


# ========== LLM配置相关路由 ==========

@app.route('/llm/providers', methods=['GET'])
def get_llm_providers():
    """获取所有LLM提供商列表"""
    try:
        llm_provider = get_llm_provider()
        providers = llm_provider.get_providers_list()
        enabled_provider = llm_provider.get_current_provider()

        return jsonify({
            'success': True,
            'providers': providers,
            'enabled_provider': enabled_provider
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取提供商列表失败：{str(e)}'
        }), 500


@app.route('/llm/provider/<provider_id>', methods=['GET'])
def get_llm_provider_config(provider_id):
    """获取指定提供商的配置"""
    try:
        llm_provider = get_llm_provider()
        provider_config = llm_provider.get_provider_config(provider_id)

        if provider_config is None:
            return jsonify({
                'success': False,
                'message': f'提供商 {provider_id} 不存在'
            }), 404

        return jsonify({
            'success': True,
            'provider': provider_config
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取提供商配置失败：{str(e)}'
        }), 500


@app.route('/llm/provider/<provider_id>', methods=['POST'])
def update_llm_provider_config(provider_id):
    """更新提供商配置"""
    try:
        data = request.get_json()

        # 更新配置
        llm_provider = get_llm_provider()
        success = llm_provider.update_provider_config(provider_id, {
            'api_key': data.get('api_key', ''),
            'endpoint': data.get('endpoint', ''),
            'model': data.get('model', ''),
            'temperature': data.get('temperature', 0.7),
            'max_tokens': data.get('max_tokens', 4096)
        })

        if not success:
            return jsonify({
                'success': False,
                'message': f'提供商 {provider_id} 不存在'
            }), 404

        return jsonify({
            'success': True,
            'message': '配置更新成功'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'更新配置失败：{str(e)}'
        }), 500


@app.route('/llm/enable/<provider_id>', methods=['POST'])
def enable_llm_provider(provider_id):
    """启用指定的提供商"""
    try:
        llm_provider = get_llm_provider()
        success = llm_provider.enable_provider(provider_id)

        if not success:
            return jsonify({
                'success': False,
                'message': f'提供商 {provider_id} 不存在'
            }), 404

        return jsonify({
            'success': True,
            'message': f'已启用提供商 {provider_id}'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'启用提供商失败：{str(e)}'
        }), 500


@app.route('/llm/test/<provider_id>', methods=['POST'])
def test_llm_provider(provider_id):
    """测试LLM提供商连接"""
    try:
        # 获取测试参数
        data = request.get_json()

        if not data:
            return jsonify({
                'success': False,
                'message': '请提供测试参数'
            }), 400

        llm_provider = get_llm_provider()

        # 临时更新配置（包括所有参数）
        llm_provider.update_provider_config(provider_id, {
            'api_key': data.get('api_key', ''),
            'endpoint': data.get('endpoint', ''),
            'model': data.get('model', ''),
            'temperature': data.get('temperature', 0.7),
            'max_tokens': data.get('max_tokens', 4096)
        })

        # 测试连接
        test_result = llm_provider.test_connection(provider_id)

        return jsonify(test_result)
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'测试连接失败：{str(e)}'
        }), 500

# ========== LLM配置相关路由结束 ==========


def main():
    """主函数"""
    print("\n" + "="*80)
    print("🚀 启动本地HTTP服务器")
    print("="*80)
    print("\n📖 使用说明：")
    print("1. 服务器地址：http://localhost:5000")
    print("2. 在浏览器中打开上述地址")
    print("3. 选择工作流并执行操作")
    print("4. 查看执行结果")
    print("\n⚠️  注意：")
    print("- 确保已安装所有依赖：pip install -r requirements.txt")
    print("- 确保已配置环境变量（API密钥等）")
    print("- 按Ctrl+C停止服务器")
    print("="*80 + "\n")
    
    # 启动服务器
    app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    main()
