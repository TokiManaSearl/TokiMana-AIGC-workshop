#!/bin/bash

echo "================================================================================"
echo "🚀 启动本地HTTP服务器"
echo "================================================================================"
echo ""
echo "📖 使用说明："
echo "1. 服务器地址：http://localhost:5000"
echo "2. 在浏览器中打开上述地址"
echo "3. 选择工作流并执行操作"
echo "4. 查看执行结果"
echo ""
echo "⚠️  注意："
echo "- 确保已安装所有依赖：pip3 install -r requirements_local.txt"
echo "- 确保已配置环境变量（API密钥等）"
echo "- 按Ctrl+C停止服务器"
echo "================================================================================"
echo ""

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 进入项目目录
cd "$PROJECT_DIR"

# 检查Python3是否安装
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3未安装，请先安装Python 3.12"
    echo "安装命令（Ubuntu/Debian）："
    echo "  sudo apt update && sudo apt install python3.12 python3-pip"
    echo ""
    echo "安装命令（Mac）："
    echo "  brew install python@3.12"
    echo ""
    echo "下载地址：https://www.python.org/downloads/"
    exit 1
fi

# 检查依赖是否安装
if ! python3 -c "import flask" &> /dev/null; then
    echo "❌ 未安装依赖，正在安装..."
    echo ""
    pip3 install -r requirements_local.txt
    if [ $? -ne 0 ]; then
        echo ""
        echo "❌ 依赖安装失败，请检查网络连接"
        echo "或尝试使用国内镜像："
        echo "  pip3 install -r requirements_local.txt -i https://pypi.tuna.tsinghua.edu.cn/simple"
        exit 1
    fi
    echo ""
    echo "✅ 依赖安装成功！"
    echo ""
fi

# 启动服务器
echo "✅ 正在启动服务器..."
echo ""
echo "🌐 服务器地址：http://localhost:5000"
echo ""
echo "⏳ 正在启动，请稍候..."
echo ""

# 启动服务器并自动打开浏览器
python3 "$SCRIPT_DIR/local_server.py" &
SERVER_PID=$!

# 等待2秒让服务器启动
sleep 2

# 自动打开浏览器
echo "🌐 正在打开浏览器..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac系统
    open http://localhost:5000
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux系统
    xdg-open http://localhost:5000 2>/dev/null || echo "请手动在浏览器中打开 http://localhost:5000"
else
    echo "请手动在浏览器中打开 http://localhost:5000"
fi

echo ""
echo "✅ 服务器已启动，浏览器已打开！"
echo ""
echo "💡 提示："
echo "- 工作流系统已在浏览器中打开"
echo "- 关闭浏览器不会停止服务器"
echo "- 按 Ctrl+C 可停止服务器"
echo ""

# 等待服务器进程
wait $SERVER_PID
