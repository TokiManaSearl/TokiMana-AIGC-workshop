"""
测试本地化存储
验证本地存储是否正常工作
"""
import os
import sys

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from utils.local_storage import get_local_storage

def test_local_storage():
    """测试本地存储功能"""
    print("="*80)
    print("测试本地化存储")
    print("="*80)
    print()

    # 获取本地存储实例
    storage = get_local_storage()

    print(f"存储根目录: {storage.base_path}")
    print(f"存储根目录是否存在: {storage.base_path.exists()}")
    print()

    # 测试1：上传文件
    print("测试1：上传文件")
    test_content = b"Hello, World! This is a test file."
    test_file_name = "test.txt"
    try:
        file_key = storage.upload_file(
            file_content=test_content,
            file_name=test_file_name,
            content_type="text/plain",
            original_name="测试文件.txt"
        )
        print(f"✅ 文件上传成功: {file_key}")
    except Exception as e:
        print(f"❌ 文件上传失败: {e}")
        return
    print()

    # 测试2：读取文件
    print("测试2：读取文件")
    try:
        content = storage.read_file(test_file_name)
        print(f"✅ 文件读取成功: {content}")
    except Exception as e:
        print(f"❌ 文件读取失败: {e}")
        return
    print()

    # 测试3：检查文件是否存在
    print("测试3：检查文件是否存在")
    try:
        exists = storage.file_exists(test_file_name)
        print(f"✅ 文件存在检查成功: {exists}")
    except Exception as e:
        print(f"❌ 文件存在检查失败: {e}")
        return
    print()

    # 测试4：列出文件
    print("测试4：列出文件")
    try:
        result = storage.list_files()
        print(f"✅ 文件列表获取成功: 找到 {len(result.get('keys', []))} 个文件")
        for key in result.get('keys', []):
            print(f"   - {key}")
    except Exception as e:
        print(f"❌ 文件列表获取失败: {e}")
        return
    print()

    # 测试5：生成文件路径
    print("测试5：生成文件路径")
    try:
        file_path = storage.generate_presigned_url(test_file_name)
        print(f"✅ 文件路径生成成功: {file_path}")
        print(f"   路径是否存在: {os.path.exists(file_path)}")
    except Exception as e:
        print(f"❌ 文件路径生成失败: {e}")
        return
    print()

    # 测试6：获取文件元数据
    print("测试6：获取文件元数据")
    try:
        metadata = storage.get_file_metadata(test_file_name)
        print(f"✅ 文件元数据获取成功: {metadata}")
    except Exception as e:
        print(f"❌ 文件元数据获取失败: {e}")
        return
    print()

    # 测试7：删除文件
    print("测试7：删除文件")
    try:
        success = storage.delete_file(test_file_name)
        print(f"✅ 文件删除成功: {success}")
    except Exception as e:
        print(f"❌ 文件删除失败: {e}")
        return
    print()

    print("="*80)
    print("✅ 所有测试通过！")
    print("="*80)

if __name__ == "__main__":
    test_local_storage()
