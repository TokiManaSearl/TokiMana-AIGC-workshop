"""
图形化工作流1：提示词模板管理（鼠标操作版）
"""
from typing import Optional
from pydantic import BaseModel, Field
from langgraph.graph import StateGraph, END

# 导入节点
from graphs.nodes.upload_template_node import upload_template_node
from graphs.nodes.list_templates_node import list_templates_node
from graphs.nodes.delete_template_node import delete_template_node
from graphs.nodes.select_template_node import select_template_node
from graphs.nodes.edit_template_node import edit_template_node
from graphs.nodes.save_template_node import save_template_node


class Workflow1Input(BaseModel):
    """
    工作流1输入 - 图形化界面版本
    用户通过点击不同按钮触发不同节点
    """
    # 上传节点参数
    upload_template_file: Optional[dict] = Field(default=None, description="点击上传按钮时提供文件")
    
    # 删除节点参数
    delete_template_name: str = Field(default="", description="点击删除按钮时提供模板名称")
    
    # 选择节点参数
    select_template_name: str = Field(default="", description="从下拉框选择模板名称")
    
    # 编辑节点参数
    edit_template_name: str = Field(default="", description="正在编辑的模板名称")
    edit_content: str = Field(default="", description="编辑框中的内容")
    
    # 保存节点参数
    save_template_name: str = Field(default="", description="点击保存按钮时的模板名称")
    save_content: str = Field(default="", description="点击保存时的编辑内容")


class Workflow1Output(BaseModel):
    """工作流1输出"""
    templates: list = Field(default=[], description="模板列表")
    selected_content: str = Field(default="", description="选中的模板内容")
    saved_url: str = Field(default="", description="保存后的URL")
    message: str = Field(default="", description="操作结果消息")


class Workflow1GlobalState(BaseModel):
    """工作流1全局状态"""
    # 存储所有模板
    templates: list = Field(default=[], description="已上传的提示词模板列表")
    
    # 当前选中的模板
    selected_template_name: str = Field(default="", description="当前选中的模板名称")
    selected_template_content: str = Field(default="", description="当前选中的模板内容")
    
    # 编辑中的内容
    editing_template_name: str = Field(default="", description="正在编辑的模板名称")
    editing_content: str = Field(default="", description="编辑中的内容")
    
    # 保存信息
    saved_url: str = Field(default="", description="最近保存的URL")
    
    # 消息
    message: str = Field(default="", description="操作结果消息")
    
    # 输入字段
    upload_template_file: Optional[dict] = Field(default=None)
    delete_template_name: str = Field(default="")
    select_template_name: str = Field(default="")
    edit_template_name: str = Field(default="")
    edit_content: str = Field(default="")
    save_template_name: str = Field(default="")
    save_content: str = Field(default="")


# 创建状态图
builder = StateGraph(Workflow1GlobalState, input_schema=Workflow1Input, output_schema=Workflow1Output)

# 添加所有节点（每个节点对应一个UI操作）
builder.add_node("upload_template", upload_template_node, metadata={
    "type": "task",
    "ui": {
        "label": "上传模板",
        "widget": "file_upload",
        "description": "点击上传提示词模板.md文件"
    }
})

builder.add_node("list_templates", list_templates_node, metadata={
    "type": "task",
    "ui": {
        "label": "刷新列表",
        "widget": "button",
        "description": "查看所有已上传的模板"
    }
})

builder.add_node("delete_template", delete_template_node, metadata={
    "type": "task",
    "ui": {
        "label": "删除模板",
        "widget": "button",
        "description": "删除选中的模板",
        "input_field": "delete_template_name"
    }
})

builder.add_node("select_template", select_template_node, metadata={
    "type": "task",
    "ui": {
        "label": "选择模板",
        "widget": "dropdown",
        "description": "从下拉框选择一个模板",
        "input_field": "select_template_name",
        "data_source": "templates"
    }
})

builder.add_node("edit_template", edit_template_node, metadata={
    "type": "task",
    "ui": {
        "label": "编辑模板",
        "widget": "textarea",
        "description": "在线编辑模板内容",
        "input_fields": ["edit_template_name", "edit_content"]
    }
})

builder.add_node("save_template", save_template_node, metadata={
    "type": "task",
    "ui": {
        "label": "保存模板",
        "widget": "button",
        "description": "保存编辑后的模板",
        "input_fields": ["save_template_name", "save_content"]
    }
})

# 设置默认入口点
builder.set_entry_point("list_templates")

# 所有节点执行完后结束
builder.add_edge("upload_template", END)
builder.add_edge("list_templates", END)
builder.add_edge("delete_template", END)
builder.add_edge("select_template", END)
builder.add_edge("edit_template", END)
builder.add_edge("save_template", END)

# 编译图
workflow1_main_graph = builder.compile()
