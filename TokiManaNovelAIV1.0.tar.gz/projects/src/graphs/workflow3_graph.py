"""
图形化工作流3：生成改编文件包（鼠标操作版）
"""
from typing import Optional
from pydantic import BaseModel, Field
from langgraph.graph import StateGraph, END

# 导入节点
from graphs.nodes.upload_files_node import upload_files_node
from graphs.nodes.list_files_node import list_files_node
from graphs.nodes.delete_file_node import delete_file_node
from graphs.nodes.generate_scripts_node import generate_scripts_node
from graphs.nodes.fill_episode_excel_node import fill_episode_excel_node
from graphs.nodes.fill_art_excel_node import fill_art_excel_node
from graphs.nodes.create_package_node import create_package_node


class Workflow3Input(BaseModel):
    """
    工作流3输入 - 图形化界面版本
    """
    # 上传节点参数
    upload_outline_file: Optional[dict] = Field(default=None, description="短剧大纲文件")
    upload_episode_excel: Optional[dict] = Field(default=None, description="剧集Excel模板")
    upload_art_excel: Optional[dict] = Field(default=None, description="美术Excel模板")
    
    # 删除节点参数
    delete_file_name: str = Field(default="", description="要删除的文件名称")
    
    # 选择模型节点参数
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="从下拉框选择LLM模型")


class Workflow3Output(BaseModel):
    """工作流3输出"""
    files: list = Field(default=[], description="文件列表")
    package_url: str = Field(default="", description="压缩包URL")
    message: str = Field(default="", description="操作结果消息")


class Workflow3GlobalState(BaseModel):
    """工作流3全局状态"""
    # 文件存储
    files: list = Field(default=[], description="已上传的文件列表")
    
    # LLM模型选择
    llm_model: str = Field(default="doubao-seed-1-8-251228", description="选择的LLM模型")
    
    # 生成的内容
    outline_content: str = Field(default="", description="短剧大纲内容")
    scripts: dict = Field(default={}, description="生成的脚本")
    character_settings: list = Field(default=[], description="角色美术设定")
    scene_settings: list = Field(default=[], description="场景美术设定")
    prop_settings: list = Field(default=[], description="道具美术设定")
    
    # 填写好的Excel
    filled_episode_excel_url: str = Field(default="", description="填写后的剧集Excel URL")
    filled_art_excel_url: str = Field(default="", description="填写后的美术Excel URL")
    
    # 最终压缩包
    package_url: str = Field(default="", description="最终压缩包URL")
    
    # 消息
    message: str = Field(default="", description="操作结果消息")
    
    # 输入字段
    upload_outline_file: Optional[dict] = Field(default=None)
    upload_episode_excel: Optional[dict] = Field(default=None)
    upload_art_excel: Optional[dict] = Field(default=None)
    delete_file_name: str = Field(default="")


# 创建状态图
builder = StateGraph(Workflow3GlobalState, input_schema=Workflow3Input, output_schema=Workflow3Output)

# 添加所有节点
builder.add_node("upload_files", upload_files_node, metadata={
    "type": "task",
    "ui": {
        "label": "上传文件",
        "widget": "file_upload_multi",
        "description": "上传短剧大纲和两个Excel模板",
        "input_fields": ["upload_outline_file", "upload_episode_excel", "upload_art_excel"]
    }
})

builder.add_node("list_files", list_files_node, metadata={
    "type": "task",
    "ui": {
        "label": "刷新列表",
        "widget": "button",
        "description": "查看所有已上传的文件"
    }
})

builder.add_node("delete_file", delete_file_node, metadata={
    "type": "task",
    "ui": {
        "label": "删除文件",
        "widget": "button",
        "description": "删除选中的文件",
        "input_field": "delete_file_name"
    }
})

builder.add_node("generate_scripts", generate_scripts_node, metadata={
    "type": "agent",
    "ui": {
        "label": "生成脚本和美术设定",
        "widget": "button",
        "description": "根据大纲生成每集脚本和美术设定"
    },
    "llm_cfg": "config/generate_scripts_cfg.json"
})

builder.add_node("create_package", create_package_node, metadata={
    "type": "task",
    "ui": {
        "label": "创建压缩包",
        "widget": "button",
        "description": "将所有文件打包成zip压缩包"
    }
})

# 设置默认入口点
builder.set_entry_point("list_files")

# 所有节点执行完后结束
builder.add_edge("upload_files", END)
builder.add_edge("list_files", END)
builder.add_edge("delete_file", END)
builder.add_edge("generate_scripts", END)
builder.add_edge("create_package", END)

# 编译图
workflow3_main_graph = builder.compile()
