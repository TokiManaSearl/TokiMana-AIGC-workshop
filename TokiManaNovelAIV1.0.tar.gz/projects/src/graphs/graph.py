"""Main graph file for GUI-based workflow execution"""
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from langgraph.graph import StateGraph, END
from utils.file.file import File

# Import state module
import graphs.state as state

# Helper function to get types from state module
def get_type(name):
    return getattr(state, name, None)

# Get all needed types
Workflow1GlobalState = get_type('Workflow1GlobalState')
Workflow2GlobalState = get_type('Workflow2GlobalState')
Workflow3GlobalState = get_type('Workflow3GlobalState')
UploadTemplateInput = get_type('UploadTemplateInput')
UploadTemplateOutput = get_type('UploadTemplateOutput')
ListTemplatesInput = get_type('ListTemplatesInput')
ListTemplatesOutput = get_type('ListTemplatesOutput')
DeleteTemplateInput = get_type('DeleteTemplateInput')
DeleteTemplateOutput = get_type('DeleteTemplateOutput')
SelectTemplateInput = get_type('SelectTemplateInput')
SelectTemplateOutput = get_type('SelectTemplateOutput')
EditTemplateInput = get_type('EditTemplateInput')
EditTemplateOutput = get_type('EditTemplateOutput')
SaveTemplateInput = get_type('SaveTemplateInput')
SaveTemplateOutput = get_type('SaveTemplateOutput')
UploadNovelInput = get_type('UploadNovelInput')
UploadNovelOutput = get_type('UploadNovelOutput')
ListNovelsInput = get_type('ListNovelsInput')
ListNovelsOutput = get_type('ListNovelsOutput')
DeleteNovelInput = get_type('DeleteNovelInput')
DeleteNovelOutput = get_type('DeleteNovelOutput')
SelectModelInput = get_type('SelectModelInput')
SelectModelOutput = get_type('SelectModelOutput')
GenerateOutlineInput = get_type('GenerateOutlineInput')
GenerateOutlineOutput = get_type('GenerateOutlineOutput')
LoadOutlineInput = get_type('LoadOutlineInput')
LoadOutlineOutput = get_type('LoadOutlineOutput')
AnalyzeOutlineInput = get_type('AnalyzeOutlineInput')
AnalyzeOutlineOutput = get_type('AnalyzeOutlineOutput')
UploadFilesInput = get_type('UploadFilesInput')
UploadFilesOutput = get_type('UploadFilesOutput')
ListFilesInput = get_type('ListFilesInput')
ListFilesOutput = get_type('ListFilesOutput')
DeleteFileInput = get_type('DeleteFileInput')
DeleteFileOutput = get_type('DeleteFileOutput')
ClearAllFilesInput = get_type('ClearAllFilesInput')
ClearAllFilesOutput = get_type('ClearAllFilesOutput')
GenerateScriptsInput = get_type('GenerateScriptsInput')
GenerateScriptsOutput = get_type('GenerateScriptsOutput')
Generate60EpisodesInput = get_type('Generate60EpisodesInput')
Generate60EpisodesOutput = get_type('Generate60EpisodesOutput')
GenerateEpisodesInput = get_type('GenerateEpisodesInput')
GenerateEpisodesOutput = get_type('GenerateEpisodesOutput')
GenerateArtSettingsInput = get_type('GenerateArtSettingsInput')
GenerateArtSettingsOutput = get_type('GenerateArtSettingsOutput')
FillEpisodeExcelInput = get_type('FillEpisodeExcelInput')
FillEpisodeExcelOutput = get_type('FillEpisodeExcelOutput')
FillArtExcelInput = get_type('FillArtExcelInput')
FillArtExcelOutput = get_type('FillArtExcelOutput')
CreatePackageInput = get_type('CreatePackageInput')
CreatePackageOutput = get_type('CreatePackageOutput')
CallWorkflow1Input = get_type('CallWorkflow1Input')
CallWorkflow1Output = get_type('CallWorkflow1Output')
CallWorkflow2Input = get_type('CallWorkflow2Input')
CallWorkflow2Output = get_type('CallWorkflow2Output')
CallWorkflow3Input = get_type('CallWorkflow3Input')
CallWorkflow3Output = get_type('CallWorkflow3Output')


class GraphInput(BaseModel):
    """主图输入 - 图形化操作界面参数"""
    # 工作流选择
    workflow_id: int = Field(
        ...,
        description="选择工作流：1-提示词模板管理，2-小说改编大纲生成，3-生成改编文件包"
    )
    # 节点操作选择
    node_name: str = Field(
        ...,
        description="点击要执行的操作按钮："
               "【工作流1】upload_template-上传提示词、list_templates-列出提示词、"
               "delete_template-删除提示词、select_template-选择提示词、"
               "edit_template-编辑提示词、save_template-保存提示词；"
               "【工作流2】upload_novel-上传小说、list_novels-列出小说、"
               "delete_novel-删除小说、load_template-加载提示词、generate_outline-生成大纲、save_outline-保存大纲；"
               "【工作流3】upload_files-上传文件、list_files-列出文件、"
               "delete_file-删除文件、clear_all_files-清理所有文件、"
               "load_outline-加载大纲、analyze_outline-分析大纲、generate_scripts-生成脚本、"
               "generate_60_episodes-生成60集完整脚本、"
               "generate_episodes-生成指定范围集数脚本（如1-10集）、"
               "generate_art_settings-生成美术设定、fill_episode_excel-填剧集Excel、"
               "fill_art_excel-填美术Excel、create_package-创建文件包"
    )
    # 工作流1参数（提示词模板管理）
    template_file: Optional[dict] = Field(
        default=None,
        description="【上传提示词时使用】上传的提示词模板.md文件，点击'上传提示词'按钮后在此处选择文件"
    )
    template_name: str = Field(
        default="",
        description="【选择/删除/保存提示词时使用】提示词模板的名称，例如：赛博朋克主题改编模板"
    )
    new_content: str = Field(
        default="",
        description="【保存提示词时使用】编辑后的提示词新内容，点击'编辑提示词'修改内容后，在此处填入要保存的内容"
    )
    # 工作流2参数（小说改编大纲生成）
    novel_file: Optional[dict] = Field(
        default=None,
        description="【上传小说时使用】上传的小说.txt文件，点击'上传小说'按钮后在此处选择文件"
    )
    novel_name: str = Field(
        default="",
        description="【删除小说时使用】小说的名称，例如：长篇小说.txt"
    )
    llm_model: str = Field(
        default="",
        description="【选择模型时使用】选择的大语言模型名称，默认使用豆包大模型"
    )
    template_content: str = Field(
        default="",
        description="【加载提示词时使用】加载的提示词模板内容，可以在此查看或复制"
    )
    # 工作流3参数（生成改编文件包）
    files: list = Field(
        default=[],
        description="【上传文件时使用】上传的文件列表，包括短剧大纲.md、剧集导入表模板.xlsx、美术资产导入表模板.xlsx"
    )
    file_name: str = Field(
        default="",
        description="【删除文件时使用】要删除的文件名称"
    )
    # generate_episodes 节点专用参数
    start_episode: int = Field(
        default=1,
        ge=1,
        description="【生成指定范围集数时使用】起始集数（从1开始）"
    )
    end_episode: int = Field(
        default=10,
        ge=1,
        description="【生成指定范围集数时使用】结束集数（最多30集）"
    )
    series_name: str = Field(
        default="动画短剧",
        description="【生成指定范围集数时使用】短剧名称（用于文件命名）"
    )
    # clear_all_files 节点参数
    delete_scripts: bool = Field(
        default=False,
        description="【清理文件时使用】是否删除所有脚本文件"
    )
    delete_outlines: bool = Field(
        default=False,
        description="【清理文件时使用】是否删除所有大纲文件"
    )
    delete_packages: bool = Field(
        default=False,
        description="【清理文件时使用】是否删除所有压缩包"
    )
    delete_all: bool = Field(
        default=False,
        description="【清理文件时使用】是否删除所有文件（包括模板、小说等）"
    )


class GraphOutput(BaseModel):
    """主图输出 - 操作结果"""
    workflow_id: int = Field(..., description="执行的工作流编号（1/2/3）")
    action: str = Field(..., description="执行的操作名称，如：upload_template、list_templates等")
    templates: list = Field(
        default=[],
        description="【工作流1】提示词模板列表，包含已上传的所有模板名称和URL"
    )
    novels: list = Field(
        default=[],
        description="【工作流2】小说列表，包含已上传的所有小说名称和URL"
    )
    files: list = Field(
        default=[],
        description="【工作流3】文件列表，包含已上传的所有文件名称和URL"
    )
    selected_template_content: str = Field(
        default="",
        description="【工作流1】选中的提示词模板内容，可以在此查看或复制"
    )
    template_content: str = Field(
        default="",
        description="【工作流2】加载的提示词模板内容，可以在此查看或复制"
    )
    outline_content: str = Field(
        default="",
        description="【工作流2】生成的短剧大纲内容，可以直接查看"
    )
    outline_url: str = Field(
        default="",
        description="【工作流2】生成的短剧大纲文件的下载链接（.md格式）"
    )
    scripts: dict = Field(
        default={},
        description="【工作流3】生成的各集脚本内容，key为episode_1、episode_2等，value为对应集的脚本文本"
    )
    package_url: str = Field(
        default="",
        description="【工作流3】最终生成的完整文件包下载链接（.zip格式），包含所有脚本、美术设定、Excel表格等"
    )
    message: str = Field(
        ...,
        description="操作结果提示消息，成功时显示✅，失败时显示❌和错误信息"
    )


def call_workflow1(
    state: CallWorkflow1Input,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CallWorkflow1Output:
    """Call workflow 1: Template management"""
    ctx = runtime.context
    node_name = state.node_name
    result_message = ""
    temp_state = Workflow1GlobalState()

    if node_name == "upload_template":
        from graphs.nodes.upload_template_node import upload_template_node
        wf1_input = UploadTemplateInput(template_file=state.template_file, template_name=state.template_name)
        wf1_output = upload_template_node(wf1_input, config, runtime)
        temp_state.uploaded_templates = wf1_output.templates
        result_message = wf1_output.message

    elif node_name == "list_templates":
        from graphs.nodes.list_templates_node import list_templates_node
        wf1_input = ListTemplatesInput()
        wf1_output = list_templates_node(wf1_input, config, runtime)
        temp_state.uploaded_templates = wf1_output.templates
        result_message = wf1_output.message

    elif node_name == "delete_template":
        from graphs.nodes.delete_template_node import delete_template_node
        wf1_input = DeleteTemplateInput(template_name=state.template_name)
        wf1_output = delete_template_node(wf1_input, config, runtime)
        temp_state.uploaded_templates = wf1_output.templates
        result_message = wf1_output.message

    elif node_name == "select_template":
        from graphs.nodes.select_template_node import select_template_node
        wf1_input = SelectTemplateInput(template_name=state.template_name)
        wf1_output = select_template_node(wf1_input, config, runtime)
        temp_state.selected_template_name = wf1_output.template_name
        temp_state.selected_template_content = wf1_output.template_content
        result_message = wf1_output.message

    elif node_name == "edit_template":
        from graphs.nodes.edit_template_node import edit_template_node
        wf1_input = EditTemplateInput(template_name=state.template_name, new_content=state.new_content)
        wf1_output = edit_template_node(wf1_input, config, runtime)
        temp_state.edited_template_content = wf1_output.edited_content
        result_message = wf1_output.message

    elif node_name == "save_template":
        from graphs.nodes.save_template_node import save_template_node
        wf1_input = SaveTemplateInput(template_name=state.template_name, edited_content=state.new_content)
        wf1_output = save_template_node(wf1_input, config, runtime)
        temp_state.saved_template_url = wf1_output.saved_url
        result_message = wf1_output.message

    else:
        result_message = f"Unknown node: {node_name}"

    return CallWorkflow1Output(
        workflow_id=1,
        action=node_name,
        templates=temp_state.uploaded_templates,
        selected_content=temp_state.selected_template_content,
        saved_url=temp_state.saved_template_url,
        message=result_message
    )


def call_workflow2(
    state: CallWorkflow2Input,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CallWorkflow2Output:
    """Call workflow 2: Novel adaptation outline"""
    ctx = runtime.context
    node_name = state.node_name
    result_message = ""
    outline_url = ""
    outline_content = ""
    temp_state = Workflow2GlobalState()

    if node_name == "upload_novel":
        from graphs.nodes.upload_novel_node import upload_novel_node
        wf2_input = UploadNovelInput(novel_file=state.novel_file, novel_name=state.novel_name)
        wf2_output = upload_novel_node(wf2_input, config, runtime)
        temp_state.uploaded_novels = wf2_output.novels
        result_message = wf2_output.message

    elif node_name == "list_novels":
        from graphs.nodes.list_novels_node import list_novels_node
        wf2_input = ListNovelsInput()
        wf2_output = list_novels_node(wf2_input, config, runtime)
        temp_state.uploaded_novels = wf2_output.novels
        result_message = wf2_output.message

    elif node_name == "delete_novel":
        from graphs.nodes.delete_novel_node import delete_novel_node
        wf2_input = DeleteNovelInput(novel_name=state.novel_name)
        wf2_output = delete_novel_node(wf2_input, config, runtime)
        temp_state.uploaded_novels = wf2_output.novels
        result_message = wf2_output.message

    elif node_name == "load_template":
        from graphs.nodes.load_template_node import load_template_node
        from graphs.state import LoadTemplateInput, LoadTemplateOutput
        wf2_input = LoadTemplateInput()
        wf2_output = load_template_node(wf2_input, config, runtime)
        temp_state.template_content = wf2_output.template_content
        result_message = wf2_output.message

    elif node_name == "generate_outline":
        from graphs.nodes.generate_outline_node import generate_outline_node
        wf2_input = GenerateOutlineInput()
        wf2_output = generate_outline_node(wf2_input, config, runtime)
        outline_url = wf2_output.outline_url
        outline_content = wf2_output.outline_content
        result_message = wf2_output.message

    else:
        result_message = f"Unknown node: {node_name}"

    return CallWorkflow2Output(
        workflow_id=2,
        action=node_name,
        novels=temp_state.uploaded_novels,
        outline_content=outline_content,
        outline_url=outline_url,
        template_content=temp_state.template_content,
        message=result_message
    )


def call_workflow3(
    state: CallWorkflow3Input,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CallWorkflow3Output:
    """Call workflow 3: Generate adaptation package"""
    ctx = runtime.context
    node_name = state.node_name
    result_message = ""
    scripts = {}
    package_url = ""
    outline_content = ""
    analysis_result = ""
    character_settings = []
    scene_settings = []
    prop_settings = []
    temp_state = Workflow3GlobalState()

    if node_name == "upload_files":
        from graphs.nodes.upload_files_node import upload_files_node
        wf3_input = UploadFilesInput(files=state.files)
        wf3_output = upload_files_node(wf3_input, config, runtime)
        temp_state.uploaded_files = wf3_output.files
        result_message = wf3_output.message

    elif node_name == "list_files":
        from graphs.nodes.list_files_node import list_files_node
        wf3_input = ListFilesInput()
        wf3_output = list_files_node(wf3_input, config, runtime)
        temp_state.uploaded_files = wf3_output.files
        result_message = wf3_output.message

    elif node_name == "delete_file":
        from graphs.nodes.delete_file_node import delete_file_node
        wf3_input = DeleteFileInput(file_name=state.file_name)
        wf3_output = delete_file_node(wf3_input, config, runtime)
        temp_state.uploaded_files = wf3_output.files
        result_message = wf3_output.message

    elif node_name == "load_outline":
        from graphs.nodes.load_outline_node import load_outline_node
        wf3_input = LoadOutlineInput(outline_file=state.outline_file)
        wf3_output = load_outline_node(wf3_input, config, runtime)
        temp_state.outline_content = wf3_output.outline_content
        outline_content = wf3_output.outline_content
        result_message = wf3_output.message

    elif node_name == "analyze_outline":
        from graphs.nodes.analyze_outline_node import analyze_outline_node
        wf3_input = AnalyzeOutlineInput(
            outline_content=temp_state.outline_content,
            template_content=temp_state.template_content
        )
        wf3_output = analyze_outline_node(wf3_input, config, runtime)
        analysis_result = wf3_output.analysis_result
        result_message = wf3_output.message

    elif node_name == "generate_scripts":
        from graphs.nodes.generate_scripts_node import generate_scripts_node
        # 支持从全局状态或参数获取输入
        start_episode = state.start_episode if hasattr(state, 'start_episode') else 1
        end_episode = state.end_episode if hasattr(state, 'end_episode') else 3
        series_name = state.series_name if hasattr(state, 'series_name') else "动画短剧"
        outline_content = state.outline_content if hasattr(state, 'outline_content') else ""
        template_content = state.template_content if hasattr(state, 'template_content') else ""
        
        wf3_input = GenerateScriptsInput(
            start_episode=start_episode,
            end_episode=end_episode,
            series_name=series_name,
            outline_content=outline_content,
            template_content=template_content
        )
        wf3_output = generate_scripts_node(wf3_input, config, runtime)
        # 将生成的脚本添加到 generated_files 中
        temp_state.generated_files["scripts"] = {
            "files": [{"url": f.url, "file_type": f.file_type} for f in wf3_output.script_files],
            "content": wf3_output.scripts_content
        }
        # 添加美术设定到generated_files
        temp_state.generated_files["art_settings"] = {
            "character_settings": [{"name": "角色", "prompt": wf3_output.character_art_content}],
            "scene_settings": [{"name": "场景", "prompt": wf3_output.scene_art_content}],
            "prop_settings": [],
            "character_settings_content": wf3_output.character_art_content,
            "scene_settings_content": wf3_output.scene_art_content,
            "prop_settings_content": ""
        }
        scripts = wf3_output.scripts_content
        result_message = wf3_output.message

    elif node_name == "generate_60_episodes":
        from graphs.nodes.generate_60_episodes_node import generate_60_episodes_node
        wf3_input = Generate60EpisodesInput()
        wf3_output = generate_60_episodes_node(wf3_input, config, runtime)
        temp_state.final_package_url = wf3_output.package_url
        package_url = wf3_output.package_url
        result_message = wf3_output.message

    elif node_name == "generate_episodes":
        from graphs.nodes.generate_episodes_node import generate_episodes_node
        wf3_input = GenerateEpisodesInput(
            start_episode=state.start_episode if state.start_episode else 1,
            end_episode=state.end_episode if state.end_episode else 10,
            series_name=state.series_name if state.series_name else "动画短剧"
        )
        wf3_output = generate_episodes_node(wf3_input, config, runtime)
        temp_state.final_package_url = wf3_output.package_url
        package_url = wf3_output.package_url
        result_message = wf3_output.message

    elif node_name == "clear_all_files":
        from graphs.nodes.clear_all_files_node import clear_all_files_node
        wf3_input = ClearAllFilesInput(
            delete_scripts=state.delete_scripts if hasattr(state, 'delete_scripts') else False,
            delete_outlines=state.delete_outlines if hasattr(state, 'delete_outlines') else False,
            delete_packages=state.delete_packages if hasattr(state, 'delete_packages') else False,
            delete_all=state.delete_all if hasattr(state, 'delete_all') else False
        )
        wf3_output = clear_all_files_node(wf3_input, config, runtime)
        temp_state.uploaded_files = wf3_output.files
        result_message = wf3_output.message

    elif node_name == "generate_art_settings":
        from graphs.nodes.generate_art_settings_node import generate_art_settings_node
        wf3_input = GenerateArtSettingsInput()
        wf3_output = generate_art_settings_node(wf3_input, config, runtime)
        temp_state.generated_files["art_settings"] = {
            "character_settings": wf3_output.character_settings,
            "scene_settings": wf3_output.scene_settings,
            "prop_settings": wf3_output.prop_settings,
            "character_settings_content": wf3_output.character_settings_content,
            "scene_settings_content": wf3_output.scene_settings_content,
            "prop_settings_content": wf3_output.prop_settings_content
        }
        character_settings = wf3_output.character_settings
        scene_settings = wf3_output.scene_settings
        prop_settings = wf3_output.prop_settings
        result_message = wf3_output.message

    elif node_name == "fill_episode_excel":
        from graphs.nodes.fill_episode_excel_node import fill_episode_excel_node
        scripts_data = temp_state.generated_files.get("scripts", {})
        wf3_input = FillEpisodeExcelInput(
            script_files=[File(url=f["url"], file_type=f.get("file_type", "document")) for f in scripts_data.get("files", [])],
            scripts_content=scripts_data.get("content", {})  # 传递scripts_content
        )
        wf3_output = fill_episode_excel_node(wf3_input, config, runtime)
        temp_state.filled_excel_files["episode_excel"] = wf3_output.excel_file.url
        result_message = wf3_output.message

    elif node_name == "fill_art_excel":
        from graphs.nodes.fill_art_excel_node import fill_art_excel_node
        art_settings = temp_state.generated_files.get("art_settings", {})
        wf3_input = FillArtExcelInput(
            character_settings=art_settings.get("character_settings", []),
            scene_settings=art_settings.get("scene_settings", []),
            prop_settings=art_settings.get("prop_settings", [])
        )
        wf3_output = fill_art_excel_node(wf3_input, config, runtime)
        temp_state.filled_excel_files["art_excel"] = wf3_output.excel_file.url
        result_message = wf3_output.message

    elif node_name == "create_package":
        from graphs.nodes.create_package_node import create_package_node
        # 准备Excel文件列表
        excel_files = []
        for excel_type, excel_url in temp_state.filled_excel_files.items():
            if excel_url:
                excel_files.append(File(url=excel_url, file_type="document"))
        wf3_input = CreatePackageInput(excel_files=excel_files)
        wf3_output = create_package_node(wf3_input, config, runtime)
        package_url = wf3_output.package_file.url
        result_message = wf3_output.message

    else:
        result_message = f"Unknown node: {node_name}"

    return CallWorkflow3Output(
        workflow_id=3,
        action=node_name,
        files=temp_state.uploaded_files,
        outline_content=outline_content,
        analysis_result=analysis_result,
        scripts=scripts,
        character_settings=character_settings,
        scene_settings=scene_settings,
        prop_settings=prop_settings,
        package_url=package_url,
        message=result_message
    )


def route_by_workflow(state: GraphInput) -> str:
    """Route to different workflows based on workflow_id"""
    return f"workflow{state.workflow_id}"


# Create main graph
builder = StateGraph(GraphInput, input_schema=GraphInput, output_schema=GraphOutput)

# Add three workflow nodes
builder.add_node("workflow1", call_workflow1)
builder.add_node("workflow2", call_workflow2)
builder.add_node("workflow3", call_workflow3)

# Set conditional entry point
builder.set_conditional_entry_point(
    route_by_workflow,
    path_map={
        "workflow1": "workflow1",
        "workflow2": "workflow2",
        "workflow3": "workflow3"
    }
)

# All nodes end after execution
builder.add_edge("workflow1", END)
builder.add_edge("workflow2", END)
builder.add_edge("workflow3", END)

# Compile graph
main_graph = builder.compile()
