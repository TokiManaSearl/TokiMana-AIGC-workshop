"""上传小说节点（图形化版）"""
import os
import re
import requests
from pathlib import Path
from urllib.parse import urlparse, unquote
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import UploadNovelInput, UploadNovelOutput
from utils.file.file import File, FileOps
from utils.file_utils import get_safe_filename


def extract_filename_from_url(url: str) -> str:
    """
    从URL中提取干净的文件名，移除签名等查询参数

    Args:
        url: 文件URL（可能包含签名参数）

    Returns:
        干净的文件名
    """
    import os

    # 处理URL（包含查询参数）
    if '?' in url:
        url = url.split('?')[0]

    # 标准化路径分隔符（处理Windows路径到Linux的转换）
    # 将反斜杠替换为正斜杠，确保跨平台兼容
    normalized_url = url.replace('\\', '/')

    # 使用os.path.basename提取文件名（跨平台兼容）
    filename = os.path.basename(normalized_url)
    # URL解码（处理中文等特殊字符）
    filename = unquote(filename)
    return filename


def extract_filename_from_headers(url: str) -> str:
    """
    从HTTP响应头的Content-Disposition中提取原始文件名

    Args:
        url: 文件URL

    Returns:
        原始文件名，如果无法提取则返回空字符串
    """
    try:
        # 发送HEAD请求获取响应头（不下载文件内容）
        response = requests.head(url, timeout=30, allow_redirects=True)
        response.raise_for_status()

        # 检查Content-Disposition响应头
        content_disposition = response.headers.get('Content-Disposition', '')
        if not content_disposition:
            return ""

        # 解析Content-Disposition响应头
        # 格式1: Content-Disposition: attachment; filename="filename.ext"
        # 格式2: Content-Disposition: attachment; filename*=UTF-8''filename.ext
        match = re.search(r'filename\*?=(?:UTF-8\'\')?([^;]+)', content_disposition, re.IGNORECASE)
        if match:
            filename = match.group(1).strip('"\' ')
            return unquote(filename)

        return ""
    except Exception as e:
        # 如果获取失败，返回空字符串
        print(f"从响应头提取文件名失败: {e}")
        return ""


def upload_novel_node(
    state: UploadNovelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> UploadNovelOutput:
    """
    title: 上传小说
    desc: 点击上传按钮，上传.txt小说文件
    integrations: 对象存储
    """
    ctx = runtime.context
    
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return UploadNovelOutput(
            novels=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )
    
    try:
        # 读取文件内容
        content = FileOps.extract_text(state.novel_file)

        # 提取原始文件名（按优先级）
        original_filename = ""

        # 优先级1: 用户手动指定的novel_name
        if state.novel_name and state.novel_name.strip():
            original_filename = state.novel_name.strip()
        else:
            # 优先级2: 从HTTP响应头中提取原始文件名
            filename_from_header = extract_filename_from_headers(state.novel_file.url)
            if filename_from_header:
                original_filename = filename_from_header
            else:
                # 优先级3: 从URL路径中提取文件名（清理签名参数）
                original_filename = extract_filename_from_url(state.novel_file.url)

        # 生成安全的文件名（使用时间戳，每次上传生成不同的key）
        safe_filename, file_id = get_safe_filename(
            original_filename,
            category="novel",
            use_timestamp=True
        )
        
        # 构建存储key
        storage_key = f"novels/{safe_filename}"
        
        # 上传到存储（传递原始文件名）
        file_key = storage.upload_file(
            file_content=content.encode('utf-8'),
            file_name=storage_key,
            content_type="text/plain",
            original_name=original_filename
        )
        
        # 列出所有小说文件
        result = storage.list_files(prefix="novels/")
        novels_list = []
        for file_key in result.get("keys", []):
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")

                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1]

                # 生成访问URL
                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                novels_list.append({
                    "name": display_name,
                    "url": url,
                    "original_name": original_name
                })
            except Exception as e:
                print(f"处理文件信息失败: {e}")
        
        # 返回输出
        return UploadNovelOutput(
            novels=novels_list,
            message=f"✅ 成功上传小说：{original_filename}"
        )
        
    except Exception as e:
        return UploadNovelOutput(
            novels=[],
            message=f"❌ 上传文件到对象存储失败: {str(e)}"
        )
