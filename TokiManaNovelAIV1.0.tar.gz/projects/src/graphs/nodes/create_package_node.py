"""
创建压缩包节点
"""
import os
import tempfile
import zipfile
import requests
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from graphs.state import CreatePackageInput, CreatePackageOutput


def create_package_node(
    state: CreatePackageInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CreatePackageOutput:
    """
    title: 创建压缩包
    desc: 将所有生成的文件打包成压缩包，并上传到对象存储
    integrations: 对象存储
    """
    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return CreatePackageOutput(
            package_file=File(url="", file_type="document"),
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 创建临时目录
    temp_dir = tempfile.mkdtemp()
    package_path = os.path.join(temp_dir, "改编文件包.zip")

    try:
        # 创建压缩包
        with zipfile.ZipFile(package_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            file_count = 0

            for idx, excel_file in enumerate(state.excel_files):
                # 下载Excel文件
                try:
                    response = requests.get(excel_file.url, timeout=30)
                    response.raise_for_status()

                    # 确定文件名
                    if idx == 0:
                        file_name = "剧集导入表_已填写.xlsx"
                    else:
                        file_name = "美术资产导入表_已填写.xlsx"

                    # 添加到压缩包
                    zipf.writestr(file_name, response.content)
                    file_count += 1

                except Exception as e:
                    print(f"警告：无法下载文件 {excel_file.url}: {str(e)}")

            # 如果没有文件，添加一个说明文件
            if file_count == 0:
                zipf.writestr("说明.txt", "暂无文件，请先运行前序步骤生成文件。")

        # 读取压缩包文件内容
        with open(package_path, 'rb') as f:
            package_content = f.read()

        # 生成安全的文件名和中文名称（使用时间戳，每次生成不同文件名）
        original_name = "小说改编动画短剧_完整文件包.zip"
        safe_filename, _ = get_safe_filename(original_name, category="packages", use_timestamp=True)
        storage_key = f"packages/{safe_filename}"

        # 上传到对象存储
        file_key = storage.upload_file(
            file_content=package_content,
            file_name=storage_key,
            content_type="application/zip",
            original_name=original_name
        )

        # 获取文件路径（本地存储模式返回绝对路径）
        if hasattr(storage, 'use_s3') and not storage.use_s3 and storage.local_storage:
            # 本地存储模式
            file_path = storage.local_storage.generate_presigned_url(key=file_key, expire_time=3600)
            message = f"""✅ 成功创建文件包！

📦 压缩包信息：
   - 文件数：{file_count} 个文件
   - 文件名：{original_name}
   - 文件大小：{len(package_content) / 1024:.1f} KB

💾 文件位置：
   {file_path}

💡 使用方法：
   1. 在资源管理器中打开上述路径
   2. 找到压缩包文件：{original_name}
   3. 右键 -> 解压文件
   4. 查看生成的Excel表格

⚠️  注意：
   - 文件已保存到本地，无需下载
   - 建议备份到其他位置
"""
            package_url = file_path
        else:
            # S3存储模式
            package_url = storage.generate_presigned_url(key=file_key, expire_time=3600)
            message = f"""✅ 成功创建文件包！

📦 压缩包信息：
   - 文件数：{file_count} 个文件
   - 文件名：{original_name}
   - 文件大小：{len(package_content) / 1024:.1f} KB

📥 下载链接（有效期1小时）：
   {package_url}

💡 使用方法：
   1. 复制上面的下载链接
   2. 在浏览器中打开
   3. 浏览器会自动下载文件到你的电脑
   4. 文件会保存在：浏览器的默认下载目录（通常是下载文件夹）

⚠️  注意：
   - 下载链接有效期1小时，超时需要重新创建
   - 建议尽快下载并备份到你的电脑
"""

        return CreatePackageOutput(
            package_file=File(url=package_url, file_type="document"),
            message=message
        )

    except Exception as e:
        return CreatePackageOutput(
            package_file=File(url="", file_type="document"),
            message=f"❌ 创建压缩包失败: {str(e)}"
        )
    finally:
        # 清理临时文件
        if os.path.exists(package_path):
            os.remove(package_path)
