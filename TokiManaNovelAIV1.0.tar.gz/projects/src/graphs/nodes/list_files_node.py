"""List files node for workflow 3"""
import os
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import ListFilesInput, ListFilesOutput


def list_files_node(
    state: ListFilesInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ListFilesOutput:
    """
    title: List Files
    desc: List all uploaded files
    integrations: 对象存储
    """
    # 初始化存储适配器（自动在S3和本地存储之间切换）
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return ListFilesOutput(
            files=[],
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    files = []
    try:
        # List files from storage
        result = storage.list_files(prefix="")
        files = []
        
        for file_key in result.get("keys", []):
            # 过滤掉空key、bucket前缀（以/结尾）和空白key
            if not file_key or not file_key.strip() or file_key.endswith("/"):
                continue
                
            try:
                # 获取文件元数据（包含原始文件名）
                metadata = storage.get_file_metadata(file_key)
                original_name = metadata.get("original_name", "")

                # 如果有原始文件名，使用原始文件名作为显示名称
                display_name = original_name if original_name else file_key.split("/")[-1]

                url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                files.append({"name": display_name, "url": url})
            except Exception as e:
                print(f"处理文件信息失败: {e}")
    except Exception as e:
        return ListFilesOutput(
            files=[],
            message=f"❌ 列出文件失败: {str(e)}"
        )

    if not files:
        return ListFilesOutput(
            files=[],
            message="📭 暂无文件，请先上传"
        )

    return ListFilesOutput(
        files=files,
        message=f"✅ 共找到 {len(files)} 个文件"
    )
