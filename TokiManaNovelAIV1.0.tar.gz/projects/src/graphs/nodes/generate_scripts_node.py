"""Generate scripts node for workflow 3"""
import os
import json
import re
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from langchain_core.messages import SystemMessage, HumanMessage
from graphs.state import GenerateScriptsInput, GenerateScriptsOutput


def generate_scripts_node(
    state: GenerateScriptsInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateScriptsOutput:
    """
    title: Generate Scripts
    desc: 根据大纲和集数范围生成剧集脚本，并从脚本中提取角色和场景美术设定
    integrations: 大语言模型, 对象存储
    """
    ctx = runtime.context

    # 获取集数范围
    start_episode = state.start_episode
    end_episode = state.end_episode
    series_name = state.series_name

    # 验证集数范围
    if start_episode > end_episode:
        return GenerateScriptsOutput(
            script_files=[],
            character_art_file=File(url="", file_type="document"),
            scene_art_file=File(url="", file_type="document"),
            scripts_content={},
            character_art_content="",
            scene_art_content="",
            message=f"❌ 起始集数({start_episode})不能大于结束集数({end_episode})"
        )

    if end_episode - start_episode + 1 > 5:
        return GenerateScriptsOutput(
            script_files=[],
            character_art_file=File(url="", file_type="document"),
            scene_art_file=File(url="", file_type="document"),
            scripts_content={},
            character_art_content="",
            scene_art_content="",
            message="❌ 单次生成最多5集脚本"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return GenerateScriptsOutput(
            script_files=[],
            character_art_file=File(url="", file_type="document"),
            scene_art_file=File(url="", file_type="document"),
            scripts_content={},
            character_art_content="",
            scene_art_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # Get outline from input parameter first, then from storage
    outline_content = state.outline_content or ""
    if not outline_content:
        try:
            # Read outline from storage
            result = storage.list_files(prefix="outlines/")
            if result.get("keys"):
                outline_key = result["keys"][-1]  # Get latest outline
                if outline_key:
                    content = storage.read_file(file_key=outline_key)
                    outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
        except Exception as e:
            return GenerateScriptsOutput(
                script_files=[],
                character_art_file=File(url="", file_type="document"),
                scene_art_file=File(url="", file_type="document"),
                scripts_content={},
                character_art_content="",
                scene_art_content="",
                message=f"❌ 读取大纲失败: {str(e)}"
            )

    if not outline_content:
        return GenerateScriptsOutput(
            script_files=[],
            character_art_file=File(url="", file_type="document"),
            scene_art_file=File(url="", file_type="document"),
            scripts_content={},
            character_art_content="",
            scene_art_content="",
            message="❌ 未找到大纲，请先生成大纲"
        )

    # 读取LLM配置
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_scripts_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)

        llm_config = _cfg.get("config", {})
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        # 使用默认配置
        llm_config = {
            "model": "doubao-seed-1-8-251228",
            "temperature": 0.8,
            "top_p": 0.9,
            "max_completion_tokens": 8192,
            "thinking": "disabled"
        }
        sp = """你是一位专业的动画短剧编剧。请根据提供的大纲，生成指定集数的完整脚本内容。

每集脚本必须包含以下三个部分：

1. **简介**
   - 该集的主要角色（列出角色名称）
   - 该集的主要场景（列出场景名称和地点）
   - 该集的故事梗概

2. **脚本正文**
   - 场景描述（时间、地点、氛围）
   - 人物对话（对话内容、语气、动作）
   - 动作指导（人物动作、镜头运动）

3. **台本**
   - 配音内容
   - 音效说明
   - 背景音乐

输出格式要求：
- 每集单独生成一个完整的脚本
- 使用清晰的分段和标题
- 包含所有必要的场景和对话
- 保持风格一致性
- 每集长度约800-1200字"""
        up = """请根据以下大纲，生成第{{ episode_number }}集的完整动画短剧脚本：

大纲内容：
{{ outline_content }}

集数：第{{ episode_number }}集

请生成包含简介、脚本正文、台本三个部分的完整脚本内容。"""

    # 创建LLM客户端（使用新的LLM提供商系统，自动从前端配置获取模型）
    from utils.llm.llm_client import create_llm_client
    client = create_llm_client(ctx=runtime.context)

    # 逐集生成脚本
    scripts = {}
    script_files = {}
    
    # 用于收集所有集的角色和场景
    all_characters = {}  # {角色名称: 集数列表}
    all_scenes = {}  # {场景名称: 集数列表}

    for episode_num in range(start_episode, end_episode + 1):
        try:
            # 渲染用户提示词
            up_tpl = Template(up)
            user_prompt = up_tpl.render(
                outline_content=outline_content,
                episode_number=episode_num
            )

            messages = [
                SystemMessage(content=sp),
                HumanMessage(content=user_prompt)
            ]

            # 调用LLM（使用前端配置的模型）
            response = client.invoke(
                messages=messages,
                temperature=llm_config.get("temperature", 0.8),
                top_p=llm_config.get("top_p", 0.9),
                max_completion_tokens=llm_config.get("max_completion_tokens", 8192),
                thinking=llm_config.get("thinking", "disabled")
            )

            # 提取响应内容
            script_content = response.content
            if isinstance(script_content, list):
                script_content = " ".join(str(item) for item in script_content)

            # 提取集数标题（用于文件命名）
            episode_title = f"第{episode_num:02d}集"
            # 尝试从脚本中提取更详细的标题
            lines = script_content.split('\n')
            for line in lines[:10]:  # 只检查前10行
                line = line.strip()
                if '第' in line and '集' in line and '：' in line:
                    # 提取标题部分
                    title_part = line.split('：')[-1].strip()
                    if title_part and len(title_part) > 2:
                        episode_title = f"第{episode_num:02d}集_{title_part}"
                        break

            # 保存脚本内容
            scripts[f"episode_{episode_num}"] = script_content

            # 从脚本中提取角色和场景信息
            characters = extract_characters(script_content)
            scenes = extract_scenes(script_content)

            # 记录角色和场景（角色现在包含详细外观设定）
            for char_name, char_info in characters.items():
                if char_name not in all_characters:
                    all_characters[char_name] = {
                        'episodes': [],
                        'appearance': char_info['appearance']
                    }
                all_characters[char_name]['episodes'].append(episode_num)
                # 如果当前集的外观设定更详细，更新它
                if len(char_info['appearance']) > len(all_characters[char_name]['appearance']):
                    all_characters[char_name]['appearance'] = char_info['appearance']

            for scene in scenes:
                if scene not in all_scenes:
                    all_scenes[scene] = []
                all_scenes[scene].append(episode_num)

            # 生成安全的文件名
            original_name = f"{episode_title}.md"
            safe_filename, _ = get_safe_filename(original_name, category="scripts", use_timestamp=True)
            storage_key = f"scripts/{safe_filename}"

            # 确保内容是UTF-8编码
            if isinstance(script_content, str):
                script_bytes = script_content.encode('utf-8')
            else:
                script_bytes = str(script_content).encode('utf-8')

            # 上传到对象存储
            file_key = storage.upload_file(
                file_content=script_bytes,
                file_name=storage_key,
                content_type="text/markdown",
                original_name=original_name
            )

            # 生成访问URL
            try:
                script_url = storage.generate_presigned_url(key=file_key, expire_time=3600)
                script_files[f"episode_{episode_num}"] = script_url
            except Exception as url_error:
                script_files[f"episode_{episode_num}"] = ""
                print(f"生成脚本URL失败（第{episode_num}集）: {url_error}")

            print(f"✅ 成功生成第{episode_num}集脚本")

        except Exception as e:
            print(f"❌ 生成第{episode_num}集脚本失败: {e}")
            # 继续生成其他集，不要因为某一集失败而中断

    # 生成角色美术设定文档
    character_art_content = generate_character_art_settings(all_characters, start_episode, end_episode, series_name)
    character_art_file = upload_art_settings_file(
        storage, character_art_content, f"{series_name}_角色美术设定_{start_episode}-{end_episode}集", "character_art"
    )

    # 生成场景美术设定文档
    scene_art_content = generate_scene_art_settings(all_scenes, start_episode, end_episode, series_name)
    scene_art_file = upload_art_settings_file(
        storage, scene_art_content, f"{series_name}_场景美术设定_{start_episode}-{end_episode}集", "scene_art"
    )

    # 计算生成的集数
    episode_count = len([k for k in scripts.keys() if k.startswith('episode_')])

    return GenerateScriptsOutput(
        script_files=[File(url=url, file_type="document") for url in script_files.values()],
        character_art_file=character_art_file,
        scene_art_file=scene_art_file,
        scripts_content=scripts,
        character_art_content=character_art_content,
        scene_art_content=scene_art_content,
        message=f"✅ 成功生成 {episode_count} 集脚本（第{start_episode}集-第{end_episode}集）\n👥 角色：{len(all_characters)}个\n🏰 场景：{len(all_scenes)}个"
    )


def extract_characters(script_content: str) -> dict:
    """从脚本内容中提取角色名称和详细外观设定"""
    characters = {}
    
    # 匹配【第一部分：简介】部分
    intro_match = re.search(r'## 第一部分：简介.*?(?=##|\Z)', script_content, re.DOTALL)
    if intro_match:
        intro_text = intro_match.group(0)
        
        # 提取"登场主要角色"行
        role_match = re.search(r'登场主要角色[：:](.*)', intro_text)
        if role_match:
            role_line = role_match.group(1).strip()
            # 分割角色名（使用顿号、逗号、分号等）
            roles = re.split(r'[、,，;；\n]', role_line)
            for role_name in roles:
                role_name = role_name.strip()
                if role_name and len(role_name) >= 2:
                    # 尝试提取该角色的详细外观设定
                    appearance = extract_character_appearance(intro_text, role_name)
                    characters[role_name] = {
                        'episodes': [],
                        'appearance': appearance
                    }
    
    # 如果简介中没有提取到角色，从对话中提取
    if not characters:
        # 匹配对话中的角色名（格式：【角色名】对话内容）
        pattern1 = r'【([^】]{2,10})】'
        matches1 = re.findall(pattern1, script_content)
        # 过滤掉明显不是角色的词（场景、镜头等）
        for m in matches1:
            if m not in ['场景', '镜头', '画外', '背景', '音效', 'BGM', '音乐', '特效']:
                if m not in characters:
                    characters[m] = {'episodes': [], 'appearance': ''}
        
        # 匹配对话中的角色名（格式：角色名：对话内容）
        pattern2 = r'\n([^：\n]{2,10})[:：]'
        matches2 = re.findall(pattern2, script_content)
        for m in matches2:
            if m not in ['场景', '镜头', '画外', '背景', '音效', 'BGM', '音乐', '特效']:
                if m not in characters:
                    characters[m] = {'episodes': [], 'appearance': ''}
    
    # 过滤掉明显不是角色的词
    characters = {k: v for k, v in characters.items() if len(k) >= 2}
    
    return characters


def extract_character_appearance(intro_text: str, character_name: str) -> str:
    """从简介文本中提取角色的详细外观设定"""
    appearance = ""
    
    # 尝试多种模式匹配角色外观设定
    patterns = [
        # 模式1：角色名：外观描述
        rf'{character_name}[：:](.+?)(?=\n[^\n]{1,5}[：:]|\n\n|$)',
        # 模式2：角色名（年龄...）
        rf'{character_name}[（\(](.+?)[）\)]',
        # 模式3：- 角色：外观描述
        rf'[-\*]\s*{character_name}[：:](.+?)(?=\n[-\*]|\n\n|$)',
        # 模式4：角色名（非中文数字开头，避免匹配"18岁"）
        rf'{character_name}[(（].+?[)）]',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, intro_text, re.DOTALL)
        if match:
            appearance = match.group(1).strip()
            # 清理外观描述，移除多余的空格和换行
            appearance = re.sub(r'\s+', ' ', appearance)
            if len(appearance) > 10:  # 确保提取到的内容不是太短
                break
    
    return appearance


def extract_scenes(script_content: str) -> list:
    """从脚本内容中提取场景名称（仅场景，不包含人类或生物）"""
    scenes = set()
    
    # 匹配【第一部分：简介】中的场景
    intro_match = re.search(r'## 第一部分：简介.*?(?=##|\Z)', script_content, re.DOTALL)
    if intro_match:
        intro_text = intro_match.group(0)
        # 提取"场景"行
        scene_match = re.search(r'场景[：:](.*)', intro_text)
        if scene_match:
            scene_line = scene_match.group(1).strip()
            # 分割场景名（使用顿号、逗号、分号等）
            extracted_scenes = re.split(r'[、,，;；\n]', scene_line)
            for s in extracted_scenes:
                s = s.strip()
                if s and len(s) >= 2:
                    scenes.add(s)
    
    # 匹配【第二部分：详细剧本正文】中的场景描述
    body_match = re.search(r'## 第二部分：详细剧本正文.*?(?=##|\Z)', script_content, re.DOTALL)
    if body_match:
        body_text = body_match.group(0)
        
        # 匹配场景标题（格式：【场景1】XXX 或 【场景XXX】）
        pattern1 = r'【场景[0-9]+】(.{2,20}?)(?=\n|【)'
        matches1 = re.findall(pattern1, body_text)
        for m in matches1:
            m = m.strip()
            if m and len(m) >= 2:
                # 过滤掉包含人物或生物的场景
                if not any(keyword in m for keyword in ['人', '员', '生', '物', '体', '男', '女', '老', '少', '师', '徒', '主', '配', '众', '群']):
                    scenes.add(m)
        
        # 匹配场景描述（格式：场景：XXX）
        pattern2 = r'场景[：:](.{2,30}?)(?=\n|【)'
        matches2 = re.findall(pattern2, body_text)
        for m in matches2:
            m = m.strip()
            if m and len(m) >= 2:
                # 过滤掉包含人物或生物的场景
                if not any(keyword in m for keyword in ['人', '员', '生', '物', '体', '男', '女', '老', '少', '师', '徒', '主', '配', '众', '群']):
                    scenes.add(m)
    
    # 过滤掉空内容
    scenes = [s for s in scenes if s.strip()]
    
    return sorted(list(scenes))


def generate_character_art_settings(characters: dict, start_episode: int, end_episode: int, series_name: str) -> str:
    """生成角色美术设定文档，包含详细的文生图提示词"""
    content = f"# {series_name} 角色美术设定（第{start_episode}-{end_episode}集）\n\n"
    content += "说明：本文件按剧本实际出场顺序提取所有角色，同一角色不同造型需分别标注为\"常规造型\"或\"特殊场景造型\"作为不同的美术资产。\n\n"
    content += "每个角色的文生图提示词包含：年龄、身高、体重、面部特征、妆容、发型、发色、服饰穿搭、随身配饰、特殊特征等详细信息。剧本未提及的信息会基于角色设定合理补充，贴合漫剧审美逻辑。\n\n"
    content += "---\n\n"
    
    # 按出场的总集数排序（出场次数多的角色排在前面）
    sorted_chars = sorted(characters.items(), key=lambda x: (-len(x[1]['episodes']), x[0]))
    
    for char_name, char_info in sorted_chars:
        # 获取角色出现的集数（按顺序）
        episodes_sorted = sorted(char_info['episodes'])
        episode_str = "、".join([str(ep) for ep in episodes_sorted])
        
        # 判断是否需要多个造型（如果角色在多集中出现，可能有不同造型）
        # 这里我们为每个角色生成一个常规造型和一个特殊场景造型（如果集数超过1集）
        has_special_style = len(char_info['episodes']) >= 2
        
        content += f"## {char_name}\n\n"
        content += f"**出场所集**: {episode_str}集\n\n"
        
        # 检测是否为奇幻生物
        is_fantasy_creature = detect_fantasy_creature(char_name)
        
        # 获取详细外观设定
        appearance = char_info['appearance'] if char_info['appearance'] else ""
        
        # 常规造型
        content += f"### {char_name}（常规造型）\n\n"
        content += f"**出场所集**: {episode_str}集\n\n"
        
        # 生成详细的文生图提示词
        prompt_normal = generate_detailed_character_prompt(
            char_name=char_name,
            appearance=appearance,
            style_type="常规造型",
            is_fantasy=is_fantasy_creature
        )
        content += f"**文生图提示词**: [{char_name}_常规造型]:[{prompt_normal}]\n\n"
        
        # 特殊场景造型（如果角色在多集中出现）
        if has_special_style:
            content += f"### {char_name}（特殊场景造型）\n\n"
            content += f"**出场所集**: {episode_str}集\n\n"
            
            # 生成特殊的文生图提示词
            prompt_special = generate_detailed_character_prompt(
                char_name=char_name,
                appearance=appearance,
                style_type="特殊场景造型",
                is_fantasy=is_fantasy_creature
            )
            content += f"**文生图提示词**: [{char_name}_特殊场景造型]:[{prompt_special}]\n\n"
        
        content += "---\n\n"
    
    return content


def detect_fantasy_creature(character_name: str) -> bool:
    """检测角色是否为奇幻生物"""
    fantasy_keywords = [
        '龙', '凤', '魔', '妖', '精', '灵', '兽', '怪', '神', '仙',
        'dragon', 'phoenix', 'demon', 'monster', 'spirit', 'beast',
        '精灵', '天使', '恶魔', '巨人', '矮人', '兽人', '龙族', '凤族',
        '骷髅', '僵尸', '幽灵', '妖怪', '魅魔', '天魔', '妖精', '幻兽'
    ]
    
    for keyword in fantasy_keywords:
        if keyword in character_name:
            return True
    
    return False


def generate_detailed_character_prompt(char_name: str, appearance: str, style_type: str, is_fantasy: bool) -> str:
    """生成详细的文生图提示词"""
    # 基础提示词
    prompt_parts = [
        "masterpiece",
        "best quality",
        "ultra-detailed",
        "anime style",
        f"{char_name} character design",
        f"{style_type}"
    ]
    
    # 如果有详细外观设定，解析并添加到提示词中
    if appearance:
        # 解析详细外观设定
        prompt_parts.extend(parse_appearance_description(appearance))
    else:
        # 如果没有详细外观设定，生成默认描述
        prompt_parts.extend(generate_default_appearance(char_name, is_fantasy))
    
    # 如果是奇幻生物，添加特殊特征
    if is_fantasy:
        prompt_parts.extend([
            "fantasy creature features",
            "magical aura",
            "ethereal glow"
        ])
    
    # 添加质量提升词
    prompt_parts.extend([
        "expressive face",
        "dynamic pose",
        "natural lighting",
        "high contrast",
        "vibrant colors",
        "cinematic composition",
        "8k resolution",
        "highly detailed"
    ])
    
    # 组合成最终的提示词
    final_prompt = ", ".join(prompt_parts)
    
    return final_prompt


def parse_appearance_description(appearance: str) -> list:
    """解析详细外观描述，提取关键词"""
    keywords = []
    
    # 常见的外观关键词映射
    age_keywords = {
        '幼': 'young child',
        '少年': 'teenager',
        '青年': 'young adult',
        '中年': 'middle-aged',
        '老年': 'elderly',
        '18岁': '18 years old',
        '20岁': '20 years old',
        '25岁': '25 years old',
        '30岁': '30 years old',
    }
    
    hair_keywords = {
        '黑发': 'black hair',
        '金发': 'blonde hair',
        '白发': 'white hair',
        '红发': 'red hair',
        '蓝发': 'blue hair',
        '长发': 'long hair',
        '短发': 'short hair',
        '卷发': 'curly hair',
        '直发': 'straight hair',
        '马尾': 'ponytail',
        '双马尾': 'twin tails',
    }
    
    eye_keywords = {
        '黑眼': 'black eyes',
        '蓝眼': 'blue eyes',
        '绿眼': 'green eyes',
        '红眼': 'red eyes',
        '金眼': 'golden eyes',
        '大眼': 'large eyes',
    }
    
    clothing_keywords = {
        '校服': 'school uniform',
        '连衣裙': 'dress',
        '外套': 'jacket',
        '西装': 'suit',
        '盔甲': 'armor',
        '长袍': 'robe',
        '古装': 'traditional Chinese clothing',
        '现代装': 'modern clothing',
        '运动装': 'sports wear',
    }
    
    # 从外观描述中提取关键词
    for cn, en in age_keywords.items():
        if cn in appearance:
            keywords.append(en)
    
    for cn, en in hair_keywords.items():
        if cn in appearance:
            keywords.append(en)
    
    for cn, en in eye_keywords.items():
        if cn in appearance:
            keywords.append(en)
    
    for cn, en in clothing_keywords.items():
        if cn in appearance:
            keywords.append(en)
    
    # 如果没有提取到任何关键词，添加一些通用的描述
    if not keywords:
        keywords.append("detailed character design")
    
    return keywords


def generate_default_appearance(char_name: str, is_fantasy: bool) -> list:
    """生成默认的外观描述"""
    if is_fantasy:
        return [
            f"{char_name} fantasy creature",
            "mystical appearance",
            "magical features",
            "ethereal beauty",
            "glowing aura"
        ]
    else:
        return [
            f"{char_name} human character",
            "attractive face",
            "detailed clothing",
            "natural expression",
            "well-proportioned body"
        ]


def generate_scene_art_settings(scenes: dict, start_episode: int, end_episode: int, series_name: str) -> str:
    """生成场景美术设定文档"""
    content = f"# {series_name} 场景美术设定（第{start_episode}-{end_episode}集）\n\n"
    content += "说明：本文件仅输出场景设定，不包含人类或生物。最大化场景资产复用，相同场景在不同集数中复用同一美术资产。\n\n"
    content += "---\n\n"
    
    # 按出场的总集数排序（出场次数多的场景排在前面，便于复用）
    sorted_scenes = sorted(scenes.items(), key=lambda x: (-len(x[1]), x[0]))
    
    for scene_name, episodes in sorted_scenes:
        # 获取场景出现的集数（按顺序）
        episodes_sorted = sorted(episodes)
        episode_str = "、".join([str(ep) for ep in episodes_sorted])
        
        content += f"## {scene_name}\n\n"
        content += f"**出场所集**: {episode_str}集\n\n"
        content += f"**复用说明**: 该场景在{len(episodes)}集中出现，可复用同一美术资产\n\n"
        
        # 生成美术设定提示词（强调场景环境，不包含人物）
        prompt = f"""masterpiece, best quality, ultra-detailed, {scene_name} 场景设定，动画短剧风格，{scene_name}环境，仅场景元素不包含人物，环境氛围浓厚，光影效果出色，画面细节丰富，高清渲染，最大化资产复用"""
        
        content += f"**美术设定**: [{scene_name}]:[{prompt}]\n\n"
        content += "---\n\n"
    
    return content


def upload_art_settings_file(storage, content: str, file_name: str, category: str) -> File:
    """上传美术设定文件到对象存储"""
    try:
        import time
        timestamp = int(time.time())
        original_name = f"{file_name}_{timestamp}.md"
        safe_filename, _ = get_safe_filename(original_name, category=category, use_timestamp=True)
        storage_key = f"art_settings/{safe_filename}"
        
        # 确保内容是UTF-8编码
        if isinstance(content, str):
            content_bytes = content.encode('utf-8')
        else:
            content_bytes = str(content).encode('utf-8')
        
        # 上传到对象存储
        file_key = storage.upload_file(
            file_content=content_bytes,
            file_name=storage_key,
            content_type="text/markdown",
            original_name=original_name
        )
        
        # 生成访问URL
        try:
            url = storage.generate_presigned_url(key=file_key, expire_time=3600)
            return File(url=url, file_type="document")
        except Exception:
            return File(url="", file_type="document")
    
    except Exception as e:
        print(f"上传美术设定文件失败: {e}")
        return File(url="", file_type="document")
