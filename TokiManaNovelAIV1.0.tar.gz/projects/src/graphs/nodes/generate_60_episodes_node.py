"""Generate 60 episodes node for workflow 3"""
import os
import json
import time
import zipfile
import tempfile
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File
from langchain_core.messages import SystemMessage, HumanMessage


def generate_60_episodes_node(
    state: dict,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> dict:
    """
    title: 生成60集完整脚本
    desc: 分批生成60集脚本（每批10集），每集包含简介、剧本正文、配音台本，并打包成压缩包
    integrations: 大语言模型, 对象存储
    """
    ctx = runtime.context

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return {
            "package_url": "",
            "message": f"❌ 初始化存储服务失败: {str(e)}"
        }

    # Get outline from storage
    outline_content = ""
    try:
        result = storage.list_files(prefix="outlines/")
        if result.get("keys"):
            outline_key = result["keys"][-1]
            if outline_key:
                content = storage.read_file(file_key=outline_key)
                outline_content = content.decode('utf-8') if isinstance(content, bytes) else content
    except Exception as e:
        return {
            "package_url": "",
            "message": f"❌ 读取大纲失败: {str(e)}"
        }

    if not outline_content:
        return {
            "package_url": "",
            "message": "❌ 未找到大纲，请先生成大纲"
        }

    # Get template content from storage
    template_content = ""
    try:
        result = storage.list_files(prefix="templates/")
        if result.get("keys"):
            template_key = result["keys"][-1]
            if template_key:
                content = storage.read_file(file_key=template_key)
                template_content = content.decode('utf-8') if isinstance(content, bytes) else content
    except Exception as e:
        template_content = ""  # Template is optional

    # 定义批次
    episode_batches = [
        "第1-10集",
        "第11-20集",
        "第21-30集",
        "第31-40集",
        "第41-50集",
        "第51-60集"
    ]

    # 读取LLM配置
    try:
        cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_60_episodes_cfg.json")
        with open(cfg_file, 'r', encoding='utf-8') as fd:
            _cfg = json.load(fd)
        llm_config = _cfg.get("config", {})
        sp = _cfg.get("sp", "")
        up = _cfg.get("up", "")
    except Exception as e:
        return {
            "package_url": "",
            "message": f"❌ 读取配置失败: {str(e)}"
        }

    # 创建临时目录保存文件
    temp_dir = tempfile.mkdtemp()
    all_files = []

    try:
        from coze_coding_utils.runtime_ctx.context import new_context
        llm_ctx = new_context(method="invoke")
        client = LLMClient(ctx=llm_ctx)

        # 分批生成
        for batch_idx, episode_range in enumerate(episode_batches, 1):
            print(f"[{batch_idx}/6] 正在生成{episode_range}...")
            print(f"  开始时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")

            # 渲染用户提示词
            up_tpl = Template(up)
            user_prompt = up_tpl.render(
                outline_content=outline_content,
                template_content=template_content,
                episode_range=episode_range
            )

            messages = [
                SystemMessage(content=sp),
                HumanMessage(content=user_prompt)
            ]

            # 调用LLM生成脚本
            print(f"  调用LLM生成{episode_range}脚本...")
            response = client.invoke(
                messages=messages,
                model=llm_config.get("model", "doubao-seed-1-8-251228"),
                temperature=llm_config.get("temperature", 0.8),
                top_p=llm_config.get("top_p", 0.9),
                max_completion_tokens=llm_config.get("max_completion_tokens", 32768),
                thinking=llm_config.get("thinking", "disabled")
            )

            # 解析响应
            scripts_content = response.content
            if isinstance(scripts_content, list):
                scripts_content = " ".join(str(item) for item in scripts_content)

            # 按分隔符拆分每集
            episodes = scripts_content.split("---")
            episode_num_start = int(episode_range.split("-")[0].replace("第", "").replace("集", ""))

            for i, episode in enumerate(episodes):
                episode_num = episode_num_start + i
                if not episode.strip():
                    continue

                # 保存每集脚本
                episode_file = os.path.join(temp_dir, f"第{episode_num}集.md")
                with open(episode_file, 'w', encoding='utf-8') as f:
                    f.write(episode.strip())
                all_files.append(episode_file)

                print(f"  ✓ 第{episode_num}集已生成")

        # 读取美术设定配置
        try:
            art_cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH"), "config/generate_art_settings_60_cfg.json")
            with open(art_cfg_file, 'r', encoding='utf-8') as fd:
                _art_cfg = json.load(fd)
            art_llm_config = _art_cfg.get("config", {})
            art_sp = _art_cfg.get("sp", "")
            art_up = _art_cfg.get("up", "")
        except Exception as e:
            print(f"⚠️ 读取美术设定配置失败，跳过美术设定生成: {e}")
            art_llm_config = None

        # 分批生成美术设定（每批10集）
        if art_llm_config:
            for episode_range in episode_batches:
                print(f"正在生成{episode_range}美术设定...")

                # 读取该批次的脚本内容
                episode_num_start = int(episode_range.split("-")[0].replace("第", "").replace("集", ""))
                episode_num_end = int(episode_range.split("-")[1].replace("集", ""))
                batch_episodes = []
                for num in range(episode_num_start, episode_num_end + 1):
                    episode_file = os.path.join(temp_dir, f"第{num}集.md")
                    if os.path.exists(episode_file):
                        with open(episode_file, 'r', encoding='utf-8') as f:
                            batch_episodes.append(f.read())

                if not batch_episodes:
                    continue

                batch_content = "\n\n---\n\n".join(batch_episodes)

                # 渲染美术设定提示词
                art_up_tpl = Template(art_up)
                art_user_prompt = art_up_tpl.render(
                    episodes_content=batch_content,
                    episode_range=episode_range
                )

                art_messages = [
                    SystemMessage(content=art_sp),
                    HumanMessage(content=art_user_prompt)
                ]

                # 调用LLM生成美术设定
                art_response = client.invoke(
                    messages=art_messages,
                    model=art_llm_config.get("model", "doubao-seed-1-8-251228"),
                    temperature=art_llm_config.get("temperature", 0.8),
                    top_p=art_llm_config.get("top_p", 0.9),
                    max_completion_tokens=art_llm_config.get("max_completion_tokens", 32768),
                    thinking=art_llm_config.get("thinking", "disabled")
                )

                # 解析并保存美术设定
                art_content = art_response.content
                if isinstance(art_content, list):
                    art_content = " ".join(str(item) for item in art_content)

                # 保存美术设定（新格式：[美术元素名称]：[香蕉pro文生图提示词]）
                # 按照"角色美术设定清单"和"场景美术设定清单"标题分割
                art_file = os.path.join(temp_dir, f"美术设定清单_{episode_range}.md")
                with open(art_file, 'w', encoding='utf-8') as f:
                    f.write(art_content)
                all_files.append(art_file)

                print(f"  ✓ {episode_range}美术设定已生成")

        # 生成完整台本（将所有集数合并）
        complete_script_file = os.path.join(temp_dir, "完整台本（第1-60集）.md")
        with open(complete_script_file, 'w', encoding='utf-8') as f:
            f.write("# 完整台本（第1-60集）\n\n")
            for episode_num in range(1, 61):
                episode_file = os.path.join(temp_dir, f"第{episode_num}集.md")
                if os.path.exists(episode_file):
                    with open(episode_file, 'r', encoding='utf-8') as ef:
                        f.write(ef.read())
                        f.write("\n\n---\n\n")
        all_files.append(complete_script_file)

        # 打包成压缩包
        package_filename = "炸炉炼丹师动画短剧_第1-60集.zip"
        package_file = os.path.join(temp_dir, package_filename)
        with zipfile.ZipFile(package_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_path in all_files:
                arcname = os.path.basename(file_path)
                zipf.write(file_path, arcname)

        # 上传压缩包到对象存储
        with open(package_file, 'rb') as f:
            package_content = f.read()

        original_name = package_filename
        safe_filename, _ = get_safe_filename(original_name, category="packages", use_timestamp=True)
        storage_key = f"packages/{safe_filename}"

        file_key = storage.upload_file(
            file_content=package_content,
            file_name=storage_key,
            content_type="application/zip",
            original_name=original_name
        )

        # 获取本地文件路径
        if hasattr(storage, 'use_s3') and not storage.use_s3:
            # 本地存储模式
            file_path = storage.generate_presigned_url(key=file_key, expire_time=3600)
            package_url = file_path

            # 构建详细的完成消息
            success_message = f"""✅ 成功生成60集完整脚本并打包！

📦 压缩包信息：
   - 文件数：{len(all_files)} 个文件
   - 文件名：{package_filename}
   - 文件大小：{len(package_content) / 1024:.1f} KB

💾 文件位置：
   {file_path}

💡 使用方法：
   1. 在资源管理器中打开上述路径
   2. 找到压缩包文件：{package_filename}
   3. 右键 -> 解压文件
   4. 查看生成的60集脚本和美术设定

⚠️  注意：
   - 文件已保存到本地，无需下载
   - 建议备份到其他位置
"""
        else:
            # S3存储模式
            package_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

            # 构建详细的完成消息，包含下载链接
            success_message = f"""✅ 成功生成60集完整脚本并打包！

📦 压缩包信息：
   - 文件数：{len(all_files)} 个文件
   - 文件名：{package_filename}
   - 文件大小：{len(package_content) / 1024:.1f} KB

📥 下载链接（有效期1小时）：
   {package_url}

💡 使用方法：
   1. 复制上面的下载链接
   2. 在浏览器中打开
   3. 浏览器会自动下载文件到你的电脑
   4. 文件会保存在：浏览器的默认下载目录（通常是下载文件夹）

⚠️  注意：
   - 下载链接有效期1小时，超时需要重新生成
   - 建议尽快下载并备份到你的电脑
"""

        # 构建详细的完成消息，包含下载链接
        success_message = f"""✅ 成功生成60集完整脚本并打包！

📦 压缩包信息：
   - 文件数：{len(all_files)} 个文件
   - 文件名：{package_filename}
   - 文件大小：{len(package_content) / 1024:.1f} KB

📥 下载链接（有效期1小时）：
   {package_url}

💡 使用方法：
   1. 复制上面的下载链接
   2. 在浏览器中打开
   3. 浏览器会自动下载文件到你的电脑
   4. 文件会保存在：浏览器的默认下载目录（通常是下载文件夹）

⚠️  注意：
   - 下载链接有效期1小时，超时需要重新生成
   - 建议尽快下载并备份到你的电脑
"""

        return {
            "package_url": package_url,
            "message": success_message
        }

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        print(f"生成60集失败: {error_detail}")
        return {
            "package_url": "",
            "message": f"❌ 生成60集失败: {str(e)}"
        }
