"""
填写剧集Excel节点
"""
import os
import tempfile
import openpyxl
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from utils.file_utils import get_safe_filename
from utils.file.file import File, FileOps
from graphs.state import FillEpisodeExcelInput, FillEpisodeExcelOutput


def fill_episode_excel_node(
    state: FillEpisodeExcelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> FillEpisodeExcelOutput:
    """
    title: 填写剧集导入Excel
    desc: 将生成的脚本内容填写到剧集导入Excel模板中，并上传到对象存储
    integrations: 对象存储
    """
    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return FillEpisodeExcelOutput(
            excel_file=File(url="", file_type="document"),
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 创建临时目录
    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, "filled_episode_excel.xlsx")

    try:
        # 创建新的Excel文件
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "剧集导入表"

        # 添加表头
        headers = ["剧集序号", "剧集内容", "备注"]
        ws.append(headers)

        # 从script_files和scripts_content中提取数据
        episode_number = 1
        for script_file in state.script_files:
            # 优先从scripts_content中读取（避免URL访问问题）
            episode_key = f"episode_{episode_number}"
            content = ""

            if state.scripts_content and episode_key in state.scripts_content:
                # 直接从scripts_content中读取
                content = state.scripts_content[episode_key]
            else:
                # 尝试从文件URL中读取
                try:
                    if script_file.url:  # 只有URL不为空才尝试读取
                        content = FileOps.extract_text(script_file)
                    else:
                        content = "脚本文件未上传"
                except Exception as e:
                    # 如果读取失败，使用URL
                    content = script_file.url if script_file.url else f"读取失败: {str(e)}"

            # 填写到Excel
            display_content = content[:500] if len(content) > 500 else content  # 限制长度
            ws.append([
                f"第{episode_number}集",
                display_content,
                ""
            ])
            episode_number += 1

        # 如果没有脚本文件，添加一个默认行
        if episode_number == 1:
            ws.append(["第1集", "暂无脚本内容", ""])

        # 保存Excel
        wb.save(output_path)

        # 读取Excel文件内容
        with open(output_path, 'rb') as f:
            excel_content = f.read()

        # 生成安全的文件名和中文名称（使用时间戳，每次生成不同文件名）
        original_name = "剧集导入表_已填写.xlsx"
        safe_filename, _ = get_safe_filename(original_name, category="excel", use_timestamp=True)
        storage_key = f"excel/{safe_filename}"

        # 上传到对象存储
        file_key = storage.upload_file(
            file_content=excel_content,
            file_name=storage_key,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            original_name=original_name
        )

        # 生成访问URL
        filled_url = storage.generate_presigned_url(key=file_key, expire_time=3600)

        return FillEpisodeExcelOutput(
            excel_file=File(url=filled_url, file_type="document"),
            message=f"✅ 剧集Excel已填写，共{episode_number - 1}集"
        )

    except Exception as e:
        return FillEpisodeExcelOutput(
            excel_file=File(url="", file_type="document"),
            message=f"❌ 填写剧集Excel失败: {str(e)}"
        )
    finally:
        # 清理临时文件
        if os.path.exists(output_path):
            os.remove(output_path)
