"""
选择大纲节点（图形化版 - 用于工作流2）
"""
from pathlib import Path
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.storage_adapter import StorageAdapter
from graphs.state import SelectOutlineInput, SelectOutlineOutput


def select_outline_node(
    state: SelectOutlineInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SelectOutlineOutput:
    """
    title: 选择大纲
    desc: 从下拉框选择一个大纲文件，查看内容
    """
    ctx = runtime.context
    
    # 处理 outline_name：可能包含路径，需要提取文件名
    outline_name = state.outline_name
    
    # 如果包含路径分隔符，提取文件名
    if "\\" in outline_name or "/" in outline_name:
        outline_name = Path(outline_name).name
    
    if not outline_name:
        return SelectOutlineOutput(
            outline_name="",
            outline_content="",
            message="❌ 请先从下拉框选择大纲"
        )

    # 初始化存储适配器
    try:
        storage = StorageAdapter(use_s3=True)
    except Exception as e:
        return SelectOutlineOutput(
            outline_name="",
            outline_content="",
            message=f"❌ 初始化存储服务失败: {str(e)}"
        )

    # 列出所有文件，找到大纲文件
    result = storage.list_files(prefix="")

    # 根据原始文件名查找文件
    selected_file_key = None
    for file_key in result.get("keys", []):
        # 过滤掉空key、bucket前缀（以/结尾）和空白key
        if not file_key or not file_key.strip() or file_key.endswith("/"):
            continue
        
        # 过滤：只保留大纲文件（文件名包含"outline"）
        file_name_lower = file_key.lower()
        if "outline" not in file_name_lower:
            continue
        
        try:
            # 标准化文件键（处理Windows路径的反斜杠问题）
            normalized_key = file_key.replace("\\", "/")
            
            # 获取文件元数据
            metadata = storage.get_file_metadata(normalized_key)
            original_name = metadata.get("original_name", "")
            display_name = original_name if original_name else Path(file_key).name
            
            # 匹配原始文件名或显示名称
            if original_name == outline_name or display_name == outline_name or Path(file_key).name == outline_name:
                selected_file_key = file_key
                print(f"[DEBUG] 找到匹配的大纲: {file_key}")
                break
        except Exception as e:
            print(f"获取文件元数据失败: {e}")

    if not selected_file_key:
        print(f"[DEBUG] 未找到大纲: {outline_name}")
        print(f"[DEBUG] 可用的文件: {result.get('keys', [])}")
        return SelectOutlineOutput(
            outline_name="",
            outline_content="",
            message=f"❌ 未找到大纲：{outline_name}"
        )

    # 读取文件内容
    try:
        file_bytes = storage.read_file(selected_file_key)
        content = file_bytes.decode('utf-8')

        return SelectOutlineOutput(
            outline_name=outline_name,
            outline_content=content,
            message=f"✅ 已选择大纲：{outline_name}"
        )
    except Exception as e:
        return SelectOutlineOutput(
            outline_name="",
            outline_content="",
            message=f"❌ 读取大纲内容失败: {str(e)}"
        )
