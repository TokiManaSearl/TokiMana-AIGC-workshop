"""
LLM提供商管理器
支持多个LLM提供商：火山方舟、DeepSeek、Gemini、OpenAI、通义千问、智谱AI等
"""
import os
import json
from typing import Optional, Dict, Any, List
from enum import Enum
from openai import OpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage


class LLMProviderType(str, Enum):
    """LLM提供商类型"""
    VOLCANO_ARK = "volcano_ark"
    DEEPSEEK = "deepseek"
    GEMINI = "gemini"
    OPENAI = "openai"
    QIANWEN = "qianwen"
    ZHIPU = "zhipu"
    CUSTOM = "custom"


class LLMProvider:
    """LLM提供商管理类"""

    def __init__(self, config_path: Optional[str] = None):
        """
        初始化LLM提供商管理器

        Args:
            config_path: 配置文件路径，默认为 config/llm_providers.json
        """
        self.project_root = os.getenv("COZE_WORKSPACE_PATH", "")
        if config_path is None:
            config_path = os.path.join(self.project_root, "config", "llm_providers.json")

        self.config_path = config_path
        self.config = self._load_config()
        self.enabled_provider = self._get_enabled_provider()

    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        if not os.path.exists(self.config_path):
            # 如果配置文件不存在，返回默认配置
            return {
                "enabled_provider": "volcano_ark",
                "providers": {}
            }

        with open(self.config_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def _save_config(self) -> None:
        """保存配置文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def _get_enabled_provider(self) -> str:
        """获取当前启用的提供商"""
        # 优先使用环境变量
        env_provider = os.getenv("LLM_PROVIDER")
        if env_provider and env_provider in self.config.get("providers", {}):
            return env_provider

        # 否则使用配置文件中的设置
        return self.config.get("enabled_provider", "volcano_ark")

    def get_providers_list(self) -> List[Dict[str, Any]]:
        """获取所有提供商列表"""
        providers = []
        for provider_id, provider_config in self.config.get("providers", {}).items():
            providers.append({
                "id": provider_id,
                "name": provider_config.get("name", provider_id),
                "description": provider_config.get("description", ""),
                "enabled": provider_config.get("enabled", False),
                "configured": bool(provider_config.get("config", {}).get("api_key", ""))
            })
        return providers

    def get_provider_config(self, provider_id: str) -> Optional[Dict[str, Any]]:
        """获取指定提供商的配置"""
        return self.config.get("providers", {}).get(provider_id)

    def update_provider_config(self, provider_id: str, config: Dict[str, Any]) -> bool:
        """
        更新提供商配置

        Args:
            provider_id: 提供商ID
            config: 配置字典

        Returns:
            是否更新成功
        """
        if provider_id not in self.config.get("providers", {}):
            return False

        self.config["providers"][provider_id]["config"].update(config)
        self._save_config()
        return True

    def enable_provider(self, provider_id: str) -> bool:
        """
        启用指定的提供商

        Args:
            provider_id: 提供商ID

        Returns:
            是否启用成功
        """
        if provider_id not in self.config.get("providers", {}):
            return False

        # 禁用所有提供商
        for pid in self.config["providers"]:
            self.config["providers"][pid]["enabled"] = False

        # 启用指定的提供商
        self.config["providers"][provider_id]["enabled"] = True
        self.config["enabled_provider"] = provider_id
        self._save_config()

        # 更新当前启用的提供商
        self.enabled_provider = provider_id
        return True

    def get_current_provider(self) -> str:
        """获取当前启用的提供商ID"""
        return self.enabled_provider

    def get_client(self) -> OpenAI:
        """
        获取OpenAI客户端（兼容所有OpenAI兼容的API）

        Returns:
            OpenAI客户端实例
        """
        provider_config = self.get_provider_config(self.enabled_provider)
        if not provider_config:
            raise ValueError(f"提供商 {self.enabled_provider} 不存在")

        config = provider_config.get("config", {})

        # 检查是否配置了API Key
        api_key = config.get("api_key", "")
        if not api_key:
            # 尝试从环境变量读取
            env_key = f"{self.enabled_provider.upper()}_API_KEY"
            api_key = os.getenv(env_key, "")

            if not api_key:
                raise ValueError(f"未配置API Key，请在配置文件或环境变量中设置 {env_key}")

        # 创建OpenAI客户端
        endpoint = config.get("endpoint", "")
        if not endpoint:
            raise ValueError("未配置API端点")

        client = OpenAI(
            api_key=api_key,
            base_url=endpoint
        )

        return client

    def call_llm(
        self,
        messages: List[Any],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        调用LLM

        Args:
            messages: 消息列表
            model: 模型名称（可选，默认使用配置中的模型）
            temperature: 温度参数（可选）
            max_tokens: 最大token数（可选）
            **kwargs: 其他参数

        Returns:
            LLM返回的文本内容
        """
        provider_config = self.get_provider_config(self.enabled_provider)
        if not provider_config:
            raise ValueError(f"提供商 {self.enabled_provider} 不存在")

        config = provider_config.get("config", {})

        # 获取模型参数
        llm_model = model or config.get("model", "")
        if not llm_model:
            raise ValueError("未配置模型名称")

        llm_temperature = temperature if temperature is not None else config.get("temperature", 0.7)
        llm_max_tokens = max_tokens if max_tokens is not None else config.get("max_tokens", 4096)

        # 获取客户端
        client = self.get_client()

        # 调用LLM
        try:
            response = client.chat.completions.create(
                model=llm_model,
                messages=messages,
                temperature=llm_temperature,
                max_tokens=llm_max_tokens,
                **kwargs
            )
            return response.choices[0].message.content
        except Exception as e:
            raise Exception(f"LLM调用失败: {str(e)}")

    def call_llm_with_config(
        self,
        llm_cfg: Dict[str, Any],
        messages: List[Any],
        **kwargs
    ) -> str:
        """
        使用指定的LLM配置调用LLM

        Args:
            llm_cfg: LLM配置字典
            messages: 消息列表
            **kwargs: 其他参数

        Returns:
            LLM返回的文本内容
        """
        # 获取模型参数
        model = llm_cfg.get("model", "")
        if not model:
            raise ValueError("未配置模型名称")

        temperature = llm_cfg.get("temperature", 0.7)
        max_tokens = llm_cfg.get("max_tokens", 4096)

        return self.call_llm(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs
        )

    def get_models_list(self, provider_id: str) -> List[Dict[str, str]]:
        """
        获取指定提供商的模型列表

        Args:
            provider_id: 提供商ID

        Returns:
            模型列表
        """
        models_config = self.config.get("models", {}).get(provider_id, {})
        models = []
        for model_id, model_name in models_config.items():
            models.append({
                "id": model_id,
                "name": model_name
            })
        return models

    def test_connection(self, provider_id: Optional[str] = None) -> Dict[str, Any]:
        """
        测试LLM连接

        Args:
            provider_id: 提供商ID（可选，默认测试当前启用的提供商）

        Returns:
            测试结果
        """
        if provider_id is None:
            provider_id = self.enabled_provider

        provider_config = self.get_provider_config(provider_id)
        if not provider_config:
            return {
                "success": False,
                "message": f"提供商 {provider_id} 不存在"
            }

        config = provider_config.get("config", {})
        api_key = config.get("api_key", "")

        if not api_key:
            return {
                "success": False,
                "message": "未配置API Key"
            }

        try:
            # 尝试调用一次LLM
            client = OpenAI(
                api_key=api_key,
                base_url=config.get("endpoint", "")
            )

            model = config.get("model", "")
            if not model:
                return {
                    "success": False,
                    "message": "未配置模型名称"
                }

            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": "你好"}],
                max_tokens=10
            )

            return {
                "success": True,
                "message": f"连接成功！模型响应: {response.choices[0].message.content[:20]}..."
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"连接失败: {str(e)}"
            }


# 创建全局LLM提供商管理器实例
_llm_provider = None


def get_llm_provider() -> LLMProvider:
    """获取全局LLM提供商管理器实例"""
    global _llm_provider
    if _llm_provider is None:
        _llm_provider = LLMProvider()
    return _llm_provider
