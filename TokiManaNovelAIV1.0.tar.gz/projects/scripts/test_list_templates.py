#!/usr/bin/env python3
"""测试脚本：测试list_templates_node"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

from graphs.nodes.list_templates_node import list_templates_node
from graphs.state import ListTemplatesInput
from langchain_core.runnables import RunnableConfig
from coze_coding_utils.runtime_ctx.context import new_context

def test_list_templates():
    """测试list_templates_node"""
    print("=" * 60)
    print("测试 list_templates_node")
    print("=" * 60)

    # 准备输入
    state = ListTemplatesInput()
    config = RunnableConfig()
    ctx = new_context(method="invoke")

    # 创建模拟Runtime
    class MockRuntime:
        def __init__(self, context):
            self.context = context

    mock_runtime = MockRuntime(ctx)

    # 执行节点
    print("正在执行 list_templates_node...")
    result = list_templates_node(state, config, mock_runtime)

    print(f"\n返回结果:")
    print(f"  - message: {result.message}")
    print(f"  - templates 数量: {len(result.templates)}")

    if result.templates:
        for idx, template in enumerate(result.templates):
            print(f"\n  模板 {idx + 1}:")
            print(f"    - name: {template.get('name')}")
            print(f"    - url: {template.get('url')[:50]}..." if template.get('url') else "    - url: N/A")

    if "✅" in result.message:
        print("\n✅ list_templates_node 测试通过")
        return True
    else:
        print(f"\n❌ list_templates_node 测试失败")
        return False


if __name__ == "__main__":
    test_list_templates()
