#!/usr/bin/env python3
"""测试脚本：验证工作流2和工作流3的文件输出修复"""
import os
import sys

# 设置Python路径
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", ".")))
sys.path.insert(0, os.path.join(os.getenv("COZE_WORKSPACE_PATH", "."), "src"))

def test_storage_adapter():
    """测试StorageAdapter功能"""
    print("=" * 60)
    print("测试 1: StorageAdapter 功能")
    print("=" * 60)

    try:
        from utils.storage_adapter import StorageAdapter
        from utils.file_utils import get_safe_filename

        # 测试中文文件名生成
        test_cases = [
            "脚本文件.txt",
            "美术设定清单.md",
            "分集脚本.xlsx",
            "角色设计表格.xlsx"
        ]

        for filename in test_cases:
            safe_name, ext = get_safe_filename(filename, category="test")
            print(f"✅ 原始文件名: {filename}")
            print(f"   安全文件名: {safe_name}")
            print(f"   扩展名: {ext}")

        # 测试存储初始化
        storage = StorageAdapter(use_s3=False)
        print("✅ StorageAdapter初始化成功（本地存储模式）")

        print("\n✅ StorageAdapter 功能测试通过")
        return True

    except Exception as e:
        print(f"\n❌ StorageAdapter 功能测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_generate_scripts_node():
    """测试generate_scripts_node节点"""
    print("\n" + "=" * 60)
    print("测试 2: Generate Scripts Node")
    print("=" * 60)

    try:
        from graphs.nodes.generate_scripts_node import generate_scripts_node
        from graphs.state import GenerateScriptsInput
        from langchain_core.runnables import RunnableConfig
        from langgraph.runtime import Runtime
        from coze_coding_utils.runtime_ctx.context import new_context, Context

        # 准备输入
        state = GenerateScriptsInput(
            outline_content="测试大纲内容",
            template_content="测试模板内容"
        )

        config = RunnableConfig(
            metadata={"llm_cfg": "config/generate_scripts_cfg.json"}
        )

        ctx = new_context(method="invoke")
        # Runtime[Context] 是类型注解，不需要初始化
        # 直接传递 ctx 作为 runtime 参数

        # 执行节点
        print("正在执行 generate_scripts_node...")
        # 由于节点需要 Runtime[Context]，我们创建一个模拟对象
        class MockRuntime:
            def __init__(self, context):
                self.context = context

        mock_runtime = MockRuntime(ctx)
        result = generate_scripts_node(state, config, mock_runtime)

        print(f"返回结果:")
        print(f"  - message: {result.message}")
        print(f"  - script_files 数量: {len(result.script_files)}")

        if result.script_files:
            for idx, script_file in enumerate(result.script_files):
                print(f"\n  脚本文件 {idx + 1}:")
                print(f"    - URL: {script_file.url}")
                print(f"    - File type: {script_file.file_type}")

        if "✅" in result.message:
            print("\n✅ Generate Scripts Node 测试通过")
            return True
        else:
            print(f"\n❌ Generate Scripts Node 测试失败: {result.message}")
            return False

    except Exception as e:
        print(f"\n❌ Generate Scripts Node 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_fill_excel_nodes():
    """测试fill_episode_excel_node和fill_art_excel_node"""
    print("\n" + "=" * 60)
    print("测试 3: Fill Excel Nodes")
    print("=" * 60)

    try:
        from graphs.nodes.fill_episode_excel_node import fill_episode_excel_node
        from graphs.nodes.fill_art_excel_node import fill_art_excel_node
        from graphs.state import FillEpisodeExcelInput, FillArtExcelInput
        from langchain_core.runnables import RunnableConfig
        from coze_coding_utils.runtime_ctx.context import new_context
        from utils.file.file import File

        ctx = new_context(method="invoke")
        config = RunnableConfig()

        # 创建模拟Runtime
        class MockRuntime:
            def __init__(self, context):
                self.context = context

        mock_runtime = MockRuntime(ctx)

        # 测试 fill_episode_excel_node
        print("\n测试 fill_episode_excel_node...")
        episode_state = FillEpisodeExcelInput(
            script_files=[
                File(url="http://example.com/script1.txt", file_type="document"),
                File(url="http://example.com/script2.txt", file_type="document")
            ]
        )

        episode_result = fill_episode_excel_node(episode_state, config, mock_runtime)
        print(f"结果: {episode_result.message}")
        print(f"Excel URL: {episode_result.excel_file.url}")

        # 测试 fill_art_excel_node
        print("\n测试 fill_art_excel_node...")
        art_state = FillArtExcelInput(
            character_settings=[{"name": "角色1", "description": "描述1"}],
            scene_settings=[{"name": "场景1", "description": "描述1"}],
            prop_settings=[{"name": "道具1", "description": "描述1"}]
        )

        art_result = fill_art_excel_node(art_state, config, mock_runtime)
        print(f"结果: {art_result.message}")
        print(f"Excel URL: {art_result.excel_file.url}")

        if "✅" in episode_result.message and "✅" in art_result.message:
            print("\n✅ Fill Excel Nodes 测试通过")
            return True
        else:
            print("\n❌ Fill Excel Nodes 测试失败")
            return False

    except Exception as e:
        print(f"\n❌ Fill Excel Nodes 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_create_package_node():
    """测试create_package_node节点"""
    print("\n" + "=" * 60)
    print("测试 4: Create Package Node")
    print("=" * 60)

    try:
        from graphs.nodes.create_package_node import create_package_node
        from graphs.state import CreatePackageInput
        from langchain_core.runnables import RunnableConfig
        from coze_coding_utils.runtime_ctx.context import new_context
        from utils.file.file import File

        ctx = new_context(method="invoke")
        config = RunnableConfig()

        # 创建模拟Runtime
        class MockRuntime:
            def __init__(self, context):
                self.context = context

        mock_runtime = MockRuntime(ctx)

        # 准备输入
        state = CreatePackageInput(
            excel_files=[
                File(url="http://example.com/episodes.xlsx", file_type="document"),
                File(url="http://example.com/art.xlsx", file_type="document")
            ]
        )

        # 执行节点
        print("正在执行 create_package_node...")
        result = create_package_node(state, config, mock_runtime)

        print(f"返回结果:")
        print(f"  - message: {result.message}")
        print(f"  - package_file URL: {result.package_file.url}")
        print(f"  - File type: {result.package_file.file_type}")

        if "✅" in result.message:
            print("\n✅ Create Package Node 测试通过")
            return True
        else:
            print(f"\n❌ Create Package Node 测试失败: {result.message}")
            return False

    except Exception as e:
        print(f"\n❌ Create Package Node 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_generate_art_settings_node():
    """测试generate_art_settings_node节点"""
    print("\n" + "=" * 60)
    print("测试 5: Generate Art Settings Node")
    print("=" * 60)

    try:
        from graphs.nodes.generate_art_settings_node import generate_art_settings_node
        from graphs.state import GenerateArtSettingsInput
        from langchain_core.runnables import RunnableConfig
        from coze_coding_utils.runtime_ctx.context import new_context

        # 准备输入
        state = GenerateArtSettingsInput(
            outline_content="测试大纲内容",
            template_content="测试模板内容"
        )

        config = RunnableConfig(
            metadata={"llm_cfg": "config/generate_art_settings_cfg.json"}
        )

        ctx = new_context(method="invoke")

        # 创建模拟Runtime
        class MockRuntime:
            def __init__(self, context):
                self.context = context

        mock_runtime = MockRuntime(ctx)

        # 执行节点
        print("正在执行 generate_art_settings_node...")
        result = generate_art_settings_node(state, config, mock_runtime)

        print(f"返回结果:")
        print(f"  - message: {result.message}")
        print(f"  - character_settings 数量: {len(result.character_settings)}")
        print(f"  - scene_settings 数量: {len(result.scene_settings)}")
        print(f"  - prop_settings 数量: {len(result.prop_settings)}")

        if "✅" in result.message:
            print("\n✅ Generate Art Settings Node 测试通过")
            return True
        else:
            print(f"\n❌ Generate Art Settings Node 测试失败: {result.message}")
            return False

    except Exception as e:
        print(f"\n❌ Generate Art Settings Node 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("开始节点功能测试")
    print("=" * 60)

    results = []

    # 测试1: StorageAdapter
    results.append(("StorageAdapter", test_storage_adapter()))

    # 测试2: Generate Scripts Node
    results.append(("Generate Scripts Node", test_generate_scripts_node()))

    # 测试3: Fill Excel Nodes
    results.append(("Fill Excel Nodes", test_fill_excel_nodes()))

    # 测试4: Create Package Node
    results.append(("Create Package Node", test_create_package_node()))

    # 测试5: Generate Art Settings Node
    results.append(("Generate Art Settings Node", test_generate_art_settings_node()))

    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)

    passed = 0
    failed = 0

    for test_name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
        else:
            failed += 1

    print(f"\n总计: {len(results)} 个测试")
    print(f"通过: {passed} 个")
    print(f"失败: {failed} 个")

    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
