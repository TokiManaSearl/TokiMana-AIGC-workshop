#!/bin/bash

# 快速分享工作流脚本
# 使用方法：bash scripts/quick_share.sh

set -e  # 遇到错误立即退出

echo "========================================="
echo "  小说改编动画短剧工作流 - 快速分享"
echo "========================================="
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 获取项目根目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

echo "📍 项目位置: $PROJECT_ROOT"
echo ""

# 检查Git状态
if [ ! -d ".git" ]; then
    echo -e "${YELLOW}⚠️  Git仓库未初始化，正在初始化...${NC}"
    git init
    git add .
    git commit -m "feat: 初始化小说改编动画短剧工作流系统"
    echo -e "${GREEN}✅ Git仓库初始化完成${NC}"
else
    echo -e "${GREEN}✅ Git仓库已存在${NC}"
fi

echo ""
echo "========================================="
echo "请选择分享方式："
echo "========================================="
echo "1. Git仓库分享（推荐，适合团队协作）"
echo "2. 压缩包分享（适合快速单次分享）"
echo "3. 查看分享指南"
echo "4. 退出"
echo ""
read -p "请输入选项 (1/2/3/4): " choice

case $choice in
    1)
        echo ""
        echo "========================================="
        echo "  Git仓库分享"
        echo "========================================="
        echo ""

        # 检查远程仓库
        if [ -z "$(git remote get-url origin 2>/dev/null)" ]; then
            echo "⚠️  未配置远程仓库"
            echo ""
            echo "请输入远程仓库地址："
            echo "示例："
            echo "  - GitHub: https://github.com/用户名/novel-to-animation-workflow.git"
            echo "  - GitLab: https://gitlab.com/用户名/novel-to-animation-workflow.git"
            echo "  - Gitee: https://gitee.com/用户名/novel-to-animation-workflow.git"
            echo ""
            read -p "仓库地址: " repo_url

            if [ -z "$repo_url" ]; then
                echo -e "${RED}❌ 仓库地址不能为空${NC}"
                exit 1
            fi

            git remote add origin "$repo_url"
            echo -e "${GREEN}✅ 远程仓库已配置${NC}"
        else
            repo_url=$(git remote get-url origin)
            echo -e "${GREEN}✅ 已配置远程仓库: $repo_url${NC}"
        fi

        echo ""
        read -p "是否推送到远程仓库？ (y/n): " push_confirm

        if [ "$push_confirm" = "y" ] || [ "$push_confirm" = "Y" ]; then
            echo ""
            echo "正在推送代码..."
            git push -u origin main || git push -u origin master

            echo ""
            echo -e "${GREEN}=========================================${NC}"
            echo -e "${GREEN}✅ 代码已推送到远程仓库${NC}"
            echo -e "${GREEN}=========================================${NC}"
            echo ""
            echo "📦 仓库地址: $repo_url"
            echo ""
            echo "📋 分享给同事的消息："
            echo ""
            echo "【工作流分享】小说改编动画短剧工作流系统"
            echo ""
            echo "仓库地址：$repo_url"
            echo ""
            echo "使用步骤："
            echo "1. git clone $repo_url"
            echo "2. cd novel-to-animation-workflow"
            echo "3. pip install -r requirements.txt"
            echo "4. python src/main.py"
            echo ""
            echo "详细使用指南：查看项目根目录的'使用指南.md'文件"
            echo ""
        fi
        ;;

    2)
        echo ""
        echo "========================================="
        echo "  压缩包分享"
        echo "========================================="
        echo ""

        # 创建压缩包
        filename="novel-to-animation-workflow.tar.gz"

        echo "正在创建压缩包..."
        git archive --format=tar.gz --prefix=novel-to-animation-workflow/ HEAD > "$filename"

        if [ ! -f "$filename" ]; then
            echo -e "${RED}❌ 压缩包创建失败${NC}"
            exit 1
        fi

        # 计算MD5和大小
        md5_hash=$(md5sum "$filename" | cut -d' ' -f1)
        file_size=$(du -h "$filename" | cut -f1)

        echo ""
        echo -e "${GREEN}=========================================${NC}"
        echo -e "${GREEN}✅ 压缩包创建完成${NC}"
        echo -e "${GREEN}=========================================${NC}"
        echo ""
        echo "📦 文件名: $filename"
        echo "📏 文件大小: $file_size"
        echo "🔐 MD5校验: $md5_hash"
        echo "📍 文件位置: $PROJECT_ROOT/$filename"
        echo ""
        echo "📋 分享步骤："
        echo "1. 将 $filename 文件发送给同事"
        echo "2. 同事解压: tar -xzf $filename"
        echo "3. 同事进入目录: cd novel-to-animation-workflow"
        echo "4. 同事安装依赖: pip install -r requirements.txt"
        echo "5. 同事启动服务: python src/main.py"
        echo ""
        echo "📋 分享给同事的消息："
        echo ""
        echo "【工作流分享】小说改编动画短剧工作流系统"
        echo ""
        echo "下载地址：[请填写网盘链接或其他分享方式]"
        echo "文件名：$filename"
        echo "MD5校验：$md5_hash"
        echo ""
        echo "使用步骤："
        echo "1. 解压文件：tar -xzf $filename"
        echo "2. 进入目录：cd novel-to-animation-workflow"
        echo "3. 安装依赖：pip install -r requirements.txt"
        echo "4. 启动服务：python src/main.py"
        echo ""
        echo "详细使用指南：查看项目根目录的'使用指南.md'文件"
        echo ""
        ;;

    3)
        echo ""
        echo "打开分享指南..."
        if command -v xdg-open &> /dev/null; then
            xdg-open "$PROJECT_ROOT/分享指南.md" 2>/dev/null || cat "$PROJECT_ROOT/分享指南.md"
        elif command -v open &> /dev/null; then
            open "$PROJECT_ROOT/分享指南.md" 2>/dev/null || cat "$PROJECT_ROOT/分享指南.md"
        else
            cat "$PROJECT_ROOT/分享指南.md"
        fi
        ;;

    4)
        echo "退出分享脚本"
        exit 0
        ;;

    *)
        echo -e "${RED}❌ 无效的选项${NC}"
        exit 1
        ;;
esac

echo ""
echo "========================================="
echo "💡 如需更多帮助，请查看："
echo "   - 分享指南.md：详细的分享方式和步骤"
echo "   - 使用指南.md：详细的使用说明"
echo "   - README.md：项目结构说明"
echo "========================================="
